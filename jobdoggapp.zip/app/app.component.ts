import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { JobdoggcommonService } from './shared/jobdoggcommon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'app';
  route: string;
  
  constructor(location: Location, router: Router,private jobdoggservice:JobdoggcommonService) {
    router.events.subscribe((val) => {
      if(location.path() != ''){
        this.route = location.path().toLowerCase().replace('/','');
      } else {
        this.route = 'home';
      }
    });
    this.jobdoggservice.createObservable()
        .subscribe((data)=>{
            console.log(data,"it is from select ride component");
        });
  }
  public changesome(ev:Event){
    console.log(ev,"from child");
  }
}
