import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';

import { AppConstants } from '../app.constants';

@Injectable()
export class FileUploadService {

  constructor(private _http: Http) { }

  upload(files) {
    debugger;
    let headers = new Headers();
    let options = new RequestOptions({ headers: headers });
    // options.params = parameters;
    return this._http.post(AppConstants.serviceEndpoint + 'EmployeeRegistrationApi/upload', files)
      .map(response => response.json())
      .catch(error => Observable.throw(error));

  }

}
