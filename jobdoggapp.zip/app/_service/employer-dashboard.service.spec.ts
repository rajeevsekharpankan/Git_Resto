import { TestBed, inject } from '@angular/core/testing';

import { EmployerDashboardService } from './employer-dashboard.service';

describe('EmployerDashboardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmployerDashboardService]
    });
  });

  it('should be created', inject([EmployerDashboardService], (service: EmployerDashboardService) => {
    expect(service).toBeTruthy();
  }));
});
