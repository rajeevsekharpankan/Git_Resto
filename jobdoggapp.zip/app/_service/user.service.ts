import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';

import { AppConstants } from '../app.constants';
import { Subject } from 'rxjs/Subject';
@Injectable()

export class UserService {
    //Sibling Communincation through the Subject, State and a shared Service
    private registerComponentViewState = new Subject<any>();

    setState(state: any) {
        this.registerComponentViewState.next(state);
    }

    getState(): Observable<any> {
        return this.registerComponentViewState.asObservable();
    }

    constructor(private _http: HttpClient) {
    }

    public login(data: any): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "SecurityManagementApi/Authenticate", data);
    }

    public getPermission(): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "SecurityManagementApi/GetPermissions");
    }

    public getLoggedInUser(): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "SecurityManagementApi/GetLoggedInUser");
    }
}