﻿import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';

import { AppConstants } from '../app.constants';
@Injectable()

export class MenuService {
    //Sibling Communincation through the Subject, State and a shared Service
    private menuListState = new Subject<any>();

    setState(state: any) {
        this.menuListState.next(state);
    }

    getState(): Observable<any> {
        return this.menuListState.asObservable();
    }

    constructor(private _http: HttpClient) {
    }

    public getMenuList(): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + 'MenuManagementApi/GetMenuList', {});
    }
}