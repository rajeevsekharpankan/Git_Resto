import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';
import { AppConstants } from '../app.constants';
import { State } from "../_models/CommonModels";

@Injectable()
export class CommonService {

  constructor(private _http: HttpClient) { }
  public GetStates(): Observable<any> {
    return this._http.get(AppConstants.serviceEndpoint + "CommonApi/GetStates");
  }

  public getApplicationDropdowns(type: string): Observable<any> {
    return this._http.get(AppConstants.serviceEndpoint + "CommonApi/GetApplicationDropdowns?type=" + type);
  }
}
