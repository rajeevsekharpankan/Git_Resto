﻿import { EducationModel, CompanyModel, jobdoggfile, BankAccountModel, MilitaryModel, CertificateModel, Skills } from './../_models/employee.model';
import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeeModel, EmployeeUpsert } from '../_models/employee.model';

///angular material
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


import { AppConstants } from '../app.constants';
import { RegistrationPopupComponent } from '../employee/registration/registration-popup/registraion-popup.component';

@Injectable()

export class EmployeeRegistrationService {
    public employee: EmployeeModel;
    public _router: Router;
    public _currentPage: number = 0;
    public employeeguid: string;
    constructor(private _http: HttpClient,
        private router: Router,
        private _route: ActivatedRoute,
        public dialog: MatDialog) {
        this._router = router;
        this._route.params.subscribe(params => console.log(JSON.stringify(params["id"])));
        
    }
    public saveEmployeeBasicDetails(): Observable<any> {
        let employeeupsert: EmployeeUpsert = new EmployeeUpsert();
        employeeupsert.employee = this.employee;
        employeeupsert.step = this._currentPage;
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeInfoUpsert", employeeupsert);
    }
    public saveEmployeeEducations(educations: Array<EducationModel>): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeEducationUpsert", educations);
    }
    public DeleteEmployeeEducations(removedids: Array<number>): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeEducationsDelete", removedids);
    }
    public DeleteEmployeeEducationCert(removedids: Array<number>): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeEducationCertDelete", removedids);
    }

    public saveEmployeeEducation(education: EducationModel): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeEducationUpsert", education);
    }
    public saveEmployeeEducationCerts(certificates:Array<CertificateModel>): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeEducationCertUpsert", certificates);
    }
    public saveEmployeeExperience( companies: Array<CompanyModel>): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeCompanyUpsert", companies);
    } public DeleteEmployeeExperience( companies: Array<number>): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeCompanyDelete", companies);
    }
    public GetEmployeeDetails(employeeid: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeDetailSelect?EmployeeGuId=" + employeeid);
    }
    public GetEmployeeEducations(guId: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeEducationSelect?EmployeeGuId=" + guId);
    }
    public GetEmployeeCertificates(guId: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeEducationCertSelect?EmployeeGuId=" + guId);
    }
    public GetEmployeeCompanies(guId: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeCompaniesSelect?EmployeeGuId=" + guId);
    }
    public GetEmployeeMilitaryList(employeeGuId: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeMilitarySelect?EmployeeGuId=" + employeeGuId);
    }
    public SaveEmployeeProfileDetails(employee: any): Observable<any> {
        let employeeupsert: EmployeeUpsert = new EmployeeUpsert();
        employeeupsert.employee = employee;
        employeeupsert.step = this._currentPage;
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeInfoUpsert", employeeupsert);
    }

    public SaveEmployeeProfilePic(file, guId): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + 'EmployeeRegistrationApi/EmployeeProfilePictureUpload?GuId=' + guId, file);

    }

    public SaveEmployeeTransportMode(employee: any): Observable<any> {
        let employeeupsert: EmployeeUpsert = new EmployeeUpsert();
        employeeupsert.employee = employee;
        employeeupsert.step = this._currentPage;
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeInfoUpsert", employeeupsert);
    }
    public SaveEmployeeBankAccountDetails(bankAccountDetails: BankAccountModel): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeBankAccountDetailsUpsert?EmployeeGuId=" + bankAccountDetails.GuId, bankAccountDetails);
    }
    public GetEmployeeBankAccountDetails(guId: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeBankAccountDetailsSelect?GuId=" + guId);
    }
    public SaveEmployeeResume(jbdoggfile: jobdoggfile): Observable<any> {
        jbdoggfile.EmployeeId = this.employee.EmployeeId;
        jbdoggfile.Guid = this.employee.GuId;
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/ResumeUpload", jbdoggfile);
    }

    public SaveEmployeeProfileVdo(jbdoggfile: jobdoggfile): Observable<any> {
        jbdoggfile.Guid = this.employee.GuId;
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/ProfileVdoUpload", jbdoggfile);
    }

    public SaveEmployeeSkillsList(selectedSkillList, guId: string): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeSkillsUpsert?EmployeeGuId=" + guId, selectedSkillList);
    }

    public GetEmployeeSelectedSkillList(guId: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeSelectedSkillsSelect?EmployeeGuId=" + guId);
    }

    public SaveEmployeePreferedJobDetails(preferedJobDetails): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeePreferedJobDetailsUpsert?EmployeeGuId=" + preferedJobDetails.GuId, preferedJobDetails);
    }

    public GetEmployeePreferedJobDetails(guId: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeePreferedJobDetailsSelect?EmployeeGuId=" + guId);
    }

    public UpdateEmployeeUserId(vm: any): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeUserIdUpsert", vm);
    }



    public showMessage(msg: Array<string>) {

        let registrationPopup = this.dialog.open(RegistrationPopupComponent, { data: { message: msg } });
        registrationPopup.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            return result;
        });
    }
    public GetSkills(): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/GetSkills");
    }


    public CreateNewUser(): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "SecurityManagementApi/UserCreation", this.employee);
    }

    public SaveMilitaryDetails(militaryList: Array<MilitaryModel>): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/EmployeeMilitaryUpsert?EmployeeGuId=" + militaryList[0].GuId, militaryList);
    }
}
