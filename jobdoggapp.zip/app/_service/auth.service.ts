import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';

import { AppConstants } from '../app.constants';
import { CookieService } from 'ngx-cookie-service';
@Injectable()

export class AuthService {

  roles: any;
  constructor(private _http: Http, private cookieService: CookieService) {

  }

  public setPermissions(authTimeOut: any) {
    let headers = new Headers();
    headers.append('X-Token', this.cookieService.get(AppConstants.Jobdogg_AuthToken));
    let options = new RequestOptions({ headers: headers });
    return this._http.get(AppConstants.serviceEndpoint + "SecurityManagementApi/GetPermissions", options)
      .toPromise()
      .then(res => {
        this.roles = res.json();
        this.cookieService.set(AppConstants.Jobdogg_Role, this.roles.ContentData.Roles, authTimeOut);
      });
  };

  public getRoles() {
    //return this.roles.ContentData.Roles;
    let rls = this.cookieService.get(AppConstants.Jobdogg_Role);
    let loadedRoles = rls != '' ? rls.split(',') : [];
    return loadedRoles;
  }
}

