import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';

import { AppConstants } from '../app.constants';

@Injectable()
export class EmployerDashboardService {

  constructor(private _http: HttpClient) {

  }

  public getEmployerMessageList(data: any = {}): Observable<any> {
    return this._http.get(AppConstants.serviceEndpoint + 'EmployerApi/GetEmployerMessageList?currentPageNumber=' + data.CurrentPageNumber + '&itemsPerPage=' + data.ItemsPerPage);
  }
  public getEmployerMessageById(data: any = {}): Observable<any> {
    return this._http.get(AppConstants.serviceEndpoint + 'EmployerApi/GetEmployerMessageById?messageId=' + data);
  }

  public getEmployerDetails(data: any = {}): Observable<any> {
    return this._http.get(AppConstants.serviceEndpoint + 'EmployerApi/GetEmployerDetails');
  }

  public getEmployerContactDetails(data: any = {}): Observable<any> {
    return this._http.get(AppConstants.serviceEndpoint + 'EmployerApi/GetEmployerContactDetails');
  }

  public getDogList(): Observable<any> {
    return this._http.get(AppConstants.serviceEndpoint + 'EmployerApi/GetDoggsList');
  }

  public getDogTypes(): Observable<any> {
    return this._http.get(AppConstants.serviceEndpoint + 'EmployerApi/GetTypeOfDoggs');
  }

}
