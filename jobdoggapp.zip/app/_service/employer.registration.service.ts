import { EducationModel, CompanyModel, jobdoggfile, BankAccountModel } from './../_models/employee.model';
import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/observable/throw';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployerModel,CompanyVideofile,EmployerContactList,EmployerContact,EmployerDepartment,EmployerPayment } from '../_models/employer.model';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AppConstants } from '../app.constants';
import { RegistrationPopupComponent } from '../employee/registration/registration-popup/registraion-popup.component';

@Injectable()

export class EmployerRegistrationService {
    public employer: EmployerModel;
    public _router: Router;
    public _currentPage: number = 0;
    constructor(private _http: HttpClient, private router: Router, private _route: ActivatedRoute, public dialog: MatDialog) {
        this._router = router;
        this._route.params.subscribe(params => console.log(JSON.stringify(params["id"])));
        console.log(this._route.url);

    }

    public saveEmployerBasicDetails(employer: EmployerModel): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerBasicInfoInsert", employer);
    }

    public showMessage(msg: Array<string>) {

        let registrationPopup = this.dialog.open(RegistrationPopupComponent, { data: { message: msg } });
        registrationPopup.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            return result;
        });
    }

    public SaveEmployeeProfileVdo(companyVideofile: CompanyVideofile): Observable<any> {
       
        companyVideofile.EmployerGuid = this.employer.EmployerGuid;
        return this._http.post(AppConstants.serviceEndpoint + "EmployeeRegistrationApi/ProfileVdoUpload", companyVideofile);
    }

    public GetEmployerContactDetails(employerGuid: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerContactsSelect?employerGuid=" + employerGuid.toString());
    }

    public saveEmployerContacts(employerContact: EmployerContact): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerContactsUpsert", employerContact);
    }

    public GetEmployerDepartmenttDetails(employerGuid: string): Observable<any> {
        return this._http.get(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerDepartmentsSelect?employerGuid=" + employerGuid.toString());
    }

    public SaveEmployerDept(employerDepartment: EmployerDepartment): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerDepartmentInsert", employerDepartment);
    }

    public RemoveEmployerDept(employerDepartment: EmployerDepartment): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerDepartmentRemove", employerDepartment);
    }

    public UpdateEmployerDept(employerDepartment: EmployerDepartment): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerDepartmentUpdate", employerDepartment);
    }

    public UpdateEmployerPayment(employerPayment: EmployerPayment): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerPaymentUpsert", employerPayment);
    }

    public CreateNewEmployerUser(): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "SecurityManagementApi/EmployerUserCreation", this.employer);
    }

    public UpdateEmployerUserId(vm: any): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + "EmployerRegistrationApi/EmployerUserIdUpsert", vm);
    }

    public SaveEmployerContactPic(file, employerGuid?): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + 'EmployerRegistrationApi/EmployerContactPhotoUpload?employerGuid='+employerGuid, file);
    }

    public saveCompanyLogo(file, employerGuid?): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + 'EmployerRegistrationApi/EmployerCompanyLogoUpload?employerGuid='+employerGuid, file);
    }

    public saveDepartmentVideo(file, employerGuid?): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + 'EmployerRegistrationApi/EmployerDeptVideoUpload?employerGuid='+employerGuid, file);
    }

    public saveCompanyVideo(file, employerGuid?): Observable<any> {
        return this._http.post(AppConstants.serviceEndpoint + 'EmployerRegistrationApi/EmployerCompanyVideoUpload?employerGuid='+employerGuid, file);
    }
}