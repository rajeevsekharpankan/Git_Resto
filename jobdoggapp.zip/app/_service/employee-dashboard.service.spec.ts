import { TestBed, inject } from '@angular/core/testing';

import { EmployeeDashboardService } from './employee-dashboard.service';

describe('EmployeeDashboardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmployeeDashboardService]
    });
  });

  it('should be created', inject([EmployeeDashboardService], (service: EmployeeDashboardService) => {
    expect(service).toBeTruthy();
  }));
});
