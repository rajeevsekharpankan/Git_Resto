import { Component, OnInit, Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';

@Component({
    selector: 'app-registration-popup',
    templateUrl: './registration-popup.component.html',
    styleUrls: ['./registration-popup.component.css']
  })

export class RegistrationPopupComponent implements OnInit {
public message:Array<string>;
    constructor(public thisModalRef: MatDialogRef<RegistrationPopupComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any,
      private router: Router) {
        this.message=data.message;
       }
  
    ngOnInit() {
      console.log(this.data)
    }
  
    close() {
      this.thisModalRef.close('Test Data from model');
    }
  }
  