import { Component, OnInit, Injectable, Output, EventEmitter } from '@angular/core';
import { Router } from "@angular/router";
import { EmployeeModel } from "../../../_models/employee.model";
import { EmployeeRegistrationService } from "../../../_service/employee.registration.service";
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
    selector: 'app-background-check',
    templateUrl: './background-check.component.html',
    styleUrls: ['./background-check.component.css']
})

export class BackgroundcheckComponent implements OnInit {
    public _employee: EmployeeModel;
    public formSubmitAttempt: boolean;
    private agree: boolean;
    backgroundCheckForm: FormGroup;
    constructor(
        private _router: Router, private _employeeservice: EmployeeRegistrationService,
        private formBuilder: FormBuilder
    ) {
        this._employeeservice.employee = this._employee = new EmployeeModel();
    };

    ngOnInit() {
        this.formSubmitAttempt = false;
        this.CreateForm();
    }
    private CreateForm() {
        this.backgroundCheckForm = this.formBuilder.group({
            agree: [false, Validators.required]
        });
    }
    public Next() {
        this.formSubmitAttempt = true;
        if (this.backgroundCheckForm.valid) {
            this._router.navigate(["employeeregistration/employeebasic"]);
        }
    }
    public change() {
        this._employee.IsBackgroundCheckVerified = this.agree;
    }

    isFieldValid(field: string) {
        return !this.backgroundCheckForm.get(field).valid && this.backgroundCheckForm.get(field).touched ||
            (this.backgroundCheckForm.get(field).untouched && this.formSubmitAttempt);
    }

    displayFieldCss(field: string) {
        return {
            'requiredvalidation': this.isFieldValid(field)
        };
    }
}
