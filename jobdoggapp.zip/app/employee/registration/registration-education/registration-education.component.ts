import { CommonService } from './../../../_service/common.service';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { EducationModel, CertificateModel } from './../../../_models/employee.model';
import { Component, OnInit } from '@angular/core';
import { EmployeeRegistrationService } from "../../../_service/employee.registration.service";
import { State } from "../../../_models/CommonModels";

@Component({
    selector: 'app-registration-education',
    templateUrl: './registration-education.html',

})
export class registrationeducationComponent implements OnInit {
    public removedcertids: Array<number> = [];
    public removedids: Array<number> = [];
    public educForm: FormGroup;
    public licesnseForm: FormGroup;
    public educations: Array<EducationModel> = [];
    public schoollist: Array<EducationModel> = [];
    public collegelist: Array<EducationModel> = [];
    public certificatelist: Array<CertificateModel> = [];
    public _certificate: CertificateModel;
    public _education: EducationModel;
    public _college: EducationModel;
    private formSubmitAttempt: boolean;
    public states = [];
    constructor(private _employeeService: EmployeeRegistrationService,
        private _commonservice: CommonService,
        private formBuilder: FormBuilder, private formBuilder2: FormBuilder) {
        this._commonservice.GetStates()
            .subscribe((data: any) => {
                this.states = data.ContentData;
            });
        if (this._employeeService.employee == null) {
            debugger;

        }
        _employeeService._currentPage = 4;

    }
    private createEduForm() {
        this.educForm = this.formBuilder.group({
            EducationType: ['', Validators.required],
            EducationDescription: ['', Validators.required],
            EducationTypeDetail: ['', Validators.required],

            City: ['', Validators.required],
            State: ['', Validators.required],
            year: [, Validators.required],
        });
        console.log("status : " + this.educForm.status);
    }
    private createLicenseForm() {
        this.licesnseForm = this.formBuilder2.group({
            CertificationLicense: ['', Validators.required],
        });
        console.log("status : " + this.licesnseForm.status);
    }


    ngOnInit() {
        this._education = new EducationModel();
        this._certificate = new CertificateModel();
        this._certificate.CertificationLicense="";
        this.createEduForm();
        this.fillEducation();
        this.fillCertificates();
        this.iscertificatevalid = true;
    }
    public Next() {
        this._employeeService._router.navigate(["employeeregistration/employeeexperience"]);
        this.educations = this._employeeService.employee.educations != null ? this._employeeService.employee.educations : [];
    }
    public submitedu(form: NgForm) {
        this.formSubmitAttempt = true;
        if (this.educForm.valid) {
            console.log(JSON.stringify(this._education));
            debugger;
            let education = new EducationModel();
            education.day = form.value["day"];
            education.month = form.value["month"];
            education.year = form.value["year"];
            education.City = form.value["City"];
            education.State = form.value["State"];
            education.EducationDescription = form.value["EducationDescription"];
            education.EducationType = form.value["EducationType"];
            education.EmployeeId = this._employeeService.employee.EmployeeId;
            education.EducationTypeDetail = form.value["EducationTypeDetail"];
            debugger;
            education.DateOfGraduation = new Date("01/01/" + this._education.year);

            education.Status = 'Active';
            this.educations.push(education);
            // this._education.day = "";
            // this._education.month= "";
            // this._education.year ="";
            // this._education.EducationDescription = "";
            // this._education.EducationType ="";
            // this._education.EmployeeId = null;
            // this._education.EducationTypeDetail=""; 
            // this._education.City=""; 
            // this._education.State=""; 
            this.createEduForm();
        }
    }

    isFieldValid(field: string) {
        return !this.educForm.get(field).valid && this.educForm.get(field).touched ||
            (this.educForm.get(field).untouched && this.formSubmitAttempt);
    }

    displayFieldCss(field: string) {
        return {
            'requiredvalidation': this.isFieldValid(field)
        };
    }
    public Add() {
        console.log(JSON.stringify(this._education));
        debugger;
        let education = new EducationModel();
        education.day = this._education.day;
        education.month = this._education.month;
        education.year = this._education.year;

        education.EducationDescription = this._education.EducationDescription;
        education.EmployeeId = this._employeeService.employee.EmployeeId;
        debugger;
        education.DateOfGraduation = new Date("01/01/" + this._education.year);
        this._education = new EducationModel();
        education.Status = 'Active';
        this.educations.push(education);

    }
    public AddSchools() {
        console.log(JSON.stringify(this._education));
        this._education.DateOfGraduation = new Date("01/01/" + this._education.year);
        this._education.EmployeeId = this._employeeService.employee.EmployeeId;
        this._education.Crt_By = "PBLC_USR";
        this._education.EducationType = "school";
        this._employeeService.saveEmployeeEducation(this._education)
            .subscribe((data: any) => {
                debugger;
                this._education.EmployeeEductaionId = data.ContentData;
                this.schoollist.push(this._education);
                this._education = new EducationModel();
            });


    }
    public AddColleges() {
        console.log(JSON.stringify(this._education));
        this._college.DateOfGraduation = new Date("01/01/" + this._college.year);
        this._college.EmployeeId = this._employeeService.employee.EmployeeId;
        this._college.Crt_By = "PBLC_USR";
        this._college.EducationType = "college";
        this._employeeService.saveEmployeeEducation(this._college)
            .subscribe((data: any) => {
                debugger;
                this._college.EmployeeEductaionId = data.ContentData;
                this.collegelist.push(this._college);
                this._college = new EducationModel();
            });
    }
    iscertificatevalid = true;
    public submitcertificate(certificate: CertificateModel) {
        debugger;
        if (certificate.CertificationLicense == "" ) {
            this.iscertificatevalid = false;
            certificate.CertificationLicense = ""
        }
        if (this.iscertificatevalid) {
            console.log(JSON.stringify(this._certificate));
            this._certificate.EmployeeId = this._employeeService.employee.EmployeeId;
            this._certificate.Crt_By = "PBLC_USR";
            this.certificatelist.push(this._certificate);
            this.iscertificatevalid = true;
            this._certificate=new CertificateModel();
            this._certificate.CertificationLicense="";
        }
    }
    public removeedu(education: EducationModel) {
        this.educations.indexOf(education);
        this.educations.splice(this.educations.indexOf(education), 1)
        console.log(education);
        debugger;
        education.Status = 'Inactive';
        this.removedids.push(education.EmployeeEductaionId);
    }
    public removcert(certificate: CertificateModel) {
        this.certificatelist.indexOf(certificate);
        this.certificatelist.splice(this.certificatelist.indexOf(certificate), 1)
        console.log(certificate);
        debugger;
        certificate.Status = 'Inactive';
        this.removedcertids.push(certificate.EmployeeEducationCertId);
    }
    public submitform() {
        this._employeeService.employee.educations = this.educations;
        this.educations.forEach(edu => {
            debugger;
            edu.DateOfGraduation = new Date(edu.month + '/' + edu.day + '/' + edu.year);

        });
        this._employeeService.DeleteEmployeeEducations(this.removedids)
            .subscribe((data) => {
                debugger;
                if (data.ContentData) {
                    this._employeeService.saveEmployeeEducations(this.educations).subscribe((data: any) => {
                        debugger;
                        let result = data.ContentData;
                        this._employeeService.DeleteEmployeeEducationCert(this.removedcertids)
                            .subscribe((data: any) => {
                                this._employeeService.saveEmployeeEducationCerts(this.certificatelist)
                                    .subscribe((data: any) => {
                                        debugger;
                                        this._employeeService.GetEmployeeCertificates(this._employeeService.employee.GuId)
                                            .subscribe((data: any) => {
                                                this.certificatelist = data.ContentData;
                                            });
                                        this._certificate = new CertificateModel();
                                        this._employeeService._router.navigate(["employeeregistration/employeeexperience"]);

                                    });

                            });


                    });
                }
            });




    }
    public fillEducation() {
        this._employeeService.GetEmployeeEducations(this._employeeService.employee.GuId).subscribe((data: any) => {
            debugger;
            this._employeeService.employee.educations = this.educations = data.ContentData != null ? data.ContentData : [];
            this.educations.forEach(edu => {
                debugger;
                edu.day = new Date(edu.DateOfGraduation).getDay().toString();
                edu.month = (new Date(edu.DateOfGraduation).getMonth() + 1).toString();
                edu.year = new Date(edu.DateOfGraduation).getFullYear().toString();
                if (edu.EducationType == 'school') {
                    this.schoollist.push(edu);
                }
                else {
                    this.collegelist.push(edu);
                }
            });

        });
    }
    public fillCertificates() {
        this._employeeService.GetEmployeeCertificates(this._employeeService.employee.GuId)
            .subscribe((data: any) => {
                this.certificatelist = data.ContentData;
            });
    }
}
