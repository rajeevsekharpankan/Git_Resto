import { jobdoggfile } from './../../../_models/employee.model';
import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from "@angular/forms";

import { EmployeeRegistrationService } from "../../../_service/employee.registration.service";
import { CompanyModel } from '../../../_models/employee.model';


@Component({
    selector: 'app-registration-experience',
    templateUrl: './registration-experience.html',
    styleUrls: ['./registration-experience.component.css']

})
export class registrationexperienceComponent implements OnInit {
    form: FormGroup;
    loading: boolean = false;
    formSubmitAttempt: boolean = false;
    public removedids:Array<number>=[];
    @ViewChild('fileInput') fileInput: ElementRef;

    public companies: Array<CompanyModel> = [];
    public _company: CompanyModel;
    constructor(private _employeeService: EmployeeRegistrationService, private fb: FormBuilder) {
        this._employeeService._currentPage = 5;

        this.fillCompanies();
        this.createForm();
    }

    ngOnInit() {
        this._company = new CompanyModel();
        this._company.CompanyName = "";
        this._company.HireDate = null;
        this._company.LenthOfEmployment = "";
        this._company.Tittle = "";
    }
    public Next() {
        this._employeeService._router.navigate(["employeeregistration/employeeskills"]);
    }
    public removecompnay(company: CompanyModel) {
        // this.educations.indexOf(education);
        // this.educations.splice(this.educations.indexOf(education), 1)
        debugger;
        company.Status = 'Inactive';
        this.companies.indexOf(company);
        this.companies.splice(this.companies.indexOf(company), 1)
        console.log(company);
        debugger;
        company.Status = 'Inactive';
        this.removedids.push(company.EmployeeCompanyId);
    }
    public submitexp(expform: NgForm) {
        this.formSubmitAttempt = true;
        if (this.form.valid) {
            console.log(JSON.stringify(this._company));
            debugger;
            if (this._company.CompanyName.trim() == "") {
                //this._employeeService.showMessage("Please enter compnay name");
                return;
            }
            let company = new CompanyModel();
            company.HireDate = this.form.value["HireDate"];
            company.Status = 'Active';
            company.Crt_By = "PBLC_USR";
            company.EmployeeId = this._employeeService.employee.EmployeeId;
            company.CompanyName = this.form.value["CompanyName"];
            company.Tittle = this.form.value["Tittle"];
            company.LenthOfEmployment = this.form.value["LenthOfEmployment"];
            //company.=this.form.value["LenthOfEmployment"];
            this.companies.push(company);
            this._company.CompanyName = "";
            this._company.HireDate = null;
            this._company.Tittle = "";
            this._company.LenthOfEmployment = "";
        }

        // this._employeeService._router.navigate(["employeeregistration/employeeskills"]);


    }
    onFileChange(event) {
        let reader = new FileReader();
        if (event.target.files && event.target.files.length > 0) {
            let file = event.target.files[0];
            reader.readAsDataURL(file);
            //console.log(reader.readAsBinaryString(file));

            reader.onload = () => {
                console.log(file.name)
                console.log(file.type);
                //console.log("result " + reader.result);
                debugger;
                let jbdoggfile = new jobdoggfile();
                jbdoggfile.filecontent = reader.result;
                jbdoggfile.filename = file.name;
                this._employeeService.SaveEmployeeResume(jbdoggfile).subscribe((data: any) => {
                    debugger;
                    console.log(data.ContentData);
                    //this._employeeService.showMessage("Uploded successfully");
                });

            };
        }
    }
    public fillCompanies() {
        this._employeeService.GetEmployeeCompanies(this._employeeService.employee.GuId).subscribe((data: any) => {
            debugger;
            this._employeeService.employee.companies = this.companies = data.ContentData != null ? data.ContentData : [];
        });
    }
    createForm() {
        this.form = this.fb.group({
            CompanyName: ['', Validators.required],
            Tittle: ['', Validators.required],
            LenthOfEmployment: ['', Validators.required],
            HireDate: ['', Validators.required],
            avatar: null
        });
    }
    isFieldValid(field: string) {
        if (field == "everify") {
            if (this.form.get(field).value == false) return false;
        }
        return !this.form.get(field).valid && this.form.get(field).touched ||
            (this.form.get(field).untouched && this.formSubmitAttempt);
    }

    displayFieldCss(field: string) {
        if (field == "everify") {
            if (this.form.get(field).value == false) return {
                'requiredvalidation': this.isFieldValid(field)
            };

        }
        return {
            'requiredvalidation': this.isFieldValid(field)
        };
    }
    public submitcompany() {
        this._employeeService.DeleteEmployeeExperience(this.removedids)
            .subscribe((data: any) => {
                debugger;
                this._employeeService.saveEmployeeExperience(this.companies)
                    .subscribe((data: any) => {
                           this._employeeService._router.navigate(["employeeregistration/employeeskills"])
                    });
            });

    }
}
