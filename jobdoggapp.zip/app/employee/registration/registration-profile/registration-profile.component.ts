import { Component, OnInit } from '@angular/core';
import { EmployeeRegistrationService } from "../../../_service/employee.registration.service";
import { FileUploadService } from './../../../_service/file-upload.service';
import { NgForm, FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { EmployeeModel } from './../../../_models/employee.model';
import { Router } from '@angular/router/src/router';
import { AppConstants } from './../../../app.constants';

@Component({
    selector: 'registration-profile',
    templateUrl: './registration-profile.component.html',
})
export class RegistrationprofileComponent implements OnInit {
    private uploadFileLoc: string = '';
    private imageName: string;
    private file: any;
    public _employee: EmployeeModel;
    private formSubmitAttempt: boolean;
    profileForm: FormGroup;
    constructor(
        private _employeeService: EmployeeRegistrationService,
        private _fileUploadService: FileUploadService,
        private formBuilder: FormBuilder) {
        debugger;
        this._employeeService._currentPage = 7;
        this._employee = this._employeeService.employee != null ? this._employeeService.employee : new EmployeeModel();
        this.uploadFileLoc = this._employeeService.employee != null ? this._employeeService.employee.ProfilePhoto : "";
        debugger;
        let img = this.uploadFileLoc != null ? this.uploadFileLoc.split('_') : "";
        this.imageName = img[1];
    }

    ngOnInit() {
        this.createForm();
        this.formSubmitAttempt = false;
    }

    private createForm() {
        this.profileForm = this.formBuilder.group({
            Description: ['', Validators.required],
            DesiredLocation: ['', Validators.required],
            DesiredPosition: ['', Validators.required],
            EmploymentType: ''
        });
    }

    public Next() {
        this._employeeService._router.navigate(["employeeregistration/profilevideo"]);
    }

    public onFileChange(_event): void {
        this.file = _event.target.files;
        this.imageName = this.file[0].name;
    }

    public uploadFile(): void {
        let errors = [];
        if (this.file.length == 1) {
            var formData = new FormData();
            formData.append("profilePic", this.file[0], this.file[0].name);
            this._employeeService.SaveEmployeeProfilePic(formData, this._employeeService.employee.GuId)
                .subscribe(
                successDate => {
                    let uploadPath = successDate.ContentData.rootFolder + "/" + successDate.ContentData.fileGuid + "/" + successDate.ContentData.fileName;
                    this.uploadFileLoc = AppConstants.WebContents + "/" + uploadPath  // successDate.ContentData;
                },
                error => {
                    console.log(error);
                    errors.push(error.ExceptionMessage);
                })
        }

    }
    public SaveProfileDetails(formValues): void {
        this.formSubmitAttempt = true;
        this._employee.ProfilePhoto = this.uploadFileLoc;
        this._employee.Description = formValues.Description;
        this._employee.DesiredLocation = formValues.DesiredLocation;
        this._employee.DesiredPosition = formValues.DesiredPosition;
        this._employee.EmploymentType = formValues.EmploymentType;
        this._employeeService.SaveEmployeeProfileDetails(this._employee).subscribe(result => {
            if (result.ContentData != null) {
                this.Next();
            }
        });
    }

    isFieldValid(field: string) {
        return !this.profileForm.get(field).valid && this.profileForm.get(field).touched ||
            (this.profileForm.get(field).untouched && this.formSubmitAttempt);
    }

    displayFieldCss(field: string) {
        return {
            'requiredvalidation': this.isFieldValid(field)
        };
    }
}
