import { CommonService } from './../../../_service/common.service';
import { State } from './../../../_models/CommonModels';
import { EmployeeModel } from './../../../_models/employee.model';
import { EmployeeRegistrationService } from './../../../_service/employee.registration.service';
import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms'
import { Http, Response, Headers, RequestOptions } from '@angular/http';
@Component({
    selector: 'app-registration-basic',
    templateUrl: './registration-basic.html',
    styleUrls: ['./registration-basic.component.css']
})
export class RegistrationbasicComponent implements OnInit {
    mask: any[] = ['+', '1', ' ', '(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    public model: any = {};
    public states: State[];
    // public selectedState: State;
    public _employee: EmployeeModel = new EmployeeModel();
    private formSubmitAttempt: boolean;

    basicForm: FormGroup;
    constructor(
        private _employeeservice: EmployeeRegistrationService,
        private _commonservice: CommonService,
        private formBuilder: FormBuilder
    ) {
        this._employeeservice._currentPage = 1;
    }

    ngOnInit() {
        this.createForm();
        this.formSubmitAttempt = false;
        this.fillStates();
        this._employeeservice.GetEmployeeDetails("601343ab-ddce-4ab4-ab05-eba296451c88").subscribe((data: any) => {
            debugger;
            this._employeeservice.employee = this._employee = data.ContentData;
            this._employee = this._employeeservice.employee != null ? this._employeeservice.employee : new EmployeeModel();
        });


    }
    fillStates() {
        this._commonservice.GetStates()
            .subscribe((data: any) => {
                console.log(data);
                this.states = data.ContentData;
            });
    }
    private emailPattern = "^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$";
    private zippattern = "^[0-9]{5}(?:-[0-9]{4})?$";
    private createForm() {
        this.basicForm = this.formBuilder.group({
            firstname: ['', Validators.required],
            middlename: '',
            lastname: ['', Validators.required],
            addressline1: ['', Validators.required],
            state: ['', Validators.required],
            zip: ['', Validators.compose([Validators.required, Validators.pattern(this.zippattern)])],
            phone1: ['', Validators.required],
            phone2: ['', Validators.required],
            email: ['', Validators.compose([Validators.required, Validators.email])],
            city: ['', Validators.required],
            ephone: ['', Validators.required],
            agree: [false, Validators.required],
            esignature: [false, Validators.required],
            everify: [false, Validators.required]
        });
        console.log("status : " + this.basicForm.status);
    }

    public submitbasic(form: NgForm) {
        this.formSubmitAttempt = true;
        if (this.basicForm.valid) {
            let employee = this._employeeservice.employee;
            employee.FirstName = form.value["firstname"];
            employee.MiddleName = form.value["middlename"];
            employee.LastName = form.value["lastname"];
            employee.AddressLine1 = form.value["addressline1"];
            employee.City = form.value["city"];
            employee.State = form.value["state"];
            employee.Zip = form.value["zip"];
            employee.HomePhone = form.value["phone1"];
            employee.WorkPhone = form.value["phone2"];
            employee.EmergencyContact = form.value["ephone"];
            employee.Email = form.value["email"];
            employee.AgreeFlag = form.value["agree"] ? form.value["agree"] : false;
            employee.SignatureFlag = form.value["esignature"] ? form.value["esignature"] : false;
            employee.EverifyFlag = form.value["everify"] ? form.value["everify"] : false;
            employee.Crt_By = "PBLC_USR";
            // console.log(JSON.stringify(this._employeeservice.employee));
            this._employeeservice.saveEmployeeBasicDetails().subscribe((data: any) => {
                if (data.ContentData != null) {
                    this._employeeservice.employee.GuId = data.ContentData;
                    this.next();
                }
            });
        }
    }

    public prev() {
        this._employeeservice._router.navigate(["employeeregistration/backgroundcheck"]);
    }

    public next() {
        this._employeeservice._router.navigate(["employeeregistration/employeepersonal"]);
    }

    isFieldValid(field: string) {
        if (field == "everify") {
            if (this.basicForm.get(field).value == false) return false;
        }
        return !this.basicForm.get(field).valid && this.basicForm.get(field).touched ||
            (this.basicForm.get(field).untouched && this.formSubmitAttempt);
    }

    displayFieldCss(field: string) {
        if (field == "everify") {
            if (this.basicForm.get(field).value == false) return {
                'requiredvalidation': this.isFieldValid(field)
            };

        }
        return {
            'requiredvalidation': this.isFieldValid(field)
        };
    }
}

