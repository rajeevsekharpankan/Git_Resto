﻿import { Component, OnInit, Input } from '@angular/core';
import { EmployeeRegistrationService } from "../../../_service/employee.registration.service";


@Component({
    selector: 'app-progressbar',
    templateUrl: './progressbar.component.html',
})
export class ProgressbarComponent implements OnInit {
    public currentpage: number = 0;
    public customstyles = "";

    constructor(private _employeeservice: EmployeeRegistrationService) {
        this.customstyles = "completed current"
        this.currentpage = this._employeeservice._currentPage;
        console.log("currentppage", this.currentpage);
    }

    ngOnInit() {
    }

}
