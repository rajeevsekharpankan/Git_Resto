﻿import { Component, OnInit } from '@angular/core';
import { EmployeeRegistrationService } from "../../../_service/employee.registration.service";
import { PreferedJobDetails, SkillList, Skills } from '../../../_models/employee.model';
import { MatListOption } from '@angular/material';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import * as _ from 'underscore';
import { debug } from 'util';
// Angular Material
@Component({
    selector: 'app-employeeskills',
    templateUrl: './employeeskills.component.html',
    styleUrls: ['./employeeskills.component.css']
})
export class EmployeeSkillsComponent implements OnInit {
    public skillList: Array<SkillList> = [];
    public SelectedSkillList: Array<SkillList> = [];
    public preferedJobDetails = new PreferedJobDetails();
    public selectedSkillsIds: any;
    private formSubmitAttempt: boolean;
    skillsForm: FormGroup;

    public states = [
        new State("WI", "WI"),
        new State("FL", "FL"),
        new State("TX", "TX"),
        new State("OH", "OH")
    ];
    public DesiredIndustries = [
        { id: "IT", name: "IT Industry" },
        { id: "Gov", name: "Goverment" }
    ];
    public DesiredPositions = [
        { id: "Developer", name: "Developer" },
        { id: "Manager", name: "Manager" },
        { id: "Trainee", name: "Trainee" }
    ];
    public DesiredSalaries = [
        { id: "0-1000", range: "0-1000" },
        { id: "1000-2500", range: "1000-2500" },
        { id: "2500-5000", range: "2500-5000" }
    ];

    constructor(
        private _employeeService: EmployeeRegistrationService,
        private formBuilder: FormBuilder
    ) {
        this._employeeService._currentPage = 5;
        this.fillskills();
        this.getEmplyeePreferedJobDetails();
        this.getEmployeeSelectedSkills();
    }

    ngOnInit() {
        this.createForm();
        this.formSubmitAttempt = false;
    }

    private createForm() {
        this.skillsForm = this.formBuilder.group({
            DesiredIndustry: ['', Validators.required],
            DesiredPostion: ['', Validators.required],
            DesiredSalary: ['', Validators.required],
            WorkType: ['', Validators.required],
            State: ['', Validators.required],
            City: ['', Validators.required],
            skills: '',
        });
    }

    public getEmplyeePreferedJobDetails() {
        this._employeeService.GetEmployeePreferedJobDetails(this._employeeService.employee.GuId).subscribe((data) => {
            if (data.ContentData) {
                this._employeeService.employee.PreferedJobDetails = this.preferedJobDetails = data.ContentData;
            }
        });
    }

    public getEmployeeSelectedSkills() {
        this._employeeService.GetEmployeeSelectedSkillList(this._employeeService.employee.GuId).subscribe((data) => {
            if (data.ContentData) {
                this._employeeService.employee.SelectedSkillList = this.SelectedSkillList = data.ContentData;
                this.selectedSkillsIds = _.map(this.SelectedSkillList, (skill) => {
                    return skill.SkillId
                });
            }
        });
    }

    public Next() {
        this.formSubmitAttempt = true;
        if (this.skillsForm.valid) {
            let oldSelectedSkillList = this.SelectedSkillList;
            this.SelectedSkillList = this.getSelectedSkills();
            this.preferedJobDetails = {
                GuId: this._employeeService.employee ? this._employeeService.employee.GuId : null,
                DesiredIndustry: this.preferedJobDetails.DesiredIndustry,
                DesiredPosition: this.preferedJobDetails.DesiredPosition,
                DesiredSalary: this.preferedJobDetails.DesiredSalary,
                WorkType: this.preferedJobDetails.WorkType,
                City: this.preferedJobDetails.City,
                State: this.preferedJobDetails.State
            }
            this._employeeService.SaveEmployeeSkillsList(this.SelectedSkillList, this._employeeService.employee.GuId).subscribe((skillData) => {
                if (skillData.ContentData) {
                    this._employeeService.SaveEmployeePreferedJobDetails(this.preferedJobDetails).subscribe((preferedJobdata) => {
                        if (preferedJobdata.ContentData) {
                            this._employeeService._router.navigate(["employeeregistration/Profile"]);
                        }
                    });
                }
            });
        }
    }

    public fillskills() {
        this._employeeService.GetSkills().subscribe((data: any) => {
            this.skillList = data.ContentData;
        });
    }

    public prev() {
        this._employeeService._router.navigate(["employeeregistration/employeeexperience"]);
    }

    public getSelectedSkills(): Array<SkillList> {
        return _.filter(this.skillList, (skill) => {
            if (_.contains(this.selectedSkillsIds, skill.SkillId)) {
                return skill;
            }
        });
    }

    isFieldValid(field: string) {
        return !this.skillsForm.get(field).valid && this.skillsForm.get(field).touched ||
            (this.skillsForm.get(field).untouched && this.formSubmitAttempt);
    }

    displayFieldCss(field: string) {
        return {
            'requiredvalidation': this.isFieldValid(field)
        };
    }
}
export class State {
    constructor(public id: string, public name: string) { }
}