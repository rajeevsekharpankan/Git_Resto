import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { EmployeeRegistrationService } from "../../../_service/employee.registration.service";

import * as RecordRTC from 'recordrtc'
import { jobdoggfile } from '../../../_models/employee.model';
@Component({
  selector: 'app-registration-video',
  templateUrl: './registration-video.html',

})

export class RegistrationVideoComponent implements OnInit {
  stream: MediaStream; recordRTC: any;
  public audiovideourl: string = "";

  public profilevdo: jobdoggfile;
  @ViewChild('video') video: any;
  public Recordtext: string = "";
  public _employeeService: EmployeeRegistrationService;
  constructor(private employeeService: EmployeeRegistrationService) {
    this._employeeService = employeeService;
  }

  ngOnInit() {
    this.Recordtext = "REC";
  }
  ngAfterViewInit() {
    let _video = this.video.nativeElement;
    debugger;
    console.log(_video);
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then(stream => {
          _video.src = window.URL.createObjectURL(stream);
          _video.play();


        })

    }

  }

  startRecording() {
    this.Recordtext="Stop";
    let _video = this.video.nativeElement;
    this.Recordtext = "Stop";
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then(this.successCallback.bind(this), this.errorCallback.bind(this))
    }
  }

  errorCallback(vdostream: MediaStream) {
    let stream;
    var options = {
      mimeType: 'video/webm', // or video/webm\;codecs=h264 or video/webm\;codecs=vp9
      audioBitsPerSecond: 128000,
      videoBitsPerSecond: 128000,
      bitsPerSecond: 128000 // if this line is provided, skip above two
    };
    stream = vdostream;
    this.recordRTC = RecordRTC(vdostream, options);
    this.recordRTC.startRecording();
    let video: HTMLVideoElement = this.video.nativeElement;
    video.src = window.URL.createObjectURL(stream);
    //this.toggleControls();
  }
  successCallback(vdostream: MediaStream) {
    let stream;
    var options = {
      mimeType: 'video/webm', // or video/webm\;codecs=h264 or video/webm\;codecs=vp9
      audioBitsPerSecond: 128000,
      videoBitsPerSecond: 128000,
      bitsPerSecond: 128000 // if this line is provided, skip above two
    };
    this.stream = vdostream;
    this.recordRTC = RecordRTC(vdostream, options);
    this.recordRTC.startRecording();
    let video: HTMLVideoElement = this.video.nativeElement;
    video.src = window.URL.createObjectURL(vdostream);
    //this.toggleControls();
  }

  stopRecording() {
    this.Recordtext = "REC";
    let recordRTC = this.recordRTC;
    recordRTC.stopRecording(this.processVideo.bind(this));
    let stream = this.stream;
    stream.getAudioTracks().forEach(track => track.stop());
    stream.getVideoTracks().forEach(track => track.stop());
  }
  processVideo(audioVideoWebMURL) {
    debugger;
    this.audiovideourl = audioVideoWebMURL;
    let video: HTMLVideoElement = this.video.nativeElement;
    let recordRTC = this.recordRTC;
    video.src = audioVideoWebMURL;
    //this.toggleControls();
    var recordedBlob = recordRTC.getBlob();
    recordRTC.getDataURL(function (dataURL) {
      console.log("frist", dataURL);
      video.src = dataURL;
      video.play();
    });
  }
  download() {
    this.recordRTC.save('video.webm');
  }
  Replay() {
    // debugger;

    let video: HTMLVideoElement = this.video.nativeElement;
    video.play();
  }
 
  public uploadvideo() {
 
    let recordRTC = this.recordRTC;
    var recordedBlob = recordRTC.getBlob();
    let vdo = new jobdoggfile();
    let eservice = this._employeeService;
    recordRTC.getDataURL(function (dataURL) {
           console.log(dataURL);
      vdo.filecontent = dataURL;
      vdo.filename = eservice.employee.FirstName;

      eservice.SaveEmployeeProfileVdo(vdo).subscribe((data: any) => {
        eservice.employee.VideoFilePath=data.ContentData;
        eservice._router.navigate(["employeeregistration/profilevideouploaded"]);
      });

    });
    vdo.filename = this._employeeService.employee.FirstName + new Date();
  }


  onFileChange(event) {
    let reader = new FileReader();
    if (event.target.files && event.target.files.length > 0) {
      let file = event.target.files[0];
      reader.readAsDataURL(file);
      //console.log(reader.readAsBinaryString(file));

      reader.onload = () => {
        console.log(file.name)
        console.log(file.type);
        //console.log("result " + reader.result);
        debugger;
        this.profilevdo = new jobdoggfile();
        this.profilevdo.filecontent = reader.result;
        this.profilevdo.filename = file.name;
        this._employeeService.SaveEmployeeProfileVdo(this.profilevdo).subscribe((data: any) => {
          debugger;
          this._employeeService.employee.VideoFilePath=data.ContentData;
        });

      };
    }
  }
}

