import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-registration-10',
    templateUrl: './registration-10.html',
})
export class registration10Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
