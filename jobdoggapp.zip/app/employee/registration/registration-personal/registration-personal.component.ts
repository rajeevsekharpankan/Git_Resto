import { EmployeeModel } from './../../../_models/employee.model';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { EmployeeRegistrationService } from "../../../_service/employee.registration.service";
import { NgClass } from '@angular/common';


@Component({
    selector: 'app-registration-personal',
    templateUrl: './registration-personal.component.html',
    styleUrls: ['./registration-personal.component.css']

})
export class registrationpersonalComponent implements OnInit {
    ssnmask: any[] = [/[1-9]/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    private ssnpattern = "^[0-9]{5}(?:-[0-9]{4})?$";
    public _employee: EmployeeModel;
    private formSubmitAttempt: boolean;
    personalform: FormGroup;
    private Dob = new Date();
    constructor(private _employeeservice: EmployeeRegistrationService,
        private formBuilder: FormBuilder) {
        if (this._employeeservice.employee == null) {
            this._employeeservice._router.navigate(["employeeregistration/backgroundcheck"]);
        }
        this._employeeservice._currentPage = 2;
        this._employee = this._employeeservice.employee;
        this._employee.Day = new Date(this._employee.Dob).getDay().toString();
        this._employee.Month = (new Date(this._employee.Dob).getMonth() + 1).toString();
        this._employee.Year = new Date(this._employee.Dob).getFullYear().toString();
    }

    ngOnInit() {
        this.createForm();
        this.formSubmitAttempt = false;
    }

    private createForm() {
        this.personalform = this.formBuilder.group({
            nickname: ['', Validators.required],
            ssn: ['', Validators.compose([Validators.required])],
            licensenumber: ['', Validators.required],
            gender: ['', Validators.required],
            salary: ['', Validators.required],
            title: ['', Validators.required],
            ethnicity: ['', Validators.required],
            // month: ['', Validators.required],
            // day: ['', Validators.required],
            // year: ['', Validators.required]
        });
    }

    public dateChange(_event) {
        this.Dob = new Date(_event.value);
    }
    public submitpersonal(form: NgForm) {
        this.formSubmitAttempt = true;
        if (this.personalform.valid) {
            let employee = this._employeeservice.employee;
            employee.NickName = form.value["nickname"];
            employee.SSN = form.value["ssn"];
            employee.DriverLicenseNumber = form.value["licensenumber"];
            //employee.Dob = new Date(form.value["month"] + '/' + form.value["day"] + '/' + form.value["year"]);
            employee.Dob = this.Dob;
            employee.Ethnicity = form.value["ethnicity"];
            employee.Sex = form.value["gender"];
            employee.CurrentSalary = form.value["salary"];
            employee.CurrentTitle = form.value["title"];
            this._employeeservice.saveEmployeeBasicDetails().subscribe((data: any) => {
                if (data.ContentData != null) {
                    this.next();
                }
            });
        }
    }

    public prev() {
        this._employeeservice._router.navigate(["employeeregistration/employeebasic"]);
    }

    public next() {
        this._employeeservice._router.navigate(["employeeregistration/military"]);
    }
}
