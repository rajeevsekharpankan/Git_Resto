import { MenuService } from './../../../_service/menu.service';
import { AppConstants } from './../../../app.constants';
import { AuthService } from './../../../_service/auth.service';
import { CookieService } from 'ngx-cookie-service';
import { UserRegistrationComponent } from './../../../shared/user-registration/user-registration.component';
import { UserService } from './../../../_service/user.service';
import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { EmployeeRegistrationService } from './../../../_service/employee.registration.service';
import { NgForm, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmployeeModel } from './../../../_models/employee.model';
import { JobdoggcommonService } from '../../../shared/jobdoggcommon.service';

@Component({
  selector: 'app-registration-select-ride',
  templateUrl: './registration-select-ride.component.html',
  styleUrls:['./registration-select-ride.component.css'],
  providers: [UserService],

})
export class RegistrationSelectRideComponent implements OnInit {
  @ViewChild("userreg") userreg: UserRegistrationComponent;
  public _employee: EmployeeModel;
  selectRideForm: FormGroup;
  constructor(
    private _employeeService: EmployeeRegistrationService,
    private _userService: UserService,
    private _authService: AuthService,
    private _cookieService: CookieService,
    private formBuilder: FormBuilder,
    public _menuService: MenuService,
    private _jobdoggservice: JobdoggcommonService
  ) {
    this._employeeService._currentPage = 8;
    this._employee = this._employeeService.employee != null ? this._employeeService.employee : new EmployeeModel();
  }

  ngOnInit() {

  }
  public isLoggedIn: boolean = false;
  public isDataLoaded: boolean = false;
  private authTimeout: number;
  public userData: any;
  public roles: any;
  public isEmployeeType: boolean = false;
  public loggedInUsername: any;
  registrationModalResult: any = null;

  // private createForm() {
  //   this.selectRideForm = this.formBuilder.group({
  //     rideMode: ''
  //   });
  //   console.log("status : " + this.selectRideForm.status);
  // }

  public Next() {
    this._employeeService.CreateNewUser().subscribe((data: any) => {
      debugger;
      var vm = {
        Username: data.ContentData.UserName,
        Password: data.ContentData.Password,
        UserId: data.ContentData.UserId
      };
      var evm = {
        Username: this._employeeService.employee.GuId,
        UserId: data.ContentData.UserId
      };

      this._employeeService.UpdateEmployeeUserId(evm).subscribe((res: any) => {
        console.log(res.ContentData);
      },
    (error:any)=>{
      console.log("error");
    },()=>{
      debugger;
      this._jobdoggservice.userobject.next(vm);
    }
    );

    });

  }
  public SaveTransportMode(selectRideForm: NgForm) {
    this._employee.TransportMode = selectRideForm.controls['TransportMode'].value;
    this._employeeService.SaveEmployeeTransportMode(this._employee).subscribe(result => {
      if (result.ContentData != null) {
        this.Next();
      }
    });
  }
}


