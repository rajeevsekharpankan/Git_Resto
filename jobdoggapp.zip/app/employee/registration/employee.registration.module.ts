import { CommonService } from './../../_service/common.service';
import { NgxPhoneMaskModule } from 'ngx-phone-mask';
import { JobdoggSharedModule } from './../../shared/jobdogg-shared.module';
import { registrationvideouploadedComponent } from './registration-video-uploaded/registration-video-uploaded.component';
import { RegistrationVideoComponent } from './registration-video/registration-video.component';
import { RegistrationPopupComponent } from './registration-popup/registraion-popup.component';
import { NgModule, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { EmployeeSkillsComponent } from './skills/employeeskills.component';
import { registrationeducationComponent } from './registration-education/registration-education.component';
import { registrationexperienceComponent } from './registration-experience/registration-experience.component';
import { registrationpersonalComponent } from './registration-personal/registration-personal.component';
import { ProgressbarComponent } from './progressbar/progressbar.component';
import { EmployeeRegistrationService } from './../../_service/employee.registration.service';
import { BackgroundcheckComponent } from './background-check/background-check.component';
import { RegistrationbasicComponent } from './registration-basic/registration-basic.component';
import { RegistrationprofileComponent } from './registration-profile/registration-profile.component';
import { RegistrationTreatBoxComponent } from './registration-treat-box/registration-treat-box.component';
import { RegistrationSelectRideComponent } from './registration-select-ride/registration-select-ride.component';


//Angular material
import {
  MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogModule,
  MatFormField, MatFormFieldControl, MatFormFieldModule, MatInputModule,
  MatSelectModule, MatSelectionList, MatListOption, MatRippleModule,
  MatPseudoCheckboxModule, MatCheckboxModule, MatCheckbox, MatListItem,
  MatSlideToggleModule,MatDatepickerModule,MatDatepicker,MatNativeDateModule,
  MatRadioModule
} from '@angular/material';
import { MilitaryComponent } from './military/military.component';
import { TextMaskModule } from 'angular2-text-mask';


//import { AuthManager } from '../authManager';

const routes: Routes = [
  { path: 'backgroundcheck', component: BackgroundcheckComponent },
  { path: 'employeebasic', component: RegistrationbasicComponent },
  { path: 'employeepersonal', component: registrationpersonalComponent },
  { path: 'employeeeducation', component: registrationeducationComponent },
  { path: 'employeeexperience', component: registrationexperienceComponent },
  { path: 'employeeskills', component: EmployeeSkillsComponent },
  { path: 'Profile', component: RegistrationprofileComponent },
  { path: 'TreatBox', component: RegistrationTreatBoxComponent },
  { path: 'SelectRide', component: RegistrationSelectRideComponent },
  { path: 'profilevideo', component: RegistrationVideoComponent },
  { path: 'profilevideouploaded', component: registrationvideouploadedComponent },
  { path: 'military', component: MilitaryComponent },
  { path: ':id', component: RegistrationbasicComponent },
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatPseudoCheckboxModule,
    MatRippleModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatDialogModule,
    MatSlideToggleModule,
    NgxPhoneMaskModule,MatDatepickerModule,MatNativeDateModule,
    TextMaskModule,
    MatRadioModule
  ],
  declarations: [
    BackgroundcheckComponent,
    RegistrationbasicComponent,
    ProgressbarComponent,
    registrationpersonalComponent,
    registrationexperienceComponent,
    registrationeducationComponent,
    EmployeeSkillsComponent,
    RegistrationprofileComponent,
    MatSelectionList,
    MatListOption,
    MatListItem, RegistrationPopupComponent,
    RegistrationTreatBoxComponent,
    RegistrationSelectRideComponent,
    RegistrationVideoComponent,
    registrationvideouploadedComponent,
    MilitaryComponent
  ],
  providers: [
    EmployeeRegistrationService,CommonService
  ],
  entryComponents: [
    RegistrationPopupComponent
  ],

})
export class EmployeeRegistrationModule {
}
