import { EmployeeRegistrationService } from './../../../_service/employee.registration.service';
import { Component, OnInit,ViewChild,AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-registration-video-uploaded',
  templateUrl: './registration-video-uploaded.html',
})
export class registrationvideouploadedComponent implements OnInit {
  @ViewChild('video') video: any;
  public profilevideourl: string = "";
  constructor(private _employeeService: EmployeeRegistrationService) {

  }

  ngOnInit() {
    this.profilevideourl = this._employeeService.employee.VideoFilePath;
    
  }
  ngAfterViewInit() {
    //let _video = this.video.nativeElement;
  }
  public submit() {
    this._employeeService._router.navigate(["employeeregistration/TreatBox"]);
  }
}
