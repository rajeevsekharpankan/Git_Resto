import { MilitaryModel } from './../../../_models/employee.model';
import { EmployeeRegistrationService } from './../../../_service/employee.registration.service';
import { Component, OnInit, EventEmitter, HostListener } from '@angular/core';
import { MatSlideToggle } from '@angular/material';
import { jobdoggfile } from '../../../_models/employee.model';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { NgClass } from '@angular/common';

@Component({
    selector: 'app-military',
    templateUrl: './military.component.html',
    styleUrls: ['./military.component.css']
})
export class MilitaryComponent implements OnInit {
    public militarylist: Array<MilitaryModel> = [];
    public military: MilitaryModel;
    public militaryform: FormGroup;
    public formSubmitAttempt: boolean;
    public noItemInList: boolean;
    constructor(private _employeeservice: EmployeeRegistrationService, private formBuilder: FormBuilder) {
        // if (this._employeeservice.employee == null) {
        //     this._employeeservice._router.navigate(["employeeregistration/backgroundcheck"]);
        // }

        this._employeeservice.GetEmployeeMilitaryList(this._employeeservice.employee.GuId).subscribe((data: any) => {
            if (data.ContentData != null) {
                this.militarylist = data.ContentData;
            }
        });
        this.formSubmitAttempt = false;
        this._employeeservice._currentPage = 3;
        this.military = new MilitaryModel();
        this.military.GuId = this._employeeservice.employee.GuId;
        this.military.Crt_By = "PBLC_USR";
    }

    ngOnInit() {
        this.createForm();
    }

    private createForm() {
        this.militaryform = this.formBuilder.group({
            MilitaryBranch: ['', Validators.required],
            Rank: ['', Validators.required],
            DischargeYear: ['', Validators.required],
            ActiveDutyFlag: ['', Validators.required],
            CertificationLicense: ['', Validators.required]
        });
    }

    onFileChange(event) {
        let reader = new FileReader();
        if (event.target.files && event.target.files.length > 0) {
            let file = event.target.files[0];
            reader.readAsDataURL(file);
            reader.onload = () => {
                let jbdoggfile = new jobdoggfile();
                jbdoggfile.filecontent = reader.result;
                jbdoggfile.filename = file.name;
                this.military.Filename = file.name;
                this.military.FileContent = jbdoggfile.filecontent;
            };
        }

    }

    public addMilitryIntoMiltryList() {
        this.formSubmitAttempt = true;
        if (this.militaryform.valid) {
            this.militarylist.push(this.military);
            this.military = new MilitaryModel();
            this.military.GuId = this._employeeservice.employee.GuId;
            this.military.Crt_By = "PBLC_USR";
            this.formSubmitAttempt = false;
            this.militaryform.markAsUntouched()
        }
    }

    public deleteMilitryFromMiltryList(_military: MilitaryModel, index: number) {
        // this.militarylist.splice(index, 1);
        if (_military.EmployeeMillitaryId) {
            _military.IsDeleted = true;
        }
    }

    public saveMilitaryList() {
        if (this.militarylist.length == 0) {
            this.noItemInList = true;
        }
        else {
            this._employeeservice.SaveMilitaryDetails(this.militarylist).subscribe((data: any) => {
                if (data.ContentData != null) {
                    this.next();
                }
            });
        }
    }

    private next() {
        this._employeeservice._router.navigate(["employeeregistration/employeeeducation"]);
    }

    private prev() {
        this._employeeservice._router.navigate(["employeeregistration/employeepersonal"]);
    }

    isFieldValid(field: string) {
        return !this.militaryform.get(field).valid && this.militaryform.get(field).touched ||
            (this.militaryform.get(field).untouched && this.formSubmitAttempt);
    }

    displayFieldCss(field: string) {
        return {
            'requiredvalidation': this.isFieldValid(field)
        };
    }
}
