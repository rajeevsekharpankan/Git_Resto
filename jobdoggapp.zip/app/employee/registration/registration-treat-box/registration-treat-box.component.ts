import { Component, OnInit } from '@angular/core';
import { EmployeeRegistrationService } from './../../../_service/employee.registration.service';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { BankAccountModel } from './../../../_models/employee.model';

@Component({
  selector: 'app-registration-treat-box',
  templateUrl: './registration-treat-box.component.html',
  styleUrls:['./registration-treat-box.component.css']
})
export class RegistrationTreatBoxComponent implements OnInit {
  public bankAccountDetails: BankAccountModel = new BankAccountModel();
  private formSubmitAttempt: boolean;
  treatBox: FormGroup;
  constructor(private _employeeService: EmployeeRegistrationService,
    private formBuilder: FormBuilder) {
    this.getEmployeeBankAccountDetails();
  }

  ngOnInit() {
    this.createForm();
    this.formSubmitAttempt = false;
  }

  private createForm() {
    this.treatBox = this.formBuilder.group({
      BankAccountNumber: ['', Validators.required],
      RoutingNumber: ['', Validators.required],
      CardOrACH: ''
    });
  }

  public SaveBankAccountDetails(paymentFormValues): void {
    this.formSubmitAttempt = true;
    if (this.treatBox.valid) {
      this.bankAccountDetails = {
        GuId : this._employeeService.employee.GuId,
        AccountNumber: paymentFormValues.BankAccountNumber,
        RoutingNumber: paymentFormValues.RoutingNumber,
        CardOrACH: paymentFormValues.CardOrACH ? paymentFormValues.CardOrACH : "ACH"
      }
      this._employeeService.SaveEmployeeBankAccountDetails(this.bankAccountDetails).subscribe(data => {
        this.Next();
      });
    }
  }

  public Next(): void {
    this._employeeService._router.navigate(["employeeregistration/SelectRide"]);
  }

  public getEmployeeBankAccountDetails(): void {
    this._employeeService.GetEmployeeBankAccountDetails(this._employeeService.employee.GuId).subscribe((data: any) => {
      debugger;
      this._employeeService.employee.bankAcountDetails = this.bankAccountDetails = data.ContentData != null ? data.ContentData : {};
    });
  }

  isFieldValid(field: string) {
    return !this.treatBox.get(field).valid && this.treatBox.get(field).touched ||
      (this.treatBox.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'requiredvalidation': this.isFieldValid(field)
    };
  }
}
