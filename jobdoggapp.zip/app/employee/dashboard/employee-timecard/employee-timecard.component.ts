import { Component, OnInit, Injectable, Output, EventEmitter } from '@angular/core';
import { Router } from "@angular/router";
import { EmployeeModel } from "../../../_models/employee.model";

@Component({
    selector: 'employee-timecard',
    templateUrl: './employee-timecard.component.html',
    styleUrls:['./employee-timecard.component.css']
    })

export class EmployeeTimecardComponent implements OnInit {
   
    constructor() {
        
    };
    ngOnInit() {
       
    }
   
}
