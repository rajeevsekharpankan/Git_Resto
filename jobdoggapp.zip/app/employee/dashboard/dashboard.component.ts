import { Component, OnInit } from '@angular/core';
import { EmployeeDashboardService } from './../../_service/employee-dashboard.service'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'], providers: [EmployeeDashboardService]
})
export class DashboardComponent implements OnInit {

  public employee: any = [];
  constructor(private _employeeDashService: EmployeeDashboardService) { }

  ngOnInit() {
    this.getEmployeeDetails();
  }

  public getEmployeeDetails(): void {
    this._employeeDashService.getEmployeeDetails().subscribe(data => {
      if (data.ContentData != null) {
        this.employee = data.ContentData;
        console.log(this.employee);
      }
    });
  }

}
