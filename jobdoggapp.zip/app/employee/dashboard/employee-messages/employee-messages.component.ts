import { Component, OnInit, Injectable, Output, EventEmitter } from '@angular/core';
import { Router } from "@angular/router";
import { EmployeeModel } from "../../../_models/employee.model";

@Component({
    selector: 'employee-messages',
    templateUrl: './employee-messages.component.html',
    styleUrls:['./employee-messages.component.css']
    })

export class EmployeeMessagesComponet implements OnInit {
   
    constructor(private _router:Router) {
        
    };
    ngOnInit() {
       
    }
    public Next() {
        this._router.navigate(["employeeregistration/employeebasic"]);
    }
   
}
