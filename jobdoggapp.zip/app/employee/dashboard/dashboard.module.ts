import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthManager } from './../../authManager';

import { DashboardComponent } from './dashboard.component';
import { EmployeeMessagesComponet } from './employee-messages/employee-messages.component';
import { EmployeeOffersComponent } from './employee-offers/employee-offers.component';
//import { EmployeeTimecardComponent } from './employee-timecard/employee-timecard.component';

const routes: Routes = [
    { path: '', component: DashboardComponent, canActivate: [AuthManager], data: { roles: ['Employee'] } },
    { path: 'Messages', component: EmployeeMessagesComponet, canActivate: [AuthManager], data: { roles: ['Employee'] } },
    { path: 'Offers', component: EmployeeOffersComponent, canActivate: [AuthManager], data: { roles: ['Employee'] } },
   // { path: 'Timecard', component: EmployeeTimecardComponent, canActivate: [AuthManager], data: { roles: ['Employee'] } },
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule
    ],
    declarations: [
        DashboardComponent,
        EmployeeMessagesComponet,
        EmployeeOffersComponent,
        //EmployeeTimecardComponent
    ],
    entryComponents: [],
    providers: [
        AuthManager
    ]
})
export class DashboardModule {

}
