import { Component, OnInit, Injectable, Output, EventEmitter } from '@angular/core';
import { Router } from "@angular/router";
import { EmployeeModel } from "../../../_models/employee.model";

@Component({
    selector: 'employee-offers',
    templateUrl: './employee-offers.component.html',
    styleUrls:['./employee-offers.component.css']
    })

export class EmployeeOffersComponent implements OnInit {
   
    constructor() {
        
    };
    ngOnInit() {
       
    }
   
}
