import { EmployeeComponent } from './employee.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

//import { AuthManager } from '../authManager';


const routes: Routes = [
  { path: '', component: EmployeeComponent }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule
  ],
  declarations: [EmployeeComponent],
  entryComponents: [],
  ////providers: [AuthManager]
})
export class EmployeeModule {
}
