import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPhoneMaskModule } from 'ngx-phone-mask';

import { UserService } from '../../_service/user.service';
import { EmployerBasicComponent } from './employer-basic/employer-basic.component';
import { EmployerRegistrationService } from './../../_service/employer.registration.service';
import { EmployerContactComponent } from './employer-contact/employer-contact.component';
import { EmployerDepartmentModalComponent } from './employer-department-modal/employer-department-modal.component';
import { EmployerPaymentComponent } from './employer-payment/employer-payment.component';
import { MatDialogModule, MatRadioModule, MatCheckboxModule } from '@angular/material';
import { CommonService } from './../../_service/common.service';

const routes: Routes = [
  { path: 'employerbasic', component: EmployerBasicComponent },
  { path: 'employercontact', component: EmployerContactComponent },
  { path: 'employerdepartmentmodal', component: EmployerDepartmentModalComponent },
  { path: 'employerpayment', component: EmployerPaymentComponent }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule, ReactiveFormsModule,
    RouterModule.forChild(routes),
    MatDialogModule,
    MatRadioModule,
    MatCheckboxModule,
    NgxPhoneMaskModule
  ],
  declarations: [
    EmployerBasicComponent,
    EmployerContactComponent,
    EmployerDepartmentModalComponent,
    EmployerPaymentComponent
  ],
  providers: [
    EmployerRegistrationService,
    CommonService
  ],
  entryComponents: [

  ],

})
export class EmployerRegistrationModule {
  constructor(private _userService: UserService) {
    this._userService.setState('registration');
  }
}
