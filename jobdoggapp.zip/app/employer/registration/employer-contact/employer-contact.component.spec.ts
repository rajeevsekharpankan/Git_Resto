import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployerContactComponent } from './employer-contact.component';

describe('EmployerContactComponent', () => {
  let component: EmployerContactComponent;
  let fixture: ComponentFixture<EmployerContactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployerContactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployerContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
