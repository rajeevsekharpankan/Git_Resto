import { ActivatedRoute } from '@angular/router';
import { EmployeeRegistrationService } from './../../../_service/employee.registration.service';
import { EmployerRegistrationService } from './../../../_service/employer.registration.service';
import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms'
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { EmployeeModel } from '../../../_models/employee.model';
import { EmployerModel, EmployerContact, EmployerContactList, EmployerDeptList, EmployerDepartment } from '../../../_models/employer.model';
import { FileUploadService } from './../../../_service/file-upload.service';
import { EmployerDepartmentModalComponent } from '../employer-department-modal/employer-department-modal.component';
import { NgClass } from '@angular/common';
import { AppConstants } from './../../../app.constants';

@Component({
  selector: 'app-employer-contact',
  templateUrl: './employer-contact.component.html',
  styleUrls: ['./employer-contact.component.css']
})
export class EmployerContactComponent implements OnInit {
  private uploadFileLoc: string = '';
  private imageName: string;
  private file: any;
  employerDepartmentModalResult: any = null;
  employerContactform: FormGroup;
  public contactValidationError: boolean;
  public departmentValidationError: boolean;
  public isContactImageUploaded: boolean;

  public _employerContactsList: EmployerContactList = new EmployerContactList();;
  public _employerContact: EmployerContact = new EmployerContact();

  public _employerDeptsList: EmployerDeptList = new EmployerDeptList();;
  public _employerDept: EmployerDepartment = new EmployerDepartment();

  constructor(private _employerService: EmployerRegistrationService,
    private _route: ActivatedRoute, public dialog: MatDialog,
    private _fileUploadService: FileUploadService,
    private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.createForm();
    this._employerContactsList.ContactList = new Array<EmployerContact>();
    this._employerDeptsList.DeptList = new Array<EmployerDepartment>();
    this.getContactsList();
    this.getDeptsList();
  }

  private createForm() {
    this.employerContactform = this.formBuilder.group({
      title: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      phone: ['', Validators.required],
      email: ['', Validators.compose([Validators.required, Validators.email])]
    });
  }

  departmentModal(dept) {
    let departmentModal = this.dialog.open(EmployerDepartmentModalComponent, { data: dept });
    departmentModal.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.getDeptsList();
    });
  }

  public getContactsList() {
    this._employerService.GetEmployerContactDetails(this._employerService.employer.EmployerGuid).subscribe((data: any) => {
      this._employerContactsList = data.ContentData != null ? data.ContentData : new EmployerContactList();
    });
  }

  public getDeptsList() {
    this._employerService.GetEmployerDepartmenttDetails(this._employerService.employer.EmployerGuid).subscribe((data: any) => {
      this._employerDeptsList = data.ContentData != null ? data.ContentData : new EmployerDeptList();
    });
  }

  public AddContact() {
    this.contactValidationError = false;
    if (this.employerContactform.valid == false || !this.isContactImageUploaded) {
      this.contactValidationError = true;
    }
    else {
      this._employerContact.EmployerContactId = 0;
      this._employerContact.EmployerGuid = this._employerService.employer.EmployerGuid;
      this._employerContact.Status = 'Active';
      this._employerContact.ContactPhoto = this.uploadFileLoc;
      this._employerService.saveEmployerContacts(this._employerContact).subscribe((data: any) => {
        let result = data.ContentData;
        this._employerContact.EmployerContactId = result as number;
        this._employerContactsList.ContactList.push(this._employerContact);
        this._employerContact = new EmployerContact();
        this.uploadFileLoc = '';
      })
    }

  }

  public AddDepartment() {
    this.departmentValidationError = false;
    if (this._employerDept.DepartmentName == undefined || this._employerDept.DepartmentName == "") {
      this.departmentValidationError = true;
    }
    else {
      this._employerDept.EmployerGuid = this._employerService.employer.EmployerGuid;
      this._employerService.SaveEmployerDept(this._employerDept).subscribe((data: any) => {
        let result = data.ContentData;
        this._employerDept.Status = 'Active';
        this._employerDept.EmployerDepartmentId = result as number;
        this._employerDeptsList.DeptList.push(this._employerDept);
        this._employerDept = new EmployerDepartment();
        this.departmentValidationError = false;
      })
    }
  }

  public RemoveDepartment(dept) {
    dept.Status = 'InActive';
    this._employerService.RemoveEmployerDept(dept).subscribe((data: any) => {
      let result = data.ContentData;
    })
  }

  public submitContacts() {
    if (this._employerContactsList.ContactList.length > 0) {
      this._employerService._router.navigate(["employerregistration/employerpayment"]);
    }
  }

  public uploadFile(): void {
    let errors = [];
    if (this.file.length == 1) {
      var formData = new FormData();
      formData.append("profilePic", this.file[0], this.file[0].name);
      this._employerService.SaveEmployerContactPic(formData, this._employerService.employer.EmployerGuid)
        .subscribe(
        successDate => {
          let imagePath = successDate.ContentData;
          this.uploadFileLoc = AppConstants.WebContents + "/" + imagePath ; 
          this.isContactImageUploaded=true;
        },
        error => {
          console.log(error);
          errors.push(error.ExceptionMessage);
        })
    }
  }

  public onFileChange(_event): void {
    this.file = _event.target.files;
    this.imageName = this.file[0].name;
  }

}
