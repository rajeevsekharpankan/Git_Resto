import { ActivatedRoute } from '@angular/router';
import { EmployeeRegistrationService } from './../../../_service/employee.registration.service';
import { EmployerRegistrationService } from './../../../_service/employer.registration.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms'
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { EmployeeModel } from '../../../_models/employee.model';
import { EmployerModel, CompanyVideofile, EmployerHOP } from '../../../_models/employer.model';
import { FileUploadService } from './../../../_service/file-upload.service';
//import * as RecordRTC from 'recordrtc';
import { NgClass } from '@angular/common';
import { CommonService } from './../../../_service/common.service';
import { AppConstants } from './../../../app.constants';

@Component({
    selector: 'employer-basic',
    templateUrl: './employer-basic.html',
    styleUrls: ['./employer-basic.component.css']
})
export class EmployerBasicComponent implements OnInit {
    stream: MediaStream; recordRTC: any;
    //public audiovideourl: string = "";
    //public profilevdo: CompanyVideofile;
    //@ViewChild('video') video: any;
    //public Recordtext: string = "";
    private videoFile: any;
    private videoName: string = "";
    private uploadVideoLoc: string = '';
    public isVideoUploaded: boolean = false;
    private video: string = "";

    private uploadFileLoc: string = '';
    private imageName: string;
    private file: any;
    private image: string = "";
    employerBasicform: FormGroup;
    public validationError: boolean;
    public NormalHopError: boolean;
    public WeekendHopError: boolean;
    public isLogoUploaded: boolean = false;

    public states: State[];
    public _employer: EmployerModel;
    public _employerModel: EmployerModel;
    constructor(private _employerService: EmployerRegistrationService,
        private _commonservice: CommonService,
        private _route: ActivatedRoute,
        private _fileUploadService: FileUploadService,
        private formBuilder: FormBuilder) {
        this._employerModel = this._employerService.employer != null ? this._employerService.employer : new EmployerModel();
        this._employerModel.Hop = new EmployerHOP();
        this.uploadFileLoc = this._employerService.employer != null ? this._employerService.employer.CompanyLogoPath : "";
        let img = this.uploadFileLoc != null ? this.uploadFileLoc.split('_') : "";
        this.imageName = img[1];
    }

    ngOnInit() {
        this.createForm();
        //this.Recordtext = "REC";
        this.fillStates();
    }

    fillStates() {
        this._commonservice.GetStates()
            .subscribe((data: any) => {
                this.states = data.ContentData;
            });
    }
    private createForm() {
        this.employerBasicform = this.formBuilder.group({
            companyName: ['', Validators.required],
            addressline1: ['', Validators.required],
            addressline2: ['', Validators.required],
            city: ['', Validators.required],
            state: ['', Validators.required],
            telePhone: ['', Validators.required],
            normalHOPFrom: ['', Validators.required],
            normalHOPTo: ['', Validators.required],
            weekendHOPFrom: ['', Validators.required],
            weekendHOPTo: ['', Validators.required],
            // normalHOPFromZone: ['', Validators.required],
            // normalHOPToZone: ['', Validators.required],
            // weekendHOPFromZone: ['', Validators.required],
            // weekendHOPToZone: ['', Validators.required],
            normalSunday: [null],
            normalMonday: [null],
            normalTuesday: [null],
            normalWednesday: [null],
            normalThursday: [null],
            normalFriday: [null],
            normalSaturday: [null],
            weekendSunday: [null],
            weekendMonday: [null],
            weekendTuesday: [null],
            weekendWednesday: [null],
            weekendThursday: [null],
            weekendFriday: [null],
            weekendSaturday: [null]
        });
        console.log("status : " + this.employerBasicform.status);
    }

    public onFileChange(_event): void {
        this.file = _event.target.files;
        this.imageName = this.file[0].name;
        this.uploadFile();
    }

    public uploadFile(): void {
        if (this.file.length == 1) {
            var myReader: FileReader = new FileReader();
            myReader.readAsDataURL(this.file[0]);
            myReader.onloadend = (e) => {
                this.image = myReader.result;
            }
            this.isLogoUploaded = true;
        }
    }


    public submitbasic() {
        this.validationError = false;
        if (this.employerBasicform.status == 'INVALID' || !this.isLogoUploaded || !this.validateTime() ||!this.isVideoUploaded) {
            this.validationError = true;
        }
        else {
            let employer = this._employerService.employer != null ? this._employerService.employer : new EmployerModel();
            employer.CompanyName = this._employerModel.CompanyName;
            employer.AddressLine1 = this._employerModel.AddressLine1;
            employer.AddressLine2 = this._employerModel.AddressLine2;
            employer.City = this._employerModel.City;
            employer.State = this._employerModel.State;
            employer.TelePhone = this._employerModel.TelePhone;
            employer.CompanyLogoPath = this.uploadFileLoc;
            employer.CompanyVideoFilePath = this.uploadVideoLoc;
            employer.NormalHOPFrom = this.convertTimeFormat(this._employerModel.NormalHOPFrom); //+ ' ' + this._employerModel.NormalHOPFromZone;
            employer.NormalHOPTo = this.convertTimeFormat(this._employerModel.NormalHOPTo);//+ ' ' + this._employerModel.NormalHOPToZone;
            employer.WeekendHOPFrom = this.convertTimeFormat(this._employerModel.WeekendHOPFrom); //+ ' ' + this._employerModel.WeekendHOPFromZone;
            employer.WeekendHOPTo = this.convertTimeFormat(this._employerModel.WeekendHOPTo);//+ ' ' + this._employerModel.WeekendHOPToZone;
            employer.Hop = this._employerModel.Hop;
            this._employerService.employer = this._employerService.employer != null ? this._employerService.employer : employer;
            this._employerService.saveEmployerBasicDetails(employer).subscribe((data: any) => {

                let result = data.ContentData;
                this._employerService.employer.EmployerGuid = result as string;
                if (this._employerService.employer.EmployerGuid != "") {
                    this.saveCompanyLogo();
                }
            })
        }
    }

    public saveCompanyLogo() {
        let errors = [];
        var formData = new FormData();
        formData.append("companyLogo", this.file[0], this.file[0].name);
        this._employerService.saveCompanyLogo(formData, this._employerService.employer.EmployerGuid)
            .subscribe(
            successDate => {
                this.uploadFileLoc = successDate.ContentData;
                if (this.uploadFileLoc != "" || this.uploadFileLoc != undefined) {
                    this.saveCompanyVideo();
                }
            },
            error => {
                console.log(error);
                errors.push(error.ExceptionMessage);
            })
    }

    public validateTime(): boolean {
        let flag: boolean = false;
        let normalFlag: boolean;
        let weekendFlag: boolean;
        if (this._employerModel.NormalHOPFrom < this._employerModel.NormalHOPTo) {
            normalFlag = true;
            this.NormalHopError = false;
        }
        else {
            normalFlag = false;
            this.NormalHopError = true;
        }
        if (this._employerModel.WeekendHOPFrom < this._employerModel.WeekendHOPTo) {
            weekendFlag = true;
            this.WeekendHopError = false;
        }
        else {
            weekendFlag = false;
            this.WeekendHopError = true;
        }
        if (normalFlag && weekendFlag) {
            flag = true;
        }
        return flag;
    }

    public convertTimeFormat(time) {  
        time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)?$/) || [time];
        
          if (time.length > 1) { // If time format correct
            time = time.slice (1);  // Remove full string match value
            time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
            time[0] = +time[0] % 12 || 12; // Adjust hours
          }
          return time.join ('');
    }

    public onVideoFileChange(_videoEvent): void {
        this.videoFile = _videoEvent.target.files;
        this.videoName = this.videoFile[0].name;
        this.videoUpload();
    }

    public videoUpload(): void {
        if (this.videoFile.length == 1) {
            var myVideoReader: FileReader = new FileReader();
            myVideoReader.readAsDataURL(this.videoFile[0]);
            myVideoReader.onloadend = (e) => {
                this.video = myVideoReader.result;
            }
            this.isVideoUploaded = true;
        }
    }

    public saveCompanyVideo(){
        let errors = [];
        var formData = new FormData();
        formData.append("companyLogo", this.videoFile[0], this.videoFile[0].name);
        this._employerService.saveCompanyVideo(formData, this._employerService.employer.EmployerGuid)
            .subscribe(
            successDate => {
                this.uploadVideoLoc = successDate.ContentData;
                if (this.uploadVideoLoc != "" || this.uploadVideoLoc != undefined) {
                    this._employerService._router.navigate(["employerregistration/employercontact"]);
                }
            },
            error => {
                console.log(error);
                errors.push(error.ExceptionMessage);
            })
    }


}

export class State {
    constructor(public id: string, public name: string) { }
}