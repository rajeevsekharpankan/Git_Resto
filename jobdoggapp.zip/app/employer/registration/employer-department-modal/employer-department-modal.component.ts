import { ActivatedRoute } from '@angular/router';
import { EmployerRegistrationService } from './../../../_service/employer.registration.service';
import { Component, OnInit, Inject } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms'
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { EmployerModel, EmployerDepartment } from '../../../_models/employer.model';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from './../../../_service/common.service';
import { AppConstants } from './../../../app.constants';

@Component({
    selector: 'employer-department-modal',
    templateUrl: './employer-department-modal.component.html',
    styleUrls: ['./employer-department-modal.component.css']
})
export class EmployerDepartmentModalComponent implements OnInit {

    public _employerDept: EmployerDepartment = new EmployerDepartment();
    employerDeptform: FormGroup;
    public deptValidationError: boolean;
    public states: State[];
    private videoFile: any;
    private videoName: string = "";
    private uploadedVideoLoc: string = '';
    public isDeptVideoUploaded: boolean;
    private video: string = "";

    constructor(private _employerService: EmployerRegistrationService,
        private _commonservice: CommonService,
        public thisModalRef: MatDialogRef<EmployerDepartmentModalComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any,
        private formBuilder: FormBuilder) {
    }

    ngOnInit() {
        this.createForm();
        this._employerDept = this.data;
        if(this._employerDept.VideoFilePath!=''
         && this._employerDept.VideoFilePath!=null
         && this._employerDept.VideoFilePath!=undefined){
            this.video=this._employerDept.VideoFilePath;
        }       
        this.fillStates();
    }

    fillStates() {
        this._commonservice.GetStates()
            .subscribe((data: any) => {
                this.states = data.ContentData;
            });
    }
    private zippattern = "^[0-9]{5}(?:-[0-9]{4})?$";
    private createForm() {
        this.employerDeptform = this.formBuilder.group({
            headOfDepartment: ['', Validators.required],
            addressLine1: ['', Validators.required],
            addressLine2: ['', Validators.required],
            city: ['', Validators.required],
            state: ['', Validators.required],
            zip: ['', Validators.compose([Validators.required, Validators.pattern(this.zippattern)])],
            email: ['', Validators.compose([Validators.required, Validators.email])],
            phone: ['', Validators.required]
        });
    }

    public submitDept() {
        this.deptValidationError = false;
        if (this.employerDeptform.status == 'INVALID' || !this.isDeptVideoUploaded) {
            this.deptValidationError = true;
        }
        else {
            this.uploadDeptVideo();
        }
    }

    public onVideoFileChange(_videoEvent): void {
        this.videoFile = _videoEvent.target.files;
        this.videoName = this.videoFile[0].name;
        this.videoUpload();
    }

    public videoUpload(): void {
        if (this.videoFile.length == 1) {
            var myVideoReader: FileReader = new FileReader();
            myVideoReader.readAsDataURL(this.videoFile[0]);
            myVideoReader.onloadend = (e) => {
                this.video = myVideoReader.result;
            }
            this.isDeptVideoUploaded = true;
        }
    }

    public uploadDeptVideo() {
        let errors = [];
        var formData = new FormData();
        formData.append("companyLogo", this.videoFile[0], this.videoFile[0].name);
        this._employerService.saveDepartmentVideo(formData, this._employerService.employer.EmployerGuid)
            .subscribe(
            successDate => {
                let videoPath = successDate.ContentData;
                this.uploadedVideoLoc = AppConstants.WebContents + "/" + videoPath;
                this._employerDept.VideoFilePath = this.uploadedVideoLoc;
                this._employerService.UpdateEmployerDept(this._employerDept).subscribe((data: any) => {
                    let result = data.ContentData;
                    this.close();
                })
            },
            error => {
                console.log(error);
                errors.push(error.ExceptionMessage);
            })
    }

    close() {
        this.thisModalRef.close('Test Data from model');
    }

}

export class State {
    constructor(public id: string, public name: string) { }
}