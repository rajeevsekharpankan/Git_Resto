import { ActivatedRoute } from '@angular/router';
import { EmployerRegistrationService } from './../../../_service/employer.registration.service';
import { Component, OnInit } from '@angular/core';
import { NgForm, FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { EmployerModel, EmployerPayment } from '../../../_models/employer.model';
import { MatRadioModule, MatCheckboxModule } from '@angular/material';

@Component({
    selector: 'employer-payment',
    templateUrl: './employer-payment.component.html',
    styleUrls: ['./employer-payment.component.css']
})
export class EmployerPaymentComponent implements OnInit {

    public _employerPayment: EmployerPayment;
    employerPaymentform: FormGroup;
    public paymentValidationError: boolean = false;
    constructor(private _employerService: EmployerRegistrationService,
        private _route: ActivatedRoute,
        private formBuilder: FormBuilder) {
    }

    ngOnInit() {
        this.createForm();
        this._employerPayment = new EmployerPayment();
    }

    private createForm() {
        this.employerPaymentform = this.formBuilder.group({
            paymentType: [null, Validators.required],
            nameOfBank: [null],
            accountNumber: [null],
            routingNumber: [null],
            manualDescription: [null],
            nameOnCard: [null],
            cardNumber: [null],
            cardExpiry: [null],
            csv: [null],
            isCheckingAccount: [null]
        });

        this.employerPaymentform.get('paymentType').valueChanges.subscribe(value => {
            this.clearValidations();
            if (value == 'Automatic ACH Payment') {
                this.employerPaymentform.controls['nameOfBank'].setValidators(Validators.required);
                this.employerPaymentform.controls['accountNumber'].setValidators(Validators.required);
                this.employerPaymentform.controls['routingNumber'].setValidators(Validators.required);
            }
            if (value == 'Manual Wire Transfer') {
                this.employerPaymentform.controls['manualDescription'].setValidators(Validators.required);
            }

            if (value == 'Credit Card Payment') {
                this.employerPaymentform.controls['nameOnCard'].setValidators(Validators.required);
                this.employerPaymentform.controls['cardNumber'].setValidators(Validators.required);
                this.employerPaymentform.controls['cardExpiry'].setValidators(Validators.required);
                this.employerPaymentform.controls['csv'].setValidators(Validators.required);
            }
            this.updateValidations();
        });
    }

    public clearValidations() {
        this.employerPaymentform.controls['nameOfBank'].clearValidators();
        this.employerPaymentform.controls['accountNumber'].clearValidators();
        this.employerPaymentform.controls['routingNumber'].clearValidators();
        this.employerPaymentform.controls['manualDescription'].clearValidators();
        this.employerPaymentform.controls['nameOnCard'].clearValidators();
        this.employerPaymentform.controls['cardNumber'].clearValidators();
        this.employerPaymentform.controls['cardExpiry'].clearValidators();
        this.employerPaymentform.controls['csv'].clearValidators();
    }

    public updateValidations(){
        this.employerPaymentform.controls['nameOfBank'].updateValueAndValidity();
        this.employerPaymentform.controls['accountNumber'].updateValueAndValidity();
        this.employerPaymentform.controls['routingNumber'].updateValueAndValidity();
        this.employerPaymentform.controls['manualDescription'].updateValueAndValidity();
        this.employerPaymentform.controls['nameOnCard'].updateValueAndValidity();
        this.employerPaymentform.controls['cardNumber'].updateValueAndValidity();
        this.employerPaymentform.controls['cardExpiry'].updateValueAndValidity();
        this.employerPaymentform.controls['csv'].updateValueAndValidity();
    }

    public submitPayment() {
        this.paymentValidationError = false;
        this.employerPaymentform.updateValueAndValidity();
        if (this.employerPaymentform.valid == false) {
            this.paymentValidationError = true;
        }
        else {
            this._employerPayment.EmployerGuid = this._employerService.employer.EmployerGuid;
            this._employerPayment.Status = 'Active';
            this._employerService.UpdateEmployerPayment(this._employerPayment).subscribe((data: any) => {
                let result = data.ContentData;
                this.createUser();
            });
        }
    }

    createUser() {
        this._employerService.CreateNewEmployerUser().subscribe((data: any) => {
            var vm = {
                Username: data.ContentData.UserName,
                Password: data.ContentData.Password,
                UserId: data.ContentData.UserId
            };
            var evm = {
                Username: this._employerService.employer.EmployerGuid,
                UserId: data.ContentData.UserId
            };

            this._employerService.UpdateEmployerUserId(evm).subscribe((res: any) => {
                console.log(res.ContentData);
                this._employerService._router.navigate(["Home"]);
            });

        });
    }

}
