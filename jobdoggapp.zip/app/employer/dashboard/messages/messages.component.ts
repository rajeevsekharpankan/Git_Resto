import { Component, OnInit } from '@angular/core';
import { EmployerDashboardService } from '../../../_service/employer-dashboard.service';
import * as moment from 'moment';
import { debug } from 'util';

@Component({
  selector: 'messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit {

  public messageList: any = [];
  public messageBox: any;
  public radioSelect: number;
  public currentPageNumber: number = 1;
  public totalPageNumber: number = 10;
  public totalNumberOfItems: number = 0;
  public nextPageNumber: number = 2;
  public prevPageNumber: number = 0;
  public itemsPerPage: number = 3;

  constructor(private _employerDashService: EmployerDashboardService) {
    this.messageBox = {
      ToAddress: '',
      Subject: '',
      Body: '',
      isCompose: false
    };
  }

  ngOnInit() {
    this.getMessageList();
  }

  public selectMessage(msgId: number): void {
    this.getEmployerMessageById(msgId);
  }

  public composeMessage(): void {
    this.messageBox = {
      ToAddress: '',
      Subject: '',
      Body: '',
      SendDate: moment().format("MMMM Do, YYYY"),
      isCompose: true
    };
    this.radioSelect = 0;
  }

  public getMessageList(): void {
    let messageData = {
      SearchText: '',
      CurrentPageNumber: this.currentPageNumber,
      ItemsPerPage: this.itemsPerPage
    };
    this._employerDashService.getEmployerMessageList(messageData).subscribe((data: any) => {
      if (data.ContentData != null) {
        this.messageList = data.ContentData.EmployerMessages;
        this.totalNumberOfItems = data.ContentData.Count.MessageCount;
        this.getEmployerMessageById(this.messageList[0].EmployerMessageId);
        this.radioSelect = this.messageList[this.messageList.length - 1].EmployerMessageId;
        this.setPagingation();
      }
    });
  }

  public getEmployerMessageById(msgId: number): void {
    this._employerDashService.getEmployerMessageById(msgId).subscribe((data: any) => {
      this.messageBox = data.ContentData;
      this.messageBox.SendDate = moment(this.messageBox.SendDate).format("MMMM Do, YYYY");
      this.messageBox.isCompose = false;
      this.radioSelect = this.messageBox.EmployerMessageId;
    });
  }

  public navigateToPage(pageNumber: number): void {
    this.currentPageNumber = pageNumber;
    this.getMessageList();
  }

  public setPagingation(): void {
    this.totalPageNumber = Math.ceil(this.totalNumberOfItems / this.itemsPerPage);
    if (this.currentPageNumber <= this.totalPageNumber && this.currentPageNumber > 1) {
      this.nextPageNumber = this.currentPageNumber + 1;
      this.prevPageNumber = this.currentPageNumber - 1;
    }
    else if (this.currentPageNumber <= 1 && this.totalPageNumber > this.currentPageNumber) {
      this.nextPageNumber = this.currentPageNumber + 1;
      this.prevPageNumber = 0;
    }
  }

  public GenerateCount(total, current) {
    // Sample calling: GenerateCountLabel(120,4);
    // total: Total records
    // current: Current page number
    var PageLimit = 20;
    var pagination = "";
    var PageStart = ((current - 1) * PageLimit) + 1;
    var PageEnd = ((current - 1) * PageLimit) + PageLimit;
    if (total % PageLimit > 0 && total < (current * PageLimit)) {
      PageEnd = ((current - 1) * PageLimit) + (total % PageLimit);
    }
    if (total > 0)
      pagination += "Showing " + PageStart + " to " + PageEnd + " of " + total + " entries";
    return pagination;
  }
}
