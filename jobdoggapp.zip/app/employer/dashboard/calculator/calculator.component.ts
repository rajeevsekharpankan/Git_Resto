import { Component, OnInit } from '@angular/core';
import { EmployerDashboardService } from '../../../_service/employer-dashboard.service';

@Component({
  selector: 'calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {

  private dogList: any = [];
  private dogTypeList: any = []
  constructor(private _employerDashService: EmployerDashboardService) { }

  ngOnInit() {
    this.getDoggList();
    this.getDogTypes();
  }

  public getDoggList() {
    this._employerDashService.getDogList().subscribe((data: any) => {
      if (data.ContentData != null) {
        this.dogList = data.ContentData;
      }
    });
  }

  public getDogTypes() {
    this._employerDashService.getDogTypes().subscribe((data: any) => {
      if (data.ContentData != null) {
        this.dogTypeList = data.ContentData;
      }
    });
  }
}
