import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'snapshot',
  templateUrl: './snapshot.component.html',
  styleUrls: ['./snapshot.component.css']
})
export class SnapshotComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  public someRange: any = 0;
  public mensualidadesConfig: any = {
    step: 1,
    // tooltips: true,
    range: {
      'min': 0,
      '20%': 1,
      '40%': 2,
      '60%': 3,
      '80%': 4,
      'max': 5
    },
    pips: {
      mode: 'steps',
      values: [0, 20, 40, 60, 80, 100],
      stepped: true,
      density: 4
    }
  }

  public modelChanged(newObj: any) {
    // console.log(this.someRange);
  }
}
