import { Component, OnInit } from '@angular/core';
import { _ } from 'underscore';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  private tabModel = {
    isMessageShow: false,
    isTimeCardShow: false,
    isCalculatorShow: false,
    isProfileShow: true,
    isReportShow: false,
    isSnapShotShow: false,
    isJobReqShow: false,
    isBillingShow: false
  }
  constructor() {
  }

  public tabChange(_event: any) {
    let tabModel = this.tabModel;
    switch (_event.tab.textLabel) {
      case 'Profile': {
        _.map(tabModel, function (value, key) { tabModel[key] = false; });
        this.tabModel.isProfileShow = true;
        break;
      }
      case 'Job Req.': {
        _.map(tabModel, function (value, key) { tabModel[key] = false; });
        this.tabModel.isJobReqShow = true;
        break;
      }
      case 'Timecard': {
        _.map(tabModel, function (value, key) { debugger; tabModel[key] = false; });
        this.tabModel.isTimeCardShow = true;
        break;
      }
      case 'Messages': {
        _.map(tabModel, function (value, key) { return tabModel[key] = false; });
        this.tabModel.isMessageShow = true;
        break;
      }
      case 'Snapshot': {
        _.map(tabModel, function (value, key) { tabModel[key] = false; });
        this.tabModel.isSnapShotShow = true;
        break;
      }
      case 'Reports': {
        _.map(tabModel, function (value, key) { tabModel[key] = false; });
        this.tabModel.isReportShow = true;
        break;
      }
      case 'Billing': {
        _.map(tabModel, function (value, key) { tabModel[key] = false; });
        this.tabModel.isBillingShow = true;
        break;
      }
      case 'Calculator': {
        _.map(tabModel, function (value, key) { tabModel[key] = false; });
        this.tabModel.isCalculatorShow = true;
        break;
      }
      default: {
        _.map(this.tabModel, function (value, key) { this.tabModel[key] = false; });
        break;
      }
    }
  }

  ngOnInit() {
  }

}
