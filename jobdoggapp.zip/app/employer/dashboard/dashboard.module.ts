import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTabsModule, MatDatepickerModule, MatNativeDateModule, MatSliderModule } from '@angular/material';
import { NouisliderModule } from 'ng2-nouislider';
import { ChartsModule } from 'ng2-charts';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { NgxPhoneMaskModule } from 'ngx-phone-mask';
import {MatSelectModule} from '@angular/material/select';

import { CommonService } from './../../_service/common.service';
import { AuthManager } from '../../authManager';

import { DashboardComponent } from './dashboard.component';
import { CalculatorComponent } from './calculator/calculator.component';
import { TimecardComponent } from './timecard/timecard.component';
import { MessagesComponent } from './messages/messages.component';
import { ProfileComponent } from './profile/profile.component';
import { SnapshotComponent } from './snapshot/snapshot.component';
import { ReportsComponent } from './reports/reports.component';
import { DoughnutChartComponent } from '../../shared/charts/doughnut-chart/doughnut-chart.component';
import { BarChartComponent } from '../../shared/charts/bar-chart/bar-chart.component';
import { PieChartComponent } from '../../shared/charts/pie-chart/pie-chart.component';
import { JobreqComponent } from './jobreq/jobreq.component';
import { BillingComponent } from './billing/billing.component';

const routes: Routes = [
  { path: '', component: DashboardComponent, canActivate: [AuthManager], data: { roles: ['Employer'] } }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    NouisliderModule,
    ChartsModule,
    MatSliderModule,
    MatCheckboxModule,
    MatRadioModule,
    NgxPhoneMaskModule,
    MatSelectModule
  ],
  declarations: [
    DashboardComponent,
    CalculatorComponent,
    TimecardComponent,
    MessagesComponent,
    ProfileComponent,
    SnapshotComponent,
    ReportsComponent,
    DoughnutChartComponent,
    BarChartComponent,
    PieChartComponent,
    JobreqComponent,
    BillingComponent
  ],
  entryComponents: [],
  providers: [
    AuthManager,
    CommonService
  ]
})
export class DashboardModule {

}
