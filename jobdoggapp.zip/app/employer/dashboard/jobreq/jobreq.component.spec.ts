import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobreqComponent } from './jobreq.component';

describe('JobreqComponent', () => {
  let component: JobreqComponent;
  let fixture: ComponentFixture<JobreqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobreqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobreqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
