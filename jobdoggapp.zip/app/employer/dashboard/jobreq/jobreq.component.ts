import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonService } from './../../../_service/common.service';
import { JobRequestModel } from './../../../_models/job-request.model';

@Component({
  selector: 'jobreq',
  templateUrl: './jobreq.component.html',
  styleUrls: ['./jobreq.component.css']
})
export class JobreqComponent implements OnInit {
  private postJobForm: FormGroup;
  private formSubmitAttempt: boolean;
  public jobTitles: any = [];
  public requiredCertifications: any = [];
  public jobLanguages: any = [];
  public jobRequest: JobRequestModel = new JobRequestModel();
  constructor(
    private builder: FormBuilder,
    private commonService: CommonService
  ) {
    this.commonService.getApplicationDropdowns("JobTitle").subscribe(data => {
      if (data.ContentData != null) {
        this.jobTitles = data.ContentData;
      }
    });

    this.commonService.getApplicationDropdowns("CertReq").subscribe(data => {
      if (data.ContentData != null) {
        this.requiredCertifications = data.ContentData;
      }
    });

    this.commonService.getApplicationDropdowns("JobLang").subscribe(data => {
      if (data.ContentData != null) {
        this.jobLanguages = data.ContentData;
      }
    });

    this.createForm();
  }

  ngOnInit() {
    this.formSubmitAttempt = false;
  }

  private createForm() {
    this.postJobForm = this.builder.group({
      'res-days': [null, [Validators.required]],
      'res-hours': [null],
      'res-minutes': [null],
      'job-title': [null, [Validators.required]],
      description: [null, [Validators.required]],
      'certifications-required': [null, [Validators.required]],
      language: [null, [Validators.required]],
      sunday: [null],
      monday: [null],
      tuesday: [null],
      wednesday: [null],
      thursday: [null],
      friday: [null],
      saturday: [null],
      'hour-from': [null, [Validators.required]],
      'minutes-from': [null],
      'ampm-from': [null, [Validators.required]],
      'hour-to': [null, [Validators.required]],
      'minutes-to': [null],
      'ampm-to': [null, [Validators.required]],
      'location': [null, [Validators.required]],
      'job-status': [null, [Validators.required]],
      duration: [null, [Validators.required]],
      'duration-type': [null, [Validators.required]],
      'min-education': [null, [Validators.required]],
      'min-experience': [null, [Validators.required]],
      salary: [null, [Validators.required]],
      'contact-person': [null, [Validators.required]],
      address: [null, [Validators.required]],
      phone: [null, [Validators.required]]
    });
  }

  public postTheJob(values) {
    this.formSubmitAttempt = true;
    debugger;

    if (this.postJobForm.valid) {
    }
  }

  isFieldValid(field: string) {
    return !this.postJobForm.get(field).valid && this.postJobForm.get(field).touched ||
      (this.postJobForm.get(field).untouched && this.formSubmitAttempt);
  }

  displayFieldCss(field: string) {
    return {
      'requiredvalidation': this.isFieldValid(field)
    };
  }
}
