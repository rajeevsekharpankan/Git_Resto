import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'timecard',
  templateUrl: './timecard.component.html',
  styleUrls: ['./timecard.component.css']
})
export class TimecardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
