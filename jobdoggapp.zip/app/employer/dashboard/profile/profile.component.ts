import { Component, OnInit } from '@angular/core';
import { EmployerDashboardService } from './../../../_service/employer-dashboard.service';

@Component({
  selector: 'profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  private employerDetails: any = {};
  private employerContactdetails: any = {};

  constructor(private _employerDashService: EmployerDashboardService) {

  }

  ngOnInit() {
    this.getEmployerDetails();
    this.getEmployerContactDetails();
  }

  public getEmployerDetails() {
    this._employerDashService.getEmployerDetails().subscribe((data: any) => {
      if (data.ContentData != null) {
        this.employerDetails = data.ContentData;
      }
    });
  }

  public getEmployerContactDetails() {
    this._employerDashService.getEmployerContactDetails().subscribe((data: any) => {
      if (data.ContentData != null) {
        this.employerContactdetails = data.ContentData;
      }
    });
  }
}
