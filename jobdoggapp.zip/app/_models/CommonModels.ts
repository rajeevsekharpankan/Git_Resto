import { Injectable } from '@angular/core';
export class State {
    State_Cd: string;
    Comments: string;
    Crt_By: string; Crt_Dt: Date;
    Upd_By: string;
    Upd_Dt: Date;
    Status: string
}
