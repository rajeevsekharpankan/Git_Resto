import { Injectable } from '@angular/core';

export class EmployerModel {

    public EmployerId: number;
    EmployerGuid: string;
    CompanyName: string;
    AddressLine1: string;
    AddressLine2: string;
    City: string;
    State: string;
    TelePhone: number;
    CompanyLogoPath: string;
    CompanyVideoFilePath: string;
    NormalHOPFrom:string;
    NormalHOPTo:string;
    WeekendHOPFrom:string;
    WeekendHOPTo:string;
    NormalHOPFromZone:string;
    NormalHOPToZone:string;
    WeekendHOPFromZone:string;
    WeekendHOPToZone:string;
    CompanyLogo:File;
    Hop:EmployerHOP;
}

export class CompanyVideofile {
    EmployerId: number;
    EmployerGuid: string;
    filecontent: string;
    filename: string;
}

export class EmployerContact{
    EmployerContactId:number;
    EmployerId: number;
    EmployerGuid: string;
    Title:string;
    FirstName:string;
    LastName:string;
    Phone:string;
    Email:string;
    Status:string;
    ContactPhoto:string;
}

export class EmployerContactList{
    EmployerId: number;
    EmployerGuid: string;
    ContactList:Array<EmployerContact>
}

export class EmployerDepartment{
    EmployerDepartmentId:number;
    EmployerId: number;
    EmployerGuid: string;
    DepartmentName:string;
    HeadOfDepartment:string;
    AddressLine1: string;
    AddressLine2: string;
    City: string;
    State: string;
    Zip:number;
    Email:string;
    Phone:string;
    Status:string;
    VideoFilePath:string;
}

export class EmployerDeptList{
    EmployerId: number;
    EmployerGuid: string;
    DeptList:Array<EmployerDepartment>
}

export class EmployerPayment{
    EmployerPaymentId : number;
        EmployerId: number;
        EmployerGuid: string;
        PaymentType:string;
        NameOfBank:string;
        AccountNumber:string;
        RoutingNumber:string;
        IsCheckingAccount:boolean;
        ManualDescription:string;
        NameOnCard:string;
        CardNumber:string;
        CardExpiry:string;
        CSV: number;
        Status:string;        
}

export class EmployerHOP{ 
    EmployerId: number;   
    EmployerGuid: string;
    NormalSunday:boolean;
    NormalMonday:boolean;
    NormalTuesday:boolean;
    NormalWednesday:boolean;
    NormalThursday:boolean;
    NormalFriday:boolean;
    NormalSaturday:boolean;
    WeekendSunday:boolean;
    WeekendMonday:boolean;
    WeekendTueday:boolean;
    WeekendWednesday:boolean;
    WeekendThursday:boolean;
    WeekendFriday:boolean;
    WeekendSaturday:boolean;
}