﻿import { Injectable } from '@angular/core';

export class EmployeeModel {
    /**
     *
     */

    //    private _FirstName : string;
    //    public get FirstName() : string {
    //        return this._FirstName;
    //    }
    //    public set FirstName(v : string) {
    //        this._FirstName = v;
    //    }


    public EmployeeId: number;
    GuId: string;
    FirstName: string;
    MiddleName: string;
    LastName: string;
    AddressLine1: string;
    AddressLine2: string;
    Email: string;
    Zip: number;
    City: string;
    State: string;
    SSN: number;
    WorkPhone: string;
    HomePhone: string;
    EmergencyContact: string;
    DriverLicenseNumber: string;
    NickName: string;
    Dob: Date;
    Ethnicity: string;
    Sex: string;
    CurrentSalary: number;
    CurrentTitle: string;
    ResumeFilePath: string;
    ProfilePhoto: string;
    Description: string;
    DesiredLocation: string;
    DesiredPosition: string;
    EmploymentType: string;
    VideoFilePath: string;
    TransportMode: string;
    UserId: number;
    IsBackgroundCheckVerified: boolean;
    AgreeFlag: boolean;
    SignatureFlag: boolean;
    EverifyFlag: boolean;
    Crt_Dt: Date;
    Crt_By: string;
    Upd_Dt: Date;
    Upd_By: string;
    Status: string;
    Day: string;
    Month: string;
    Year: string;
    educations: Array<EducationModel>;
    companies: Array<CompanyModel>;
    PreferedJobDetails: PreferedJobDetails;
    SelectedSkillList: Array<SkillList>;
    bankAcountDetails: BankAccountModel
}

export class EmployeeUpsert {
    employee: EmployeeModel;
    step: number;
}
export class EducationModel {
    EmployeeId: number;
    EmployeeEductaionId: number;
    EducationType: string;
    EducationDescription: string;
    City: string;
    State: string;
    DateOfGraduation: Date;
    EducationTypeDetail: string;
    day: string;
    month: string
    year: string;
    Status: string;
    Crt_By: string;
}
export class CompanyModel {
    CompanyName: string;
    Crt_By: string;
    EmployeeCompanyId: number;
    EmployeeId: number;
    HireDate: Date;
    LastWorkingDate: Date;
    LenthOfEmployment: string;
    Status: string;
    Tittle: string;
    day: string;
    month: string;
    year: string;
}
export class jobdoggfile {
    EmployeeId: number;
    filecontent: string;
    filename: string;
    Guid: string;
}
export class PreferedJobDetails {
    GuId: string;
    DesiredIndustry: string;
    DesiredPosition: string;
    DesiredSalary: string;
    WorkType: string;
    City: string;
    State: string;
}
export class SkillList {
    EmployeeSkillListId: number;
    SkillId: number;
    SkillName: string;
    Description: string;
    isSelected: boolean;
    GuId: string;
}
export class Skills {
    PreferedJobDetails: PreferedJobDetails;
    SkillList: Array<SkillList>
}
export class BankAccountModel {
    GuId: string;
    AccountNumber: string;
    RoutingNumber: string;
    CardOrACH: string;
}

export class MilitaryModel {
    EmployeeMillitaryId: number;
    EmployeeId: number;
    GuId: string;
    MilitaryBranch: string;
    ActiveDutyFlag: boolean;
    DischargeYear: string;
    Rank: string;
    CertificationLicense: string;
    FilePath: string;
    Status: boolean;
    Filename: string;
    FileContent: string;
    Crt_By: string;
    IsDeleted: boolean;
}
export class CertificateModel {
    EmployeeEducationCertId: number;
    EmployeeId: number;
    CertificationLicense: string;
    Crt_Dt: Date;
    Crt_By: string;
    Upd_Dt: Date;
    Upd_By: string;
    Status: string;
}
