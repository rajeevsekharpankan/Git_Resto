﻿export class MenuModel {
    Title: string;
    Tooltip: string;
    Url: string;
}  