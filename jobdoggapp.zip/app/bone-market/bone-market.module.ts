import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { boneMarketComponent } from './bone-market.component';
import { MarketDetailsComponent } from './market-details/market-details.component';
const routes: Routes = [
    { path: '', component: boneMarketComponent },
    { path: 'MarketDetails', component: MarketDetailsComponent }
];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    declarations: [
        boneMarketComponent,
        MarketDetailsComponent
    ],
    entryComponents: [],
    providers: []
})
export class BoneMarketModule {

}
