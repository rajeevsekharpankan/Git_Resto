import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { MarketDetailsComponent } from './market-details/market-details.component';

@Component({
  selector: 'bone-market',
  templateUrl: './bone-market.component.html',
  styleUrls: ['./bone-market.component.css']
})
export class boneMarketComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit() {
  }
  goToMarketDetails(){
    this._router.navigate(["BoneMarket/MarketDetails"]);
  }
}
