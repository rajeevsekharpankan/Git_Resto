import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'market-details',
  templateUrl: './market-details.component.html',
  styleUrls: ['./market-details.component.css']
})
export class MarketDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
