import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './_service/auth.service';
@Injectable()

export class AuthManager implements CanActivate {
    private userService: any;
    public permissions: any;
    private loadedRoles: any;
    private roles: any;

    constructor(private authService: AuthService, private router: Router) {
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        this.loadedRoles = this.authService.getRoles();
        
        let roles = route.data["roles"] as Array<string>;
        let canLoadRoute: boolean = false;
        let rolesLoaded = false;

        for (var loadedRole in this.loadedRoles) {
            for (var role in roles) {
                if (roles[role].indexOf(this.loadedRoles[loadedRole]) > -1) {
                    canLoadRoute = true;
                    break;
                }
            }
        }
        if (canLoadRoute == false)
            this.router.navigate(['/Home']);
        return canLoadRoute;
    }
}