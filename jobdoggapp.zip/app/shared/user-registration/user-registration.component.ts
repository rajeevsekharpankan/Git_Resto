import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { UserService } from '../../_service/user.service';
import { AuthService } from '../../_service/auth.service';
import { AppConstants } from '../../app.constants';
import { CookieService } from 'ngx-cookie-service';
import { RegistrationModalComponent } from '../../shared/registration-modal/registration-modal.component';
import { MenuService } from '../../_service/menu.service';
import { Subscription } from 'rxjs';
import { JobdoggcommonService } from '../jobdoggcommon.service';

@Component({
    selector: 'app-user-registration',
    templateUrl: './user-registration.component.html',
    styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit, OnDestroy {

    public isLoggedIn: boolean = false;
    public isDataLoaded: boolean = false;
    public isRegistration: boolean = false;
    private authTimeout: number;
    public userData: any;
    public roles: any;
    public isEmployeeType: boolean = false;
    public loggedInUsername: any;
    registrationModalResult: any = null;
    subscription: Subscription;

    constructor(private _userService: UserService
        , private _authService: AuthService
        , private _cookieService: CookieService
        , private _router: Router
        , public dialog: MatDialog
        , public _menuService: MenuService
        , private _jobdoggservice: JobdoggcommonService
    ) {
        this.isDataLoaded = true;
        this.isRegistration = false;
        this.isLoggedIn = !!this._cookieService.get(AppConstants.Jobdogg_AuthToken);
        if (this.isLoggedIn) {
            this.getLoggedInUser();
        }

        this.subscription = this._userService.getState().subscribe(
            registerComponentViewState => {
                if (registerComponentViewState == "registration")
                    this.isRegistration = true;
                else
                    this.isRegistration = false;
            }
        );
        
        this._jobdoggservice.createObservable()
        .subscribe((data)=>{
            debugger;
            console.log(data);
            this.ProcessLogin(data);
        });
        
    }

    ngOnInit() {

    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    registerModal() {
        let registrationModal = this.dialog.open(RegistrationModalComponent, { data: { name: 'TestData' } });
        registrationModal.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
            this.registrationModalResult = result;
        });
    }

    public login(loginForm: NgForm) {
        if (loginForm.valid) {
            var data = {
                Username: loginForm.value.username,
                Password: loginForm.value.password
            };
           this.ProcessLogin(data);
        }
    }

    public getLoggedInUser() {
        this._userService.getLoggedInUser().subscribe((data: any) => {
            if (data.ContentData != null) {
                this.loggedInUsername = data.ContentData.LoggedInUser;
            }
        }, error => {
            if (error) {
                alert(error);
            }
        });
        this.updateNavigation();
    }

    private logout() {
        this._cookieService.delete(AppConstants.Jobdogg_AuthToken);
        this._cookieService.delete(AppConstants.Jobdogg_Role);
        this.isLoggedIn = false;
        this.updateNavigation();
        this._router.navigate(['Home']);
    }

    private updateNavigation() {
        this._menuService.setState('state_changed');
    }

    private ProcessLogin(data: any) {
        this._userService.login(data).subscribe((data: any) => {
            this.isEmployeeType = false;
            if (data.ContentData != null && data.ContentData.IsAuthenticated) {
                this.authTimeout = data.ContentData.TimeOut;
                this._cookieService.set(AppConstants.Jobdogg_AuthToken, data.ContentData.Token, this.authTimeout);
                this._authService.setPermissions(this.authTimeout).then(res => {
                    this.userData = data;
                    this.isLoggedIn = true;
                    this.roles = this._authService.getRoles();
                    for (var a in this.roles) {
                        if (this.roles[a].indexOf('Employee') > -1) {
                            this.isEmployeeType = true;
                            this.isRegistration=false;
                            break;
                        }
                    }
                    this.getLoggedInUser();
                    this.updateNavigation();
                    if (!this.isEmployeeType) {
                        this._router.navigate(['EmployerDashboard']);
                    }
                    else {
                        this._router.navigate(['EmployeeDashboard']);
                    }
                });
            }
            else {
                this.userData = null;
                this.isLoggedIn = false;
                this._cookieService.delete(AppConstants.Jobdogg_AuthToken);
            }
        })
    }
}
