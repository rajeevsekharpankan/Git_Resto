import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { MenuService } from '../../_service/menu.service';
import { MenuModel } from '../../_models/menu.model';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})

export class NavigationComponent implements OnInit, OnDestroy {

  menuItems: MenuModel;
  subscription: Subscription;

  constructor(private _menuService: MenuService) {
    this.subscription = this._menuService.getState().subscribe(
      manuListSate => {
        this.getMenu();
      });
  }

  ngOnInit() {
    this.getMenu();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getMenu() {
    this._menuService.getMenuList().subscribe((data: any) => {
      this.menuItems = data.ContentData;
    });
  }
}
