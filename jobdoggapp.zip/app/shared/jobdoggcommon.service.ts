import { Subject } from 'rxjs/Subject';
import { Injectable } from '@angular/core';

@Injectable()
export class JobdoggcommonService {
public userobject =new Subject<any>();
  constructor() { 

  }
public createObservable(){
  return this.userobject.asObservable();
}
}
