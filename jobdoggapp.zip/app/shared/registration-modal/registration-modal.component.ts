import { Component, OnInit, Inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { UserService } from '../../_service/user.service';


@Component({
  selector: 'app-registration-modal',
  templateUrl: './registration-modal.component.html',
  styleUrls: ['./registration-modal.component.css']
})
export class RegistrationModalComponent implements OnInit {

  constructor(public thisModalRef: MatDialogRef<RegistrationModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router,
    private _userService: UserService
  ) { }

  ngOnInit() {
    console.log(this.data)
  }

  close() {
    this.thisModalRef.close('Test Data from model');
  }

  public EmployeeRegistration() {
    this._userService.setState('registration');
    this.router.navigateByUrl('/employeeregistration/backgroundcheck');
    this.close();
  }

  public EmployerRegistration() {
    this._userService.setState('registration');
    this.router.navigateByUrl('/employerregistration/employerbasic');
    this.close();
  }
}
