import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'doughnut-chart',
  templateUrl: './doughnut-chart.component.html',
  styleUrls: ['./doughnut-chart.component.css']
})
export class DoughnutChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  // Doughnut
  public doughnutChartLabels: string[] = ['Temp', 'Temp-To-Prem', 'Permanent'];
  public doughnutChartData: number[] = [350, 450, 100];
  public doughnutChartType: string = 'doughnut';
  //public innerRadius: string = "20%";
  public doughnutChartOptions: any = {
    cutoutPercentage: "20%"
  };

  // events
  public chartClicked(e: any): void {
    // console.log(e);
  }

  public chartHovered(e: any): void {
    // console.log(e);
  }
}
