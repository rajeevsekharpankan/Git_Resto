import { TestBed, inject } from '@angular/core/testing';

import { JobdoggcommonService } from './jobdoggcommon.service';

describe('JobdoggcommonService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [JobdoggcommonService]
    });
  });

  it('should be created', inject([JobdoggcommonService], (service: JobdoggcommonService) => {
    expect(service).toBeTruthy();
  }));
});
