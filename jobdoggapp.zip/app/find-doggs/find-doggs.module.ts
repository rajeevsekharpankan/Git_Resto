import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatTabsModule, MatSliderModule } from '@angular/material';
import { FindDoggsComponent } from './find-doggs.component';
import { AuthManager } from '../authManager';


const routes: Routes = [
  { path: '', component: FindDoggsComponent }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    MatTabsModule,
    MatSliderModule
  ],
  declarations: [FindDoggsComponent],
  entryComponents: [],
  providers: [AuthManager]
})
export class FindDoggsModule {

}
