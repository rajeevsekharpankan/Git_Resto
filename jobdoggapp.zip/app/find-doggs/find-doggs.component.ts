import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'find-doggs',
  templateUrl: './find-doggs.component.html',
  styleUrls: ['./find-doggs.component.css']
})
export class FindDoggsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
