export class AppConstants {
        //public static serviceEndpoint = 'http://cccsrochester.speridian.com/JobDoggAPI/api/';
        public static serviceEndpoint = 'http://localhost:62480/api/';
        public static Jobdogg_AuthToken = 'JobToken';
        public static Jobdogg_Role = 'Role';
        public static WebContents ="https://jobdogg.speridian.com/jobdoggcontent/";
}