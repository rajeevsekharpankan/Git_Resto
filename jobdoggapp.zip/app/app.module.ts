import { JobdoggSharedModule } from './shared/jobdogg-shared.module';
import { JobdoggcommonService } from './shared/jobdoggcommon.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatDialogModule } from '@angular/material';
import { ChartsModule } from 'ng2-charts';
import { AppComponent } from './app.component';

import { appRoutes } from './app.routes';
import { CookieService } from 'ngx-cookie-service';
import { RequestInterceptor } from './http.interceptor';
import { AuthManager } from './authManager';
import { NavigationComponent } from './shared/navigation/navigation.component';
import { UserRegistrationComponent } from './shared/user-registration/user-registration.component';
import { FooterComponent } from './shared/footer/footer.component';
import { AuthService } from './_service/auth.service';
import { MenuService } from './_service/menu.service';
import { UserService } from './_service/user.service';
import { EmployerDashboardService } from './_service/employer-dashboard.service';
//import { EmployeeDashboardService } from './_service/employee-dashboard.service';
import { FileUploadService } from './_service/file-upload.service';
import { RegistrationModalComponent } from './shared/registration-modal/registration-modal.component';
@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    UserRegistrationComponent,
    FooterComponent,
    RegistrationModalComponent,
  ],
  imports: [
    FormsModule,
    HttpModule,
    RouterModule.forRoot(appRoutes, { useHash: true }),
    BrowserAnimationsModule,
    HttpClientModule,
    MatDialogModule,JobdoggSharedModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: RequestInterceptor,
    multi: true
  }
    , CookieService
    , AuthManager
    , UserRegistrationComponent
    , AuthService
    , EmployerDashboardService
    //, EmployeeDashboardService
    , AuthService
    , MenuService
    , UserService
    , FileUploadService
  ],
  entryComponents: [
    RegistrationModalComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule {

}
