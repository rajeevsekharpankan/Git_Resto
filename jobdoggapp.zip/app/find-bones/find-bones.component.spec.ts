import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindBonesComponent } from './find-bones.component';

describe('FindBonesComponent', () => {
  let component: FindBonesComponent;
  let fixture: ComponentFixture<FindBonesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindBonesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindBonesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
