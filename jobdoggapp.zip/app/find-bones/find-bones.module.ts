import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatTabsModule } from '@angular/material';
import { FindBonesComponent } from './find-bones.component';
import { AuthManager } from '../authManager';


const routes: Routes = [
  { path: '', component: FindBonesComponent }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    MatTabsModule
  ],
  declarations: [FindBonesComponent],
  entryComponents: [],
  providers: [AuthManager]
})
export class FindBonesModule {

}
