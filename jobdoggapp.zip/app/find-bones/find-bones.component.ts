import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-bones',
  templateUrl: './find-bones.component.html',
  styleUrls: ['./find-bones.component.css']
})
export class FindBonesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
