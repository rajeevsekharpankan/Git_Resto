import { Routes, RouterModule } from '@angular/router';

export const appRoutes: Routes = [
  {
    path: '',
    loadChildren: './home/home.module#HomeModule'
  },
  {
    path: 'Home',
    loadChildren: './home/home.module#HomeModule'
  },
  {
    path: 'FindBones',
    loadChildren: './find-bones/find-bones.module#FindBonesModule'
  },
  {
    path: 'employeeregistration',
    loadChildren: './employee/registration/employee.registration.module#EmployeeRegistrationModule'
  },
  
  {
    path: 'EmployeeDashboard',
    loadChildren: './employee/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'EmployerDashboard',
    loadChildren: './employer/dashboard/dashboard.module#DashboardModule'
  },
  {
    path: 'AboutUs',
    loadChildren: './about-us/about-us.module#AboutUsModule'
  },
  {
    path: 'employerregistration',
    loadChildren: './employer/registration/employer.registration.module#EmployerRegistrationModule'
  },
  {
    path: 'BoneMarket',
    loadChildren: './bone-market/bone-market.module#BoneMarketModule'
  },
  {
    path: 'FindDoggs',
    loadChildren: './find-doggs/find-doggs.module#FindDoggsModule'
  },
];
