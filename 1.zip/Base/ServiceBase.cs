﻿//using BrokMartLogger;
using System;

namespace JobDoggApi.Base
{
    public class ServiceBase
    {
        public Token LoggedInUser { get; set; }

        public T ExecuteAction<T>(Func<T> action, string method)
        {
            try
            {
                return action.Invoke();
            }
            catch (Exception ex)
            {
                //BrokLogger.LogException(ex, method, "Public Calls");
                return default(T);
            }
        }

        public T ExecuteServiceAction<T>(Func<T> action, string method, string className)
        {
            try
            {
                return action.Invoke();
            }
            catch (Exception ex)
            {
                //BrokLogger.LogException(ex, method, className);
                throw ex;
            }
        }
    }
}