﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace JobDoggApi.Base
{
    public static class Extensions
    {
        public static Dictionary<string, string> ToDictionary(this string keyValue)
        {
            return keyValue.Split(new[] { '$' }, StringSplitOptions.RemoveEmptyEntries)
                          .Select(part => part.Split('='))
                          .ToDictionary(split => split[0], split => split[1]);
        }
    }
}