﻿using System.Security.Cryptography;
using System.Text;
using System;

namespace JobDoggApi.Base
{
    public static class Encrypt
    {
        /// <summary>
        /// Method to generate salt value for password
        /// </summary>       
        /// <returns>returns salt value for input password </returns>
        public static string GetSalt()
        {
            //generate a random number
            var rnd = new Random();
            var randomNumber = rnd.Next(1, 25);

            //Generate a cryptographic random number.
            var rng = new RNGCryptoServiceProvider();
            var buff = new byte[randomNumber];
            rng.GetBytes(buff);

            // Return a Base64 string representation of the random number.
            return Convert.ToBase64String(buff);
        }

        /// <summary>
        /// Method to generate Hash password
        /// </summary>
        /// <param name="password">password input for registration </param>
        /// <param name="salt">salt value generated for input password</param>
        /// <returns>returns hash password using password and salt value</returns>
        public static string GetHashPassword(string password, string salt)
        {
            // merge password and salt together
            var sHashWithSalt = password + salt;

            // convert this merged value to a byte array
            var saltedHashBytes = Encoding.UTF8.GetBytes(sHashWithSalt);

            // use hash algorithm to compute the hash
            var algorithm = new SHA256Managed();

            // convert merged bytes to a hash as byte array
            var hash = algorithm.ComputeHash(saltedHashBytes);

            // return the has as a base 64 encoded string
            return Convert.ToBase64String(hash);
        }
    }
}