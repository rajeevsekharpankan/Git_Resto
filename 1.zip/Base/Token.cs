﻿using JobDoggApi.Models.DbRepository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace JobDoggApi.Base
{
    /// <summary>
    /// Class that handles the authentication process
    /// </summary>
    public class Token
    {
        /// <summary>
        /// Constructor to initialize the properties
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="userName"></param>
        /// <param name="isAuthenticated"></param>
        /// <param name="roles"></param>
        /// <param name="identifier"></param>
        public Token(int id, string name, string userName, bool isAuthenticated, string roles, string identifier)
        {
            Id = id;
            Name = name;
            UserName = userName;
            Roles = roles;
            IsAuthenticated = isAuthenticated;
            Identifier = identifier;
        }

        /// <summary>
        /// Store the user name
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Stores the user's name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Stores the user name
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Store the roles
        /// </summary>
        public string Roles { get; set; }
        /// <summary>
        /// Store the user is authenticated or not
        /// </summary>
        public bool IsAuthenticated { get; set; }
        /// <summary>
        /// Stores the identifier string
        /// </summary>
        public static string Identifier { get; set; }

        private const string PasswordHash = "P@@Sw0rd";
        private const string SaltKey = "S@LT&KEY";

        public string Encrypt()
        {

            byte[] plainTextBytes = Encoding.UTF8.GetBytes(this.ToString());
            byte[] keyBytes = new Rfc2898DeriveBytes(PasswordHash, Encoding.ASCII.GetBytes(SaltKey)).GetBytes(256 / 8);
            var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.Zeros };
            var encryptor = symmetricKey.CreateEncryptor(keyBytes, Encoding.ASCII.GetBytes(Identifier));

            byte[] cipherTextBytes;

            using (var memoryStream = new MemoryStream())
            {
                using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                {
                    cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                    cryptoStream.FlushFinalBlock();
                    cipherTextBytes = memoryStream.ToArray();
                    cryptoStream.Close();
                }
                memoryStream.Close();
            }
            return Convert.ToBase64String(cipherTextBytes);
        }

        public override string ToString()
        {
            return String.Format("Id={0}$Name={1}$UserName={2}$IsAuthenticated={3}$Roles={4}",
                this.Id, this.Name, this.UserName, this.IsAuthenticated, this.Roles);
        }

        public static Token Decrypt(string encryptedToken)
        {
            try
            {
                byte[] cipherTextBytes = Convert.FromBase64String(HttpUtility.UrlDecode(encryptedToken).Replace(' ', '+'));
                byte[] keyBytes = new Rfc2898DeriveBytes(PasswordHash, Encoding.ASCII.GetBytes(SaltKey)).GetBytes(256 / 8);
                var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.None };
                JD_ADM_Token token = null;
                using (Security db = new Security())
                {
                    token = db.GetToken(encryptedToken);
                    if (token == null)
                        return null;
                }

                var decryptor = symmetricKey.CreateDecryptor(keyBytes, Encoding.ASCII.GetBytes(token.KeyIdentifier));
                var memoryStream = new MemoryStream(cipherTextBytes);
                var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
                var plainTextBytes = new byte[cipherTextBytes.Length];

                int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                memoryStream.Close();
                cryptoStream.Close();
                string decrypted = Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount)
                    .TrimEnd("\0".ToCharArray());

                ////Splitting it to dictionary
                Dictionary<string, string> dictionary = decrypted.ToDictionary();


                return new Base.Token(Convert.ToInt32(dictionary["Id"]),
                    dictionary["Name"], dictionary["UserName"], Convert.ToBoolean(dictionary["IsAuthenticated"]), dictionary["Roles"], token.KeyIdentifier);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }

    public static class Role
    {
        public const string Admin = "Admin";
        public const string Employee = "Employee";
        public const string Employer = "Employer";
    }
}