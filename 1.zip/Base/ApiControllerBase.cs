﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace JobDoggApi.Base
{
    [ApiControllerExceptionFilter]
    public class ApiControllerBase : ApiController
    {
        /// <summary>
        /// Gets the instance of the application service class used by the WebAPI controller.This must be overridden by all the
        /// class which inherits this classes
        /// </summary>
        protected virtual ServiceBase Service
        {
            get
            {
                return null;
            }
        }

        /// <summary>
        /// Object of the class Token where it stores the user data after the login process
        /// </summary>
        protected Token LoggedInUser { get; set; }

        /// <summary>
        /// The asynchronous function which will be executed before each WebAPI requests.
        /// </summary>
        /// <param name="controllerContext">The controller context.</param>
        /// <param name="cancellationToken">The cancellation token.</param>
        /// <returns>result of the operation.</returns>
        public override Task<HttpResponseMessage> ExecuteAsync(
            HttpControllerContext controllerContext,
            CancellationToken cancellationToken)
        {
            try
            {
                //validate the application service instance.
                if (this.Service != null)
                {
                    if (controllerContext.Request.Headers.Contains("X-Token"))
                    {
                        string encryptedToken = controllerContext.Request.Headers.GetValues("X-Token").First();
                        if (!String.IsNullOrEmpty(encryptedToken))
                        {
                            this.LoggedInUser = Token.Decrypt(encryptedToken);
                            this.Service.LoggedInUser = this.LoggedInUser;
                        }
                    }
                }
                return base.ExecuteAsync(controllerContext, cancellationToken)
                   .ContinueWith(task => task)
                       .Unwrap();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

    }
}