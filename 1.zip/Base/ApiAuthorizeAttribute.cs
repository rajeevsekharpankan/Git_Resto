﻿using JobDoggApi.Models.DbRepository;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;

namespace JobDoggApi.Base
{
    public class ApiAuthorizeAttribute : AuthorizeAttribute
    {
        /// <summary>
        /// Array of allowed permissions
        /// </summary>
        public string[] Permissions { get; set; }

        /// <summary>
        /// Calls when an action is being authorized
        /// </summary>
        /// <param name="actionContext">The context.</param>
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            if (Authorized(actionContext))
            {
                return;
            }
            HandleUnauthorizedRequest(actionContext);
        }

        /// <summary>
        /// Called when a process requests authorization.
        /// </summary>
        /// <returns></returns>
        private bool Authorized(HttpActionContext actionContext)
        {
            if (!actionContext.Request.Headers.Contains("x-token"))
            {
                var queryString = actionContext.Request.GetQueryNameValuePairs().ToDictionary(x => x.Key, x => x.Value);
                string encryptedToken;
                queryString.TryGetValue("x-token", out encryptedToken);
                if (string.IsNullOrEmpty(encryptedToken))
                {
                    return false;
                }
                var loggedinUser = Token.Decrypt(HttpUtility.UrlDecode(encryptedToken).Replace(' ', '+'));
                if (loggedinUser != null && CheckUserSessionTimedOut(loggedinUser, encryptedToken) == true)
                    return false;
                else if (loggedinUser == null)
                    return false;
                return loggedinUser.IsAuthenticated && this.IsAuthorized(loggedinUser.Roles.Split(','));

            }
            else
            {
                string encryptedToken = actionContext.Request.Headers.GetValues("X-Token").First();
                if (string.IsNullOrEmpty(encryptedToken)) return false;
                var loggedinUser = Token.Decrypt(encryptedToken);
                if (loggedinUser != null && CheckUserSessionTimedOut(loggedinUser, encryptedToken) == true)
                    return false;
                else if (loggedinUser == null)
                    return false;
                return loggedinUser.IsAuthenticated && this.IsAuthorized(loggedinUser.Roles.Split(','));
            }
        }


        private bool CheckUserSessionTimedOut(Token loggedinUser, string encryptedToken)
        {
            using (Security db = new Security())
            {
                return db.CheckSessionTimeout(loggedinUser.Id, encryptedToken, loggedinUser.Name);
            }
        }
        /// <summary>
        /// Method for evaluated the authorization of logged in user
        /// </summary>
        /// <param name="loggedInUserPermissions">roles of logged in user</param>
        /// <returns>authorization status</returns>
        private bool IsAuthorized(IEnumerable<string> loggedInUserPermissions)
        {
            // if no roles where specified then all authenticated users are authorized
            if (this.Permissions != null)
            {
                return this.Permissions.Length <= 0 || this.Permissions.Any(role => loggedInUserPermissions.Any(userRole => role == userRole));
            }
            return true;

        }
    }
}