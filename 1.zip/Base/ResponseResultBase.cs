﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Base
{
    public class ResponseResultBase
    {
        public string ErrorMessage { get; set; }
        public object ContentData { get; set; }
    }
}