﻿using JobDoggApi.Areas.EmployerManagement.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;
using static JobDoggApi.Models.DbRepository.DbRepository;

namespace JobDoggApi.Models.DbRepository
{
    public class GeneralModules: BaseRepo
    {
        public List<Location> GetLocations(string searchText)
        {
            //SpExecution
            List<Location> lstLocations = new List<Location>();
            return lstLocations;
        }
        public List<JD_ADM_Skills>GetSkills()
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Skills_Select";
                command.CommandType = CommandType.StoredProcedure;
                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                List<JD_ADM_Skills> skills = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_ADM_Skills>(reader).ToList();

                return skills;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }



    }
}