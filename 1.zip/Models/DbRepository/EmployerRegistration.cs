﻿using JobDoggApi.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using static JobDoggApi.Models.DbRepository.DbRepository;
using System.Xml.Linq;
using JobDoggApi.Areas.EmployerRegistration.Model;
using System.Text.RegularExpressions;
using System.IO;
using JobDoggApi.Areas.SecurityManagement.Model;
using JobDoggApi.Base;
using System.Configuration;
using System.Threading.Tasks;

namespace JobDoggApi.Models.DbRepository
{
    public class EmployerRegistration : BaseRepo
    {
        public string Employer_Basic_Info_Insert(EmployerInsert employer)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Basic_Insert";
                command.CommandType = CommandType.StoredProcedure;
                
                command.Parameters.Add(new SqlParameter("@CompanyName", (employer.CompanyName)));
                command.Parameters.Add(new SqlParameter("@AddressLine1", (employer.AddressLine1)));
                command.Parameters.Add(new SqlParameter("@AddressLine2", (employer.AddressLine2)));
                command.Parameters.Add(new SqlParameter("@City", employer.City));
                command.Parameters.Add(new SqlParameter("@State", employer.State));
                command.Parameters.Add(new SqlParameter("@TelePhone", employer.TelePhone));
                command.Parameters.Add(new SqlParameter("@CompanyLogoPath", employer.CompanyLogoPath));
                command.Parameters.Add(new SqlParameter("@CompanyVideoFilePath", employer.CompanyVideoFilePath));
                command.Parameters.Add(new SqlParameter("@NormalHOPFrom", (employer.NormalHOPFrom)));
                command.Parameters.Add(new SqlParameter("@NormalHOPTo", employer.NormalHOPTo));
                command.Parameters.Add(new SqlParameter("@WeekendHOPFrom", employer.WeekendHOPFrom));
                command.Parameters.Add(new SqlParameter("@WeekendHOPTo", employer.WeekendHOPTo));
                command.Parameters.Add(new SqlParameter("@NormalSunday", employer.Hop.NormalSunday));
                command.Parameters.Add(new SqlParameter("@NormalMonday", employer.Hop.NormalMonday));
                command.Parameters.Add(new SqlParameter("@NormalTuesday", employer.Hop.NormalTuesday));
                command.Parameters.Add(new SqlParameter("@NormalWednesday", employer.Hop.NormalWednesday));
                command.Parameters.Add(new SqlParameter("@NormalThursday", employer.Hop.NormalThursday));
                command.Parameters.Add(new SqlParameter("@NormalFriday", employer.Hop.NormalFriday));
                command.Parameters.Add(new SqlParameter("@NormalSaturday", employer.Hop.NormalSaturday));
                command.Parameters.Add(new SqlParameter("@WeekendSunday", employer.Hop.WeekendSunday));
                command.Parameters.Add(new SqlParameter("@WeekendMonday", employer.Hop.WeekendMonday));
                command.Parameters.Add(new SqlParameter("@WeekendTuesday", employer.Hop.WeekendTuesday));
                command.Parameters.Add(new SqlParameter("@WeekendWednesday", employer.Hop.WeekendWednesday));
                command.Parameters.Add(new SqlParameter("@WeekendThursday", employer.Hop.WeekendThursday));
                command.Parameters.Add(new SqlParameter("@WeekendFriday", employer.Hop.WeekendFriday));
                command.Parameters.Add(new SqlParameter("@WeekendSaturday", employer.Hop.WeekendSaturday));
                command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                command.Parameters.Add(new SqlParameter("@Crt_Dt", DateTime.Now));

                _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<Guid>(reader).FirstOrDefault().ToString();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public EmployerContactsList Employer_Contacts_Select(Guid employerGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Contacts_Get";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerGuId));
                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                EmployerContactsList employerContactsList = new EmployerContactsList()
                {
                    EmployerGuId = employerGuId,
                    ContactList = new List<EmployerContact>()
                };
                employerContactsList.ContactList = ((IObjectContextAdapter)_db).ObjectContext.Translate<EmployerContact>(reader).ToList();
                
                return employerContactsList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public int Employer_Contacts_Upsert(EmployerContact employerContact)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Contacts_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@EmployerContactId", employerContact.EmployerContactId));
                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerContact.EmployerGuId));
                command.Parameters.Add(new SqlParameter("@Designation", employerContact.Title));
                command.Parameters.Add(new SqlParameter("@FirstName", employerContact.FirstName));
                command.Parameters.Add(new SqlParameter("@LastName", employerContact.LastName));
                command.Parameters.Add(new SqlParameter("@Phone", employerContact.Phone));
                command.Parameters.Add(new SqlParameter("@Email", employerContact.Email));
                command.Parameters.Add(new SqlParameter("@Status", employerContact.Status));
                command.Parameters.Add(new SqlParameter("@ContactPhoto", employerContact.ContactPhoto));
                command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public EmployerDepartmentList Employer_Departments_Select(Guid employerGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Departments_Get";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerGuId));
                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                EmployerDepartmentList employerDeptList = new EmployerDepartmentList()
                {
                    EmployerGuId = employerGuId,
                    DeptList = new List<EmployerDepartment>()
                };
                employerDeptList.DeptList = ((IObjectContextAdapter)_db).ObjectContext.Translate<EmployerDepartment>(reader).ToList();

                return employerDeptList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public int Employer_Department_Insert(EmployerDepartment employerDepartment)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Department_Insert";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerDepartment.EmployerGuId));
                command.Parameters.Add(new SqlParameter("@DeptName", employerDepartment.DepartmentName));
                command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                command.Parameters.Add(new SqlParameter("@Status", "Active"));
                _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public int Employer_Department_Remove(EmployerDepartment employerDepartment)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Department_Delete";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@EmployerDepartmentId", employerDepartment.EmployerDepartmentId));
                command.Parameters.Add(new SqlParameter("@Status", employerDepartment.Status));
                _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public int Employer_Department_Update(EmployerDepartment employerDepartment)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Department_Update";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@EmployerDepartmentId", employerDepartment.EmployerDepartmentId));
                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerDepartment.EmployerGuId));
                command.Parameters.Add(new SqlParameter("@DeptName", employerDepartment.DepartmentName));
                command.Parameters.Add(new SqlParameter("@HeadOfDepartment", employerDepartment.HeadOfDepartment));
                command.Parameters.Add(new SqlParameter("@AddressLine1", employerDepartment.AddressLine1));
                command.Parameters.Add(new SqlParameter("@AddressLine2", employerDepartment.AddressLine2));
                command.Parameters.Add(new SqlParameter("@City", employerDepartment.City));
                command.Parameters.Add(new SqlParameter("@State", employerDepartment.State));
                command.Parameters.Add(new SqlParameter("@Zip", employerDepartment.Zip));
                command.Parameters.Add(new SqlParameter("@Email", employerDepartment.Email));
                command.Parameters.Add(new SqlParameter("@Phone", employerDepartment.Phone));
                command.Parameters.Add(new SqlParameter("@VideoFilePath", employerDepartment.VideoFilePath));
                command.Parameters.Add(new SqlParameter("@Upd_By", "test"));
                command.Parameters.Add(new SqlParameter("@Status", employerDepartment.Status));
                _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public int Employer_Payment_Upsert(EmployerPayment employerPayment)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Payment_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@EmployerPaymentId", employerPayment.EmployerPaymentId));
                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerPayment.EmployerGuId));
                command.Parameters.Add(new SqlParameter("@PaymentType", employerPayment.PaymentType));
                command.Parameters.Add(new SqlParameter("@NameOfBank", employerPayment.NameOfBank));
                command.Parameters.Add(new SqlParameter("@AccountNumber", employerPayment.AccountNumber));
                command.Parameters.Add(new SqlParameter("@RoutingNumber", employerPayment.RoutingNumber));
                command.Parameters.Add(new SqlParameter("@IsCheckingAccount", employerPayment.IsCheckingAccount));
                command.Parameters.Add(new SqlParameter("@ManualDescription", employerPayment.ManualDescription));
                command.Parameters.Add(new SqlParameter("@NameOnCard", employerPayment.NameOnCard));
                command.Parameters.Add(new SqlParameter("@CardNumber", employerPayment.CardNumber));
                command.Parameters.Add(new SqlParameter("@CardExpiry", employerPayment.CardExpiry));
                command.Parameters.Add(new SqlParameter("@CSV", employerPayment.CSV));
                command.Parameters.Add(new SqlParameter("@Status", employerPayment.Status));
                command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public string Employer_UserId_Upsert(Guid employerGuId, int userid)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_UserId_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerGuId));
                command.Parameters.Add(new SqlParameter("@Userid", userid));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<Guid>(reader).FirstOrDefault().ToString();
                JD_EMR_Employer employer = EmployerDetailSelect(employerGuId);
                List<EmployerContact> employerContactsList = Employer_Contacts_Select(employerGuId).ContactList;
                JD_ADM_UserIdentity userIdentity = SelectUserName(userid);
                foreach(EmployerContact empContact in employerContactsList)
                {
                    SendEmployerMail(userIdentity, empContact.Email, employer.CompanyName);
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }

        }

        public JD_EMR_Employer EmployerDetailSelect(Guid employerGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_Details_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerGuId));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                JD_EMR_Employer employer = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMR_Employer>(reader).FirstOrDefault();

                return employer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public JD_ADM_UserIdentity SelectUserName(int userid)
        {
            try
            {
                //string saltkey = Encrypt.GetSalt();

                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_ADM_UserIdentity_Select_UserName";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@UserId", userid));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                JD_ADM_UserIdentity username = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_ADM_UserIdentity>(reader).FirstOrDefault();

                return username;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public bool SendEmployerMail(JD_ADM_UserIdentity userIdentity, string Toemail,string companyName)
        {
            try
            {
                EmailMessageService email = new EmailMessageService();

                Task.Run(() => email.SendEmployerMail(userIdentity.UserName, "Welcome123", Toemail, companyName));
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        public string Employer_LogoPath_Upsert(Guid employerGuId, string companyLogoPath)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_CompanyLogo_Update";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerGuId));
                command.Parameters.Add(new SqlParameter("@CompanyLogoPath", companyLogoPath));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<Guid>(reader).FirstOrDefault().ToString();                

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }

        }

        public string Employer_CompanyVideoPath_Upsert(Guid employerGuId, string companyVideoPath)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employer_CompanyVideoPath_Update";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@EmployerGuId", employerGuId));
                command.Parameters.Add(new SqlParameter("@CompanyVideoPath", companyVideoPath));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<Guid>(reader).FirstOrDefault().ToString();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }

        }
    }
}