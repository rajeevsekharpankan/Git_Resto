﻿using JobDoggApi.Utilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using static JobDoggApi.Models.DbRepository.DbRepository;



using System.Xml.Linq;
using JobDoggApi.Areas.EmployeeRegistration.Model;
using System.Text.RegularExpressions;
using System.IO;
using JobDoggApi.Areas.SecurityManagement.Model;
using JobDoggApi.Base;
using System.Configuration;
using System.Threading.Tasks;

namespace JobDoggApi.Models.DbRepository
{
    public class EmployeeRegistration : BaseRepo
    {
        public string Employee_Basic_info_Upsert(JD_EMP_Employee employee)
        {
            try
            {
                // string fileGuid = Guid.NewGuid().ToString();
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Basic_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@EmployeeId", employee.EmployeeId));
                command.Parameters.Add(new SqlParameter("@GuId", employee.GuId));
                command.Parameters.Add(new SqlParameter("@FirstName", (employee.FirstName)));
                command.Parameters.Add(new SqlParameter("@MiddleName", (employee.MiddleName)));
                command.Parameters.Add(new SqlParameter("@LastName", (employee.LastName)));
                command.Parameters.Add(new SqlParameter("@AddressLine1", (employee.AddressLine1)));
                command.Parameters.Add(new SqlParameter("@Zip", employee.Zip));
                command.Parameters.Add(new SqlParameter("@City", employee.City));
                command.Parameters.Add(new SqlParameter("@State", employee.State));
                command.Parameters.Add(new SqlParameter("@Email", employee.Email));
                command.Parameters.Add(new SqlParameter("@WorkPhone", employee.WorkPhone));
                command.Parameters.Add(new SqlParameter("@HomePhone", employee.HomePhone));
                command.Parameters.Add(new SqlParameter("@Crt_By", employee.Crt_By));
                // command.Parameters.Add(new SqlParameter("@Phone", employee.Phone));
                command.Parameters.Add(new SqlParameter("@IsBackgroundCheckVerified", employee.IsBackgroundCheckVerified));
                command.Parameters.Add(new SqlParameter("@AgreeFlag", employee.AgreeFlag));
                command.Parameters.Add(new SqlParameter("@SignatureFlag", employee.SignatureFlag));
                command.Parameters.Add(new SqlParameter("@EverifyFlag", employee.EverifyFlag));
                command.Parameters.Add(new SqlParameter("@EmergencyContact", employee.EmergencyContact));

                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open();

                System.Data.Common.DbDataReader reader = command.ExecuteReader();
                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<Guid>(reader).FirstOrDefault().ToString();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public string Employee_Personal_info_Upsert(JD_EMP_Employee employee)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Personal_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                // command.Parameters.Add(new SqlParameter("@EmployeeId", employee.EmployeeId));
                command.Parameters.Add(new SqlParameter("@GuId", employee.GuId));
                command.Parameters.Add(new SqlParameter("@Nickname", (employee.Nickname)));
                command.Parameters.Add(new SqlParameter("@SSN", (employee.SSN)));
                command.Parameters.Add(new SqlParameter("@DriverLicenseNumber", (employee.DriverLicenseNumber)));
                //command.Parameters.Add(new SqlParameter("@AddressLine2", (employee.AdressLine2)));
                command.Parameters.Add(new SqlParameter("@Ethnicity", employee.Ethnicity));
                command.Parameters.Add(new SqlParameter("@Sex", employee.Sex));
                command.Parameters.Add(new SqlParameter("@Dob", employee.Dob));
                command.Parameters.Add(new SqlParameter("@CurrentSalary", employee.CurrentSalary));
                command.Parameters.Add(new SqlParameter("@CurrentTitle", employee.CurrentTitle));

                command.Parameters.Add(new SqlParameter("@Upd_Dt", DateTime.Now));
                command.Parameters.Add(new SqlParameter("@Upd_By", "test"));

                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<Guid>(reader).FirstOrDefault().ToString();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public int Employee_Military_info_Upsert(EmployeeMillitary military, Guid EmployeeGuId)
        {
            if (military.FileContent != null)
            {
                var base64Data = Regex.Match(military.FileContent, @"data:application/(?<type>.+?),(?<data>.+)").Groups["data"].Value;
                byte[] bytes = Convert.FromBase64String(base64Data);
                string filePath = ConfigurationManager.AppSettings["SharedPath"] + "\\" + ConfigurationManager.AppSettings["EmployeeFolder"] + "\\" + EmployeeGuId;
                if (!System.IO.Directory.Exists(filePath))
                {
                    System.IO.Directory.CreateDirectory(filePath); //Create directory if it doesn't exist
                }
                if (!File.Exists(filePath + "\\" + military.Filename))
                    File.WriteAllBytes(filePath + "\\" + military.Filename, bytes);
                else
                {
                    File.Delete(filePath + military.Filename);
                    File.WriteAllBytes(filePath + "\\" + military.Filename, bytes);
                }
                military.FilePath = filePath + "\\" + military.Filename;
            }
            
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Military_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@EmployeeMillitaryId", military.EmployeeMillitaryId));
                // command.Parameters.Add(new SqlParameter("@EmployeeId", (military.EmployeeId)));
                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                command.Parameters.Add(new SqlParameter("@MilitaryBranch", (military.MilitaryBranch)));
                command.Parameters.Add(new SqlParameter("@ActiveDutyFlag", (military.ActiveDutyFlag ?? false)));
                //command.Parameters.Add(new SqlParameter("@AddressLine2", (employee.AdressLine2)));
                command.Parameters.Add(new SqlParameter("@DischargeYear", military.DischargeYear));
                command.Parameters.Add(new SqlParameter("@Rank", military.Rank));
                command.Parameters.Add(new SqlParameter("@CertificationLicense", military.CertificationLicense));
                command.Parameters.Add(new SqlParameter("@FilePath", military.FilePath));
                command.Parameters.Add(new SqlParameter("@Crt_By", military.Crt_By));
                command.Parameters.Add(new SqlParameter("@IsDeleted", military.IsDeleted));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public string Employee_Profile_info_Upsert(JD_EMP_Employee employee)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_ProfileInfo_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@GuId", employee.GuId));
                command.Parameters.Add(new SqlParameter("@Description", (employee.Description)));
                command.Parameters.Add(new SqlParameter("@DesiredLocation", (employee.DesiredLocation)));
                command.Parameters.Add(new SqlParameter("@DesiredPosition", (employee.DesiredPosition)));
                command.Parameters.Add(new SqlParameter("@ProfilePhoto", (employee.ProfilePhoto)));
                command.Parameters.Add(new SqlParameter("@EmployementType", (employee.EmploymentType)));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<Guid>(reader).FirstOrDefault().ToString();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public string Employee_TransportMode_Upsert(JD_EMP_Employee employee)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_TransportMode_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@GuId", employee.GuId));
                command.Parameters.Add(new SqlParameter("@TransportMode", (employee.TransportMode)));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<Guid>(reader).FirstOrDefault().ToString();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }

        }

        public int Employee_UserId_Upsert(string Guid, int userid)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_UserId_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@EmployeeId", Guid));
                command.Parameters.Add(new SqlParameter("@Userid", userid));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
                JD_EMP_Employee employee = EmployeeDetailSelect(Guid);
                JD_ADM_UserIdentity userIdentity = SelectUserName(userid);
                SendEmail(userIdentity.UserName, employee.Email, employee.LastName + " " + employee.FirstName);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }

        }
        public bool SendEmail(string username, string Toemail, string employeename)
        {
            try
            {
                EmailMessageService email = new EmailMessageService();

                Task.Run(() => email.Sendmail(username, "Welcome123", Toemail, employeename));
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
        public JD_ADM_UserIdentity SelectUserName(int userid)
        {
            try
            {
                //string saltkey = Encrypt.GetSalt();

                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_ADM_UserIdentity_Select_UserName";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@UserId", userid));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                JD_ADM_UserIdentity username = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_ADM_UserIdentity>(reader).FirstOrDefault();

                return username;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }


        public int Employee_BankAccount_Details_Upsert(JD_EMP_Employee_BankAccounts paymentDetails, string EmployeeGuId)
        {
            try

            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Payment_Details_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                command.Parameters.Add(new SqlParameter("@AccountNumber", (paymentDetails.AccountNumber)));
                command.Parameters.Add(new SqlParameter("@RoutingNumber", (paymentDetails.RoutingNumber)));
                command.Parameters.Add(new SqlParameter("@CardOrACH", (paymentDetails.CardOrACH)));
                command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                command.Parameters.Add(new SqlParameter("@Crt_Dt", DateTime.Now));
                command.Parameters.Add(new SqlParameter("@Upd_Dt", DateTime.Now));
                command.Parameters.Add(new SqlParameter("@Upd_By", "test"));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public int Employee_Education_Upsert(List<JD_EMP_Employee_Education> educations)
        {

            try
            {

                XElement xEle = new XElement("educationlist",
                 from education in educations
                 select new XElement("education",
                              new XElement("EmployeeEductaionId", education.EmployeeEductaionId),
                              new XElement("EmployeeId", education.EmployeeId),
                              new XElement("EducationDescription", education.EducationDescription),
                              new XElement("EducationType", education.EducationType),
                              new XElement("City", education.City),
                              new XElement("State", education.State),
                              new XElement("EducationTypeDetail", education.EducationTypeDetail),
                              new XElement("Status", education.Status),
                              new XElement("DateOfGraduation", education.DateOfGraduation)


                    ));

                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Education_Upsert_copy";
                command.CommandType = CommandType.StoredProcedure;
                command.CommandType = CommandType.StoredProcedure;
                SqlParameter xleparam = new SqlParameter("@XmlDocument", SqlDbType.NVarChar, 0);
                xleparam.Value = xEle.ToString();
                command.Parameters.Add(xleparam);
                command.Parameters.Add(new SqlParameter("@Crt_By", "PBLC_USR"));
                //command.Parameters.Add(new SqlParameter("@EmployeeEductaionId", education.EmployeeEductaionId));
                //command.Parameters.Add(new SqlParameter("@EmployeeId", education.EmployeeId));
                //command.Parameters.Add(new SqlParameter("@EducationType", education.EducationType));
                //command.Parameters.Add(new SqlParameter("@EducationDescription", education.EducationDescription));
                //command.Parameters.Add(new SqlParameter("@City", education.City));
                //command.Parameters.Add(new SqlParameter("@State", education.State));
                //command.Parameters.Add(new SqlParameter("@DateOfGraduation", education.DateOfGraduation));
                //command.Parameters.Add(new SqlParameter("@EducationTypeDetail", education.EducationTypeDetail));
                //command.Parameters.Add(new SqlParameter("@Crt_By", education.Crt_By));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public Boolean Employee_Educations_Delete(List<int> educationids)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "[JD_Employee_Education_Delete]";
                command.CommandType = CommandType.StoredProcedure;

                foreach (int item in educationids)
                {
                    command.Parameters.Add(new SqlParameter("@EmployeeEductaionId", item));
                    if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;

                    System.Data.Common.DbDataReader reader = command.ExecuteReader();
                    int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
                    reader.Close();
                    command.Parameters.Clear();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }


        }
        public Boolean Employee_Education_Cert_Delete(List<int> certificateids)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "[JD_Employee_EdCertificate_Delete]";
                command.CommandType = CommandType.StoredProcedure;

                foreach (int item in certificateids)
                {
                    command.Parameters.Add(new SqlParameter("@EmployeeEducationCertId", item));
                    if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;

                    System.Data.Common.DbDataReader reader = command.ExecuteReader();
                    int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
                    reader.Close();
                    command.Parameters.Clear();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }


        }
        public Boolean Employee_Experience_Delete(List<int> experiences)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "[JD_Employee_Experience_Delete]";
                command.CommandType = CommandType.StoredProcedure;

                foreach (int item in experiences)
                {
                    command.Parameters.Add(new SqlParameter("@EmployeeCompanyId", item));
                    if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                    System.Data.Common.DbDataReader reader = command.ExecuteReader();
                    int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
                    reader.Close();
                    command.Parameters.Clear();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }


        }
        public bool Employee_Education_Cert_Upsert(List<JD_EMP_Employee_Education_Cert> certificates)
        {

            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Education_certifications_Upsert";
                command.CommandType = CommandType.StoredProcedure;
                System.Data.Common.DbDataReader reader;
                foreach (JD_EMP_Employee_Education_Cert certificate in certificates)
                {
                    command.Parameters.Add(new SqlParameter("@EmployeeEducationCertId", certificate.EmployeeEducationCertId));
                    command.Parameters.Add(new SqlParameter("@CertificationLicense", certificate.CertificationLicense));
                    command.Parameters.Add(new SqlParameter("@EmployeeId", certificate.EmployeeId));
                    command.Parameters.Add(new SqlParameter("@Crt_By", certificate.Crt_By));
                    if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                    reader = command.ExecuteReader();
                    int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
                    reader.Close();
                    command.Parameters.Clear();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public JD_EMP_Employee_BankAccounts Employee_BankAccountDetails_Select(string GuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_BankAccountDetails_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@GuId", GuId));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                JD_EMP_Employee_BankAccounts bankAccount = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMP_Employee_BankAccounts>(reader).FirstOrDefault();
                return bankAccount;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        /*public int Employee_Education_Upsert(List<JD_EMP_Employee_Education> educations)
        {
            try
            {
                XElement xEle = new XElement("educationlist",
         from education in educations
         select new XElement("education",
                      new XElement("EmployeeEductaionId", education.EmployeeEductaionId),
                      new XElement("EmployeeId", education.EmployeeId),
                      // new XElement("University", education.University),
                      // new XElement("GPA", education.GPA),
                      new XElement("Status", education.Status),
                      new XElement("DateOfGraduation", education.DateOfGraduation)

                    ));
                //DataTable etable = new DataTable();

                //etable.Columns.Add("EmployeeEductaionId", typeof(int));
                //etable.Columns.Add("EmployeeId", typeof(int));
                //etable.Columns.Add("University", typeof(string));
                //etable.Columns.Add("DateOfGraduation", typeof(DateTime));
                //etable.Columns.Add("GPA", typeof(string));
                //etable.Columns.Add("Status", typeof(string));

                //DataRow dr;
                //foreach (education item in educations)
                //{
                //    dr = etable.NewRow();
                //    dr["EmployeeEductaionId"] = item.EmployeeEductaionId;
                //    dr["EmployeeId"] = item.EmployeeId;
                //    dr["University"] = item.University;
                //    dr["DateOfGraduation"] = item.DateOfGraduation;
                //    dr["GPA"] = item.GPA;
                //    dr["Status"] = item.Status;
                //    etable.Rows.Add(dr);                }
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Education_Upsert";
                command.CommandType = CommandType.StoredProcedure;
                SqlParameter xleparam = new SqlParameter("@XmlDocument", SqlDbType.NVarChar, 0);
                xleparam.Value = xEle.ToString();
                command.Parameters.Add(xleparam);
                command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                 if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open();;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();
                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }*/

        /* public int Employee_Compnay_Upsert(List<JD_EMP_Employee_Company> Companies)
         {
             try
             {
                 XElement xEle = new XElement("companylist",
          from company in Companies
          select new XElement("company",
                       new XElement("CompanyName", company.CompanyName),
                       new XElement("EmployeeCompanyId", company.EmployeeCompanyId),
                       new XElement("EmployeeId", company.EmployeeId),
                       new XElement("HireDate", company.HireDate),
                       new XElement("Status", company.Status),
                       new XElement("LenthOfEmployment", company.LenthOfEmployment),
                       new XElement("Tittle", company.Tittle)
                     ));
                 //DataTable etable = new DataTable();

                 //etable.Columns.Add("EmployeeEductaionId", typeof(int));
                 //etable.Columns.Add("EmployeeId", typeof(int));
                 //etable.Columns.Add("University", typeof(string));
                 //etable.Columns.Add("DateOfGraduation", typeof(DateTime));
                 //etable.Columns.Add("GPA", typeof(string));
                 //etable.Columns.Add("Status", typeof(string));

                 //DataRow dr;
                 //foreach (education item in educations)
                 //{
                 //    dr = etable.NewRow();
                 //    dr["EmployeeEductaionId"] = item.EmployeeEductaionId;
                 //    dr["EmployeeId"] = item.EmployeeId;
                 //    dr["University"] = item.University;
                 //    dr["DateOfGraduation"] = item.DateOfGraduation;
                 //    dr["GPA"] = item.GPA;
                 //    dr["Status"] = item.Status;
                 //    etable.Rows.Add(dr);                }
                 var command = _db.Database.Connection.CreateCommand();
                 command.CommandText = "JD_Employee_Companies_Upsert";
                 command.CommandType = CommandType.StoredProcedure;
                 SqlParameter xleparam = new SqlParameter("@XmlDocument", SqlDbType.NVarChar, 0);
                 xleparam.Value = xEle.ToString();
                 command.Parameters.Add(xleparam);
                 command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                  if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open();;
                 System.Data.Common.DbDataReader reader = command.ExecuteReader();
                 int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
                 return result;
             }
             catch (Exception ex)
             {
                 throw ex;
             }
             finally
             {
                 _db.Database.Connection.Close();
             }
         }*/
        public Boolean Employee_Compnay_Upsert(List<JD_EMP_Employee_Company> companies)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Companies_Upsert";
                command.CommandType = CommandType.StoredProcedure;
                foreach (JD_EMP_Employee_Company Company in companies)
                {


                    command.Parameters.Add(new SqlParameter("@EmployeeCompanyId", Company.EmployeeCompanyId));
                    command.Parameters.Add(new SqlParameter("@EmployeeId", Company.EmployeeId));
                    command.Parameters.Add(new SqlParameter("@CompanyName", Company.CompanyName));
                    command.Parameters.Add(new SqlParameter("@Tittle", Company.Tittle));
                    command.Parameters.Add(new SqlParameter("@HireDate", Company.HireDate));
                    command.Parameters.Add(new SqlParameter("@LenthOfEmployment", Company.LenthOfEmployment));
                    command.Parameters.Add(new SqlParameter("@Crt_By", Company.Crt_By));
                    if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                    System.Data.Common.DbDataReader reader = command.ExecuteReader();

                    int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
                    reader.Close();
                    command.Parameters.Clear();
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }
        public int Employee_Skills_Upsert(JD_EMP_Employee_Skill_List skill, string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Skills_Upsert";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                command.Parameters.Add(new SqlParameter("@SkillId", skill.SkillId));
                command.Parameters.Add(new SqlParameter("@Description", skill.Description));
                command.Parameters.Add(new SqlParameter("@Crt_Dt", DateTime.Now));
                command.Parameters.Add(new SqlParameter("@Crt_By", skill.Crt_By));
                command.Parameters.Add(new SqlParameter("@Upd_Dt", DateTime.Now));
                command.Parameters.Add(new SqlParameter("@Upd_By", skill.Upd_By));
                command.Parameters.Add(new SqlParameter("@Status", skill.Status));

                _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public List<JD_EMP_Employee_Skill_List> Employee_SelectedSkills_Select(string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_SelectedSkills_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                List<JD_EMP_Employee_Skill_List> SelectedSkillList = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMP_Employee_Skill_List>(reader).ToList();
                return SelectedSkillList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }



        public int Employee_PreferedJobDetails_Upsert(JD_EMP_Employee_PreferedJobDetails preferedJobDetails, string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_PreferedJob_Details_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                command.Parameters.Add(new SqlParameter("@DesiredIndustry", preferedJobDetails.DesiredIndustry));
                command.Parameters.Add(new SqlParameter("@DesiredPosition", preferedJobDetails.DesiredPosition));
                command.Parameters.Add(new SqlParameter("@DesiredSalary", preferedJobDetails.DesiredSalary));
                command.Parameters.Add(new SqlParameter("@WorkType", preferedJobDetails.WorkType));
                command.Parameters.Add(new SqlParameter("@City", preferedJobDetails.City));
                command.Parameters.Add(new SqlParameter("@State", preferedJobDetails.State));
                command.Parameters.Add(new SqlParameter("@Crt_Dt", DateTime.Now));
                command.Parameters.Add(new SqlParameter("@Crt_By", "Admin"));
                command.Parameters.Add(new SqlParameter("@Upd_Dt", DateTime.Now));
                command.Parameters.Add(new SqlParameter("@Upd_By", "Admin"));
                command.Parameters.Add(new SqlParameter("@Status", preferedJobDetails.Status));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public JD_EMP_Employee_PreferedJobDetails Employee_PreferedJobDetails_Select(string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_PreferedJobDetails_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                JD_EMP_Employee_PreferedJobDetails preferedJobDetails = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMP_Employee_PreferedJobDetails>(reader).FirstOrDefault();
                return preferedJobDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public JD_EMP_Employee EmployeeDetailSelect(string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Details_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@Guid", EmployeeGuId));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                JD_EMP_Employee employee = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMP_Employee>(reader).FirstOrDefault();

                return employee;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }
        public JD_EMP_Employee Select(int EmployeeId)
        {
            try
            {
                //string saltkey = Encrypt.GetSalt();

                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Details_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@EmployeeId", EmployeeId));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                JD_EMP_Employee employee = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMP_Employee>(reader).FirstOrDefault();

                return employee;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public List<JD_EMP_Employee_Education> EmployeeEducationsSelect(string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Educations_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                List<JD_EMP_Employee_Education> Educations = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMP_Employee_Education>(reader).ToList();
                return Educations;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public List<JD_EMP_Employee_Education_Cert> EmployeeEducationsCertSelect(string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Educations_Cert_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                List<JD_EMP_Employee_Education_Cert> Educations = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMP_Employee_Education_Cert>(reader).ToList();
                return Educations;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }
        public List<JD_EMP_Employee_Company> EmployeeCompaniessSelect(string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Companies_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                var reader = command.ExecuteReader();

                List<JD_EMP_Employee_Company> companies = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_EMP_Employee_Company>(reader).ToList();
                return companies;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public List<EmployeeMillitary> EmployeeMiliatrySelect(string EmployeeGuId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Military_Select";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@GuId", EmployeeGuId));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                List<EmployeeMillitary> Militarylist = ((IObjectContextAdapter)_db).ObjectContext.Translate<EmployeeMillitary>(reader).ToList();
                foreach (var military in Militarylist)
                {
                    List<string> slist = military.FilePath.Split('\\').ToList();
                    if (slist.Count > 0)
                        military.Filename = slist.Last();
                }
                return Militarylist;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public string ResumeUpload(Jobdoggfile jobdoggfile)
        {

            var base64Data = Regex.Match(jobdoggfile.filecontent, @"data:application/(?<type>.+?),(?<data>.+)").Groups["data"].Value;
            byte[] bytes = Convert.FromBase64String(base64Data);
            string filePath = ConfigurationManager.AppSettings["SharedPath"]  + ConfigurationManager.AppSettings["EmployeeFolder"] + "\\" + jobdoggfile.Guid;
            if (!System.IO.Directory.Exists(filePath))
            {
                System.IO.Directory.CreateDirectory(filePath); //Create directory if it doesn't exist
            }
            if (!File.Exists(filePath + "\\" + jobdoggfile.filename))
                File.WriteAllBytes(filePath + "\\" + jobdoggfile.filename, bytes);
            else
            {
                File.Delete(filePath + "\\" + jobdoggfile.filename);
                File.WriteAllBytes(filePath + "\\" + jobdoggfile.filename, bytes);
            }
            string returnPath = filePath + "\\" + jobdoggfile.filename;
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_Resume_Upsert";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@EmployeeId", jobdoggfile.EmployeeId));
                command.Parameters.Add(new SqlParameter("@ResumeFilePath", returnPath));
                command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }

            return returnPath;

        }

        public string ProfileVdoUpload(Jobdoggfile jobdoggfile)
        {
            jobdoggfile.filename = jobdoggfile.filename + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.Day.ToString() + "_" + DateTime.Now.Year.ToString() + "_" + DateTime.Now.Hour.ToString() + "_" + DateTime.Now.Minute.ToString() + ".webm";
            var base64Data = Regex.Match(jobdoggfile.filecontent, @"data:video/(?<type>.+?),(?<data>.+)").Groups["data"].Value;
            byte[] bytes = Convert.FromBase64String(base64Data);
            string filePath = ConfigurationManager.AppSettings["SharedPath"] + "\\" + ConfigurationManager.AppSettings["EmployeeFolder"] + "\\" + jobdoggfile.Guid;
            if (!System.IO.Directory.Exists(filePath))
            {
                System.IO.Directory.CreateDirectory(filePath); //Create directory if it doesn't exist
            }
            if (!File.Exists(filePath + "\\" + jobdoggfile.filename))
                File.WriteAllBytes(filePath + "\\" + jobdoggfile.filename, bytes);
            else
            {
                File.Delete(filePath + "\\" + jobdoggfile.filename);
                File.WriteAllBytes(filePath + "\\" + jobdoggfile.filename, bytes);
            }
            string returnPath = filePath + "\\" + jobdoggfile.filename;
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_Employee_ProfileVdo_Upsert";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@Guid", jobdoggfile.Guid));
                command.Parameters.Add(new SqlParameter("@ProfileVdoPath", returnPath));
                command.Parameters.Add(new SqlParameter("@Crt_By", "test"));
                if (_db.Database.Connection.State == ConnectionState.Closed) _db.Database.Connection.Open(); ;
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                string result = ((IObjectContextAdapter)_db).ObjectContext.Translate<string>(reader).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }

            return returnPath;

        }

        /* public void UserCreation(int EmployeeId)
         {
             JD_EMP_Employee employee = Select(EmployeeId);
             string username = "";


             using (Security db = new Security())
             {
                 foreach (char chr in employee.FirstName)
                 {
                     username = chr + employee.LastName;
                     var userData = db.GetUserInfo(username);
                     if (userData == null) break;
                 }

                 var resultObj = new Authentication();
                 resultObj = new Authentication()
                 {
                     IsAuthenticated = false
                 };
                 string salt = Encrypt.GetSalt();
                 string passwrod = Encrypt.GetHashPassword(ConfigurationManager.AppSettings["defaultpassword"], salt);
                 db.CreateNewUser(0, passwrod, username, "PBLC_USER", salt);


             };

         }*/


    }

}
