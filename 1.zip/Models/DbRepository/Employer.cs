﻿using JobDoggApi.Areas.EmployerManagement.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using static JobDoggApi.Models.DbRepository.DbRepository;

namespace JobDoggApi.Models.DbRepository
{
    public class Employer : BaseRepo
    {
        public EmployerMessageData GetEmployerMessageList(int userId, int currentPageNumber, int itemsPerPage)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_EmployerMessage_Select";
                command.CommandType = CommandType.StoredProcedure;
                
                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@UserId",
                    Value = userId
                });
                
                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@CurrentPageNumber",
                    Value = currentPageNumber
                });

                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@ItemsPerPage",
                    Value = itemsPerPage
                });

                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                EmployerMessageListCount messageCount = ((IObjectContextAdapter)_db).ObjectContext.Translate<EmployerMessageListCount>(reader).FirstOrDefault();

                reader.NextResult();

                List<EmployerMessage> messageList = ((IObjectContextAdapter)_db).ObjectContext.Translate<EmployerMessage>(reader).ToList();

                return new EmployerMessageData
                {
                    Count = messageCount,
                    EmployerMessages = messageList
                };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public GetEmployerMessageList_Result GetEmployerMessageById(int userId, int messageId)
        {
            return _db.JD_EmployerMessage_Select(userId, messageId, 0, 0).FirstOrDefault();
        }

        public EmailContact GetEmailAddress(string searchText)
        {
            return new EmailContact();
        }
        
        public JD_Employer_Select_Result GetEmployerDetails(int userId)
        {
            return _db.JD_Employer_Select(userId).FirstOrDefault();
        }

        public JD_EmployerContact_Select_Result GetEmployerContactDetails(int userId)
        {
            return _db.JD_EmployerContact_Select(userId).FirstOrDefault();
        }

        public List<DogList> GetDogList(int userId)
        {
            List<DogList> dogList = new List<DogList>();
            dogList.Add(new DogList() { DogId = 1, DogName = "FirstDogg" });
            dogList.Add(new DogList() { DogId = 2, DogName = "SecondDogg" });
            return dogList;
        }

        public List<DogType> GetDogTypeList(int userId)
        {
            List<DogType> dogTypeList = new List<DogType>();
            dogTypeList.Add(new DogType() { DogId = 1, Type = "FirstDoggType" });
            dogTypeList.Add(new DogType() { DogId = 2, Type = "SecondDoggType" });
            return dogTypeList;
        }
    }
}