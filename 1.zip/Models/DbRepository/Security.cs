﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using static JobDoggApi.Models.DbRepository.DbRepository;

namespace JobDoggApi.Models.DbRepository
{
    /// <summary>
    /// Security class
    /// </summary>
    public class Security : BaseRepo
    {
        /// <summary>
        /// User Name for the login
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Password for the login
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// Is active property of the user
        /// </summary>
        public bool IsActive { get; set; }
        /// <summary>
        /// Contains the list of roles
        /// </summary>
        public List<String> Roles { get; set; }
        /// <summary>
        /// string key for the token generation
        /// </summary>
        public string Salt { get; set; }
        /// <summary>
        /// user id
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// This method will do the authentication checking by comparing the database values
        /// </summary>
        /// <param name="userName">User Name from the client side</param>
        /// <param name="password">Password from the client side</param>
        /// <returns></returns>
        public Security GetUserInfo(string userName)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_UserRole_Select";
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter username = new SqlParameter
                {
                    ParameterName = "@Username",
                    Value = userName
                };
                command.Parameters.Add(username);

                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                Security userData = ((IObjectContextAdapter)_db).ObjectContext.Translate<Security>(reader).FirstOrDefault();
                if (userData != null)
                {
                    reader.NextResult();
                    userData.Roles = ((IObjectContextAdapter)_db).ObjectContext.Translate<String>(reader).ToList();
                }

                return userData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        /// <summary>
        /// Save the token details to the database
        /// </summary>
        /// <param name="token">encrypted token</param>
        /// <param name="keyIdentifier">key identifier</param>
        /// <param name="userId">user id</param>
        /// <returns></returns>
        public void SaveToken(string token, int userId, string username, string keyIdentifier = "")
        {
            _db.JD_Token_Upsert(userId, token, keyIdentifier, username);
        }

        /// <summary>
        /// This will check the session timeout of the user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="encryptedToken"></param>
        /// <returns></returns>
        public bool CheckSessionTimeout(int userId, string encryptedToken, string username)
        {
            JD_ADM_Token tokenData = GetToken(encryptedToken);

            TimeSpan timeSpan = DateTime.Now - tokenData.LastAccessedDate;

            if (timeSpan.Days > 1)
            {
                return true;
            }
            else if (timeSpan.Hours > 1)
            {
                return true;
            }
            else if (timeSpan.Minutes > Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["sessiontimeout"]))
            {
                return true;
            }
            else
            {
                if (tokenData != null)
                {
                    SaveToken(encryptedToken, userId, username);
                }
                return false;
            }
        }

        /// <summary>
        /// This method will validate the encrypted token from the database
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public JD_ADM_Token GetToken(string token)
        {
            return _db.JD_Token_Select(null, token).FirstOrDefault();
        }

        /// <summary>
        /// This method change the password of an existing user to a new one
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="passwrod"></param>
        /// <returns></returns>
        public void ChangePassword(int userId, string passwrod)
        {
            _db.JD_UserIdentity_Upsert(userId, passwrod, "", "", "", 0);
        }
        public int CreateNewUser(int userId, string passwrod, string username, string crt_by, string salt, int userRoleId=2)
        {

            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_UserIdentity_Upsert";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@UserId", userId));
                command.Parameters.Add(new SqlParameter("@Password", passwrod));
                command.Parameters.Add(new SqlParameter("@UserName", username));
                command.Parameters.Add(new SqlParameter("@Salt", salt));
                command.Parameters.Add(new SqlParameter("@UserRoleId", userRoleId));
                //command.Parameters.Add(new SqlParameter("@AddressLine2", (employee.AdressLine2)));
                command.Parameters.Add(new SqlParameter("@Crt_By", crt_by));
                _db.Database.Connection.Open();
                System.Data.Common.DbDataReader reader = command.ExecuteReader();

                int result = ((IObjectContextAdapter)_db).ObjectContext.Translate<int>(reader).FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }


    
        /// <summary>
        /// This return the user details by user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public Security GetUserByUserId(int userId)
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_UserRole_Select";
                command.CommandType = CommandType.StoredProcedure;

                SqlParameter sqlUserId = new SqlParameter
                {
                    ParameterName = "@UserId",
                    Value = userId
                };
                command.Parameters.Add(sqlUserId);

                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                return ((IObjectContextAdapter)_db).ObjectContext.Translate<Security>(reader).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }
    }
}