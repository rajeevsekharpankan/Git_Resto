﻿using JobDoggApi.Areas.MenuManagement;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using static JobDoggApi.Models.DbRepository.DbRepository;

namespace JobDoggApi.Models.DbRepository
{
    public class Menu : BaseRepo
    {
        public List<GetMenuList_Result> GetMenuList(string roles)
        {
            return _db.JD_MenuRole_Select(roles).ToList();
        }
    }
}