﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Models.DbRepository
{
    public class DbRepository
    {
        /// <summary>
        /// Base repository class
        /// </summary>
        public class BaseRepo : IDisposable
        {
            /// <summary>
            /// Initializing the jobdogg database
            /// </summary>
            public JobDoggEntities _db;

            /// <summary>
            /// baserepo constructor
            /// </summary>
            public BaseRepo()
            {
                _db = new JobDoggEntities();
            }

            /// <summary>
            /// database object disposing
            /// </summary>
            public void Dispose()
            {
                if (_db != null)
                {
                    _db.Dispose();
                    _db = null;
                }
            }
        }
    }
}