﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using static JobDoggApi.Models.DbRepository.DbRepository;

namespace JobDoggApi.Models.DbRepository
{
    public class Employee : BaseRepo
    {
        public JD_Employee_Select_Result GetEmployeeDetails(int userId)
        {
            return _db.JD_Employee_Select(userId).FirstOrDefault();
        }
    }
}