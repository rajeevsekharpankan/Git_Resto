﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Utilities
{
    public class PictureUpload
    {
        public string profilePicUpload(HttpPostedFile file, string path, string imageName)
        {
            // Check if directory exist
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path); //Create directory if it doesn't exist
            }
            string filepath = path + "//" + imageName;
            file.SaveAs(filepath); 
            return filepath;
        }
    }
}