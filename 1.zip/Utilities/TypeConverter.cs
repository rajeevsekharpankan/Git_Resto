﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Utilities
{
    public class TypeConverter
    {
        public static T Parse<T>(string sourceValue) //where T : IConvertible
        {
            return (T)Convert.ChangeType(sourceValue, typeof(T));
        }

        public static T Parse<T>(string sourceValue, IFormatProvider provider) //where T : IConvertible
        {
            return (T)Convert.ChangeType(sourceValue, typeof(T), provider);
        }

        public static object ChangeType(object value, Type type)
        {
            Type actualType = Nullable.GetUnderlyingType(type) ?? type;
            return (value == null) ? null : Convert.ChangeType(value, actualType);
        }

        public static T CheckNullOrEmpty<T>(T value)
        {
            if (value == null)
                return default(T);

            return value;
        }
    }
}