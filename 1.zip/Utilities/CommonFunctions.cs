﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;
using JobDoggApi.Models.DbRepository;
using static JobDoggApi.Models.DbRepository.DbRepository;

namespace JobDoggApi.Utilities
{
    public class CommonFunctions : BaseRepo
    {
        public List<JD_ADM_States> GetAllStates()
        {
            try
            {
                var command = _db.Database.Connection.CreateCommand();
                command.CommandText = "JD_ADM_States_Select";
                command.CommandType = CommandType.StoredProcedure;
                _db.Database.Connection.Open();
                var reader = command.ExecuteReader();

                List<JD_ADM_States> States = ((IObjectContextAdapter)_db).ObjectContext.Translate<JD_ADM_States>(reader).ToList();
                return States;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                _db.Database.Connection.Close();
            }
        }

        public List<JD_ADM_Dropdown_Select_Result> GetApplicationDropdowns(string type)
        {
            return _db.JD_ADM_Dropdown_Select(type).ToList();
        }


    }
}