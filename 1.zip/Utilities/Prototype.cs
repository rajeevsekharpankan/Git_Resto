﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Utilities
{
    public static class Prototype
    {
        public static string CorrectExceptionMessage(Exception ex)
        {
            string errorMessage = "";

            errorMessage = ex.InnerException != null ? ex.InnerException.Message : ex.Message;
            errorMessage = errorMessage.Replace("Transaction count after EXECUTE indicates a mismatching number of BEGIN and COMMIT statements. Previous count = 1, current count = 0.", "");

            return errorMessage;
        }

        /// <summary>
        /// Set the expiry month
        /// </summary>
        /// <param name="expiryMonth"></param>
        /// <returns></returns>
        public static string SetExpiryMoth(int expiryMonth)
        {
            var month = "";
            switch (expiryMonth)
            {
                case 1:
                    month = "January";
                    break;
                case 2:
                    month = "February";
                    break;
                case 3:
                    month = "March";
                    break;
                case 4:
                    month = "April";
                    break;
                case 5:
                    month = "May";
                    break;
                case 6:
                    month = "June";
                    break;
                case 7:
                    month = "July";
                    break;
                case 8:
                    month = "August";
                    break;
                case 9:
                    month = "September";
                    break;
                case 10:
                    month = "October";
                    break;
                case 11:
                    month = "November";
                    break;
                case 12:
                    month = "December";
                    break;
            }
            return month;
        }

        /// <summary>
        /// Masked credit card details
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static string maskedCardDetails(string number)
        {
            int cardLength = number.Length;
            var last4Digit = number.Substring(cardLength - 4, 4);
            var masKedCard = "";

            for (int i = 1; i <= cardLength - 4; i++)
            {
                masKedCard += "X";
                if (i % 4 == 0)
                {
                    masKedCard += "-";
                }
            }
            return masKedCard + last4Digit;

        }

        /// <summary>
        /// return the phone number format
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <returns></returns>
        public static string PhoneNumberFormat(string phoneNumber)
        {
            phoneNumber = new System.Text.RegularExpressions.Regex(@"\D").Replace(phoneNumber, string.Empty);

            if (phoneNumber.Length == 7)
                phoneNumber = Convert.ToInt64(phoneNumber).ToString("###-####");
            if (phoneNumber.Length == 10)
                phoneNumber = Convert.ToInt64(phoneNumber).ToString("(###) ###-####");
            return phoneNumber;
        }

        private static Random random = new Random();
        /// <summary>
        /// Generate Random string for the user's key identifier
        /// </summary>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+_)(*&^%$#@!~?><:{}|][';.,";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}