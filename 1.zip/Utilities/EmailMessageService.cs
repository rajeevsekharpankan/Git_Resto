﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Web.Configuration;
using System.Net.Configuration;
using System.Threading.Tasks;

namespace JobDoggApi.Utilities
{
    public class EmailMessageService
    {
        private void Dispatch(MailMessage message)
        {
            SmtpSection section = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");
            NetworkCredential credential = new NetworkCredential(section.Network.UserName, section.Network.Password);
            SmtpClient smtpClient = new SmtpClient();
            smtpClient.Host = section.Network.Host;
            smtpClient.Credentials = credential;
            try
            {
                smtpClient.Send(message);
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
        public async void Sendmail(string username,string password,string emailto,string employeename)
        {
            string mailBody = System.IO.File.ReadAllText(System.Configuration.ConfigurationManager.AppSettings["emailtemplate"]);
            mailBody = mailBody.Replace("@EmployeeName@", employeename);
            mailBody = mailBody.Replace("@username@", username);
            mailBody = mailBody.Replace("@password@", password);
            MailMessage message = new MailMessage();
            message.Subject = "JobDogg Registration!";
            message.Body = mailBody;
            message.IsBodyHtml = true;
            message.To.Add(emailto);
            await Task.Run(() => Dispatch(message));
        }

        public async void SendEmployerMail(string username, string password, string emailto,string companyName)
        {
            string mailBody = System.IO.File.ReadAllText(System.Configuration.ConfigurationManager.AppSettings["employerEmailtemplate"]);
            mailBody = mailBody.Replace("[Username]", username);
            mailBody = mailBody.Replace("[Password]", password);
            mailBody = mailBody.Replace("[CompanyName]", companyName);
            MailMessage message = new MailMessage();
            message.Subject = "JobDogg Registration!";
            message.Body = mailBody;
            message.IsBodyHtml = true;
            message.To.Add(emailto);
            await Task.Run(() => Dispatch(message));
        }
    }
}