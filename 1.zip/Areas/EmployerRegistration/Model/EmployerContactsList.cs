﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Areas.EmployerRegistration.Model
{
    public class EmployerContactsList
    {
        public int EmployerId { get; set; }
        public Guid EmployerGuId { get; set; }
        public List<EmployerContact> ContactList { get; set; }
    }

    public class EmployerContact
    {
        public int EmployerContactId { get; set; }
        public Guid EmployerGuId { get; set; }
        public int EmployerId { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Status { get; set; }
        public string ContactPhoto { get; set; }
    }
}