﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Areas.EmployerRegistration.Model
{
    public class EmployerInsert
    {
        public int EmployerId { get; set; }
        public Guid EmployerGuId { get; set; }
        public string CompanyName { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int TelePhone { get; set; }
        public string CompanyLogoPath { get; set; }
        public byte[] CompanyLogo { get; set; }
        public string CompanyVideoFilePath { get; set; }
        public string NormalHOPFrom { get; set; }
        public string NormalHOPTo { get; set; }
        public string WeekendHOPFrom { get; set; }
        public string WeekendHOPTo { get; set; }
        public EmployerHOP Hop { get; set; }
    }

    public class EmployerHOP
    {
        public int EmployerId { get; set; }
        public Guid EmployerGuid { get; set; }
        public Boolean NormalSunday { get; set; }
        public Boolean NormalMonday { get; set; }
        public Boolean NormalTuesday { get; set; }
        public Boolean NormalWednesday { get; set; }
        public Boolean NormalThursday { get; set; }
        public Boolean NormalFriday { get; set; }
        public Boolean NormalSaturday { get; set; }
        public Boolean WeekendSunday { get; set; }
        public Boolean WeekendMonday { get; set; }
        public Boolean WeekendTuesday { get; set; }
        public Boolean WeekendWednesday { get; set; }
        public Boolean WeekendThursday { get; set; }
        public Boolean WeekendFriday { get; set; }
        public Boolean WeekendSaturday { get; set; }
    }
}