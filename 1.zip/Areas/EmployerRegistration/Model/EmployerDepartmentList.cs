﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Areas.EmployerRegistration.Model
{
    public class EmployerDepartmentList
    {
        public int EmployerId { get; set; }
        public Guid EmployerGuId { get; set; }
        public List<EmployerDepartment> DeptList { get; set; }
    }

    public class EmployerDepartment
    {
        public int EmployerDepartmentId { get; set; }
        public Guid EmployerGuId { get; set; }
        public int EmployerId { get; set; }
        public string DepartmentName { get; set; }
        public string HeadOfDepartment { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int? Zip { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Status { get; set; }
        public string VideoFilePath { get; set; }
    }
}