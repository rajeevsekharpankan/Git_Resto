﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Areas.EmployerRegistration.Model
{
    public class EmployerPayment
    {
        public int EmployerPaymentId { get; set; }
        public Guid EmployerGuId { get; set; }
        public int EmployerId { get; set; }
        public string PaymentType { get; set; }
        public string NameOfBank { get; set; }
        public string AccountNumber { get; set; }
        public string RoutingNumber { get; set; }
        public bool IsCheckingAccount { get; set; }
        public string ManualDescription { get; set; }
        public string NameOnCard { get; set; }
        public string CardNumber { get; set; }
        public string CardExpiry { get; set; }
        public int CSV { get; set; }
        public string Status { get; set; }
    }
}