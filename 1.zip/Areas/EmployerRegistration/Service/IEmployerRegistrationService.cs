﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using JobDoggApi.Areas.EmployerRegistration.Model;

namespace JobDoggApi.Areas.EmployerRegistration.Service
{
    public interface IEmployerRegistrationService
    {
        string EmployerBasicInfoInsert(EmployerInsert employer);
        EmployerContactsList EmployerContactsSelect(Guid employerGuId);
        int EmployerContactsUpsert(EmployerContact employerContact);
        EmployerDepartmentList EmployerDepartmentsSelect(Guid employerGuId);
        int EmployerDepartmentInsert(EmployerDepartment employerDepartment);
        int EmployerDepartmentRemove(EmployerDepartment employerDepartment);
        int EmployerDepartmentUpdate(EmployerDepartment employerDepartment);
        int EmployerPaymentUpsert(EmployerPayment employerPayment);
        string EmployerUserIdUpsert(Guid employerGuId, int UserId);
        string EmployerContactPhotoUpload(HttpRequest context, Guid employerGuId);
        string EmployerCompanyLogoUpload(HttpRequest context, Guid employerGuId);
        string EmployerLogoPathUpsert(Guid employerGuId, string companyLogoPath);
        string EmployerDeptVideoUpload(HttpRequest context, Guid employerGuId);
        string EmployerCompanyVideoUpload(HttpRequest context, Guid employerGuId);
    }
}