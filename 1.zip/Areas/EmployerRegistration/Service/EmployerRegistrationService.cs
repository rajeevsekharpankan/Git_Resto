﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using JobDoggApi.Models.DbRepository;
using JobDoggApi.Base;
using JobDoggApi.Areas.EmployerRegistration.Model;
using System.Configuration;
using JobDoggApi.Utilities;

namespace JobDoggApi.Areas.EmployerRegistration.Service
{
    public class EmployerRegistrationService : ServiceBase, IEmployerRegistrationService
    {

        public string EmployerBasicInfoInsert(EmployerInsert employer)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_Basic_Info_Insert(employer);
                }

            }, "EmployerBasicInfoInsert");

            return result;
        }

        public EmployerContactsList EmployerContactsSelect(Guid employerGuId)
        {
            EmployerContactsList result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_Contacts_Select(employerGuId);
                }

            }, "EmployerContactsSelect");

            return result;
        }

        public int EmployerContactsUpsert(EmployerContact employerContact)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_Contacts_Upsert(employerContact);
                }

            }, "EmployerContactsUpsert");

            return result;
        }

        public EmployerDepartmentList EmployerDepartmentsSelect(Guid employerGuId)
        {
            EmployerDepartmentList result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_Departments_Select(employerGuId);
                }

            }, "EmployerDepartmentsSelect");

            return result;
        }

        public int EmployerDepartmentInsert(EmployerDepartment employerDepartment)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_Department_Insert(employerDepartment);
                }

            }, "EmployerDepartmentInsert");

            return result;
        }

        public int EmployerDepartmentRemove(EmployerDepartment employerDepartment)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_Department_Remove(employerDepartment);
                }

            }, "EmployerDepartmentRemove");

            return result;
        }

        public int EmployerDepartmentUpdate(EmployerDepartment employerDepartment)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_Department_Update(employerDepartment);
                }

            }, "EmployerDepartmentUpdate");

            return result;
        }

        public int EmployerPaymentUpsert(EmployerPayment employerPayment)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_Payment_Upsert(employerPayment);
                }

            }, "EmployerPaymentUpsert");

            return result;
        }

        public string EmployerUserIdUpsert(Guid employerGuId, int UserId)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_UserId_Upsert(employerGuId, UserId);
                }

            }, "EmployerUserIdUpsert");
            return result;
        }

        public string EmployerLogoPathUpsert(Guid employerGuId, string companyLogoPath)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_LogoPath_Upsert(employerGuId, companyLogoPath);
                }

            }, "EmployerLogoPathUpsert");
            return result;
        }

        public string EmployerCompanyVideoPathUpsert(Guid employerGuId, string companyVideoPath)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployerRegistration db = new JobDoggApi.Models.DbRepository.EmployerRegistration())
                {
                    return db.Employer_CompanyVideoPath_Upsert(employerGuId, companyVideoPath);
                }

            }, "EmployerCompanyVideoPathUpsert");
            return result;
        }

        public string EmployerContactPhotoUpload(HttpRequest context, Guid employerGuId)
        {
            var imageFilepath = string.Empty;
            var filepath = string.Empty;
            var fileName = string.Empty;
            try
            {
                if (context.Files.Count > 0)
                {
                    fileName = context.Files[0].FileName;
                    String path = ConfigurationManager.AppSettings["SharedPath"] + ConfigurationManager.AppSettings["EmployerFolder"] + "/" + employerGuId;
                    PictureUpload picUpload = new PictureUpload();
                    filepath = picUpload.profilePicUpload(context.Files[0], path, fileName);
                    imageFilepath = ConfigurationManager.AppSettings["EmployerFolder"] + "/" + employerGuId + "//" + fileName;
                }
            }
            catch (Exception ex)
            {
                //status.Message = ex.Message;
            }
            return imageFilepath;
        }

        public string EmployerCompanyLogoUpload(HttpRequest context, Guid employerGuId)
        {
            var imageFilepath = string.Empty;
            var filepath = string.Empty;
            var fileName = string.Empty;
            try
            {
                if (context.Files.Count > 0)
                {
                    fileName = context.Files[0].FileName;
                    String path = ConfigurationManager.AppSettings["SharedPath"] + ConfigurationManager.AppSettings["EmployerFolder"] + "/" + employerGuId;
                    PictureUpload picUpload = new PictureUpload();
                    filepath = picUpload.profilePicUpload(context.Files[0], path, fileName);
                    imageFilepath = ConfigurationManager.AppSettings["WebContents"] + "/" + ConfigurationManager.AppSettings["EmployerFolder"] + "/" + employerGuId + "//" + fileName;
                }

                EmployerLogoPathUpsert(employerGuId, imageFilepath);
            }
            catch (Exception ex)
            {
                //status.Message = ex.Message;
            }
            return imageFilepath;
        }

        public string EmployerDeptVideoUpload(HttpRequest context, Guid employerGuId)
        {
            var videoFilepath = string.Empty;
            var filepath = string.Empty;
            var fileName = string.Empty;
            try
            {
                if (context.Files.Count > 0)
                {
                    fileName = context.Files[0].FileName;
                    String path = ConfigurationManager.AppSettings["SharedPath"] + ConfigurationManager.AppSettings["EmployerFolder"] + "/" + employerGuId;
                    PictureUpload picUpload = new PictureUpload();
                    filepath = picUpload.profilePicUpload(context.Files[0], path, fileName);
                    videoFilepath = ConfigurationManager.AppSettings["EmployerFolder"] + "/" + employerGuId + "//" + fileName;
                }
            }
            catch (Exception ex)
            {
                //status.Message = ex.Message;
            }
            return videoFilepath;
        }

        public string EmployerCompanyVideoUpload(HttpRequest context, Guid employerGuId)
        {
            var videoFilepath = string.Empty;
            var filepath = string.Empty;
            var fileName = string.Empty;
            try
            {
                if (context.Files.Count > 0)
                {
                    fileName = context.Files[0].FileName;
                    String path = ConfigurationManager.AppSettings["SharedPath"] + ConfigurationManager.AppSettings["EmployerFolder"] + "/" + employerGuId;
                    PictureUpload picUpload = new PictureUpload();
                    filepath = picUpload.profilePicUpload(context.Files[0], path, fileName);
                    videoFilepath = ConfigurationManager.AppSettings["WebContents"] + "/" + ConfigurationManager.AppSettings["EmployerFolder"] + "/" + employerGuId + "//" + fileName;
                }

                EmployerCompanyVideoPathUpsert(employerGuId, videoFilepath);
            }
            catch (Exception ex)
            {
                //status.Message = ex.Message;
            }
            return videoFilepath;
        }
    }
}