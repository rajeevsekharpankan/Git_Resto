﻿using JobDoggApi.Areas.EmployerRegistration.Service;
using JobDoggApi.Areas.EmployerRegistration.Model;
using JobDoggApi.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using System.Web;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using JobDoggApi.Areas.SecurityManagement.Model;
using System.Configuration;


namespace JobDoggApi.Areas.EmployerRegistration.Controller
{
    public class EmployerRegistrationApiController : ApiControllerBase
    {
        private readonly IEmployerRegistrationService _service = null;

        protected override ServiceBase Service
        {
            get
            {
                return (ServiceBase)this._service;
            }
        }

        public EmployerRegistrationApiController()
            : this(new EmployerRegistrationService())
        {

        }

        public EmployerRegistrationApiController(EmployerRegistrationService service)
        {
            this._service = service;
        }

        [HttpPost]
        public HttpResponseMessage EmployerBasicInfoInsert(EmployerInsert employer)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerBasicInfoInsert(employer)
            });
        }

        [HttpGet]
        public HttpResponseMessage EmployerContactsSelect(Guid employerGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerContactsSelect(employerGuId)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerContactsUpsert(EmployerContact employerContact)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {


                ContentData = this._service.EmployerContactsUpsert(employerContact)
                //ContentData = null
            });
        }

        [HttpGet]
        public HttpResponseMessage EmployerDepartmentsSelect(Guid employerGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerDepartmentsSelect(employerGuId)
            });
        }


        [HttpPost]
        public HttpResponseMessage EmployerDepartmentInsert(EmployerDepartment employerDepartment)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerDepartmentInsert(employerDepartment)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerDepartmentRemove(EmployerDepartment employerDepartment)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerDepartmentRemove(employerDepartment)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerDepartmentUpdate(EmployerDepartment employerDepartment)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerDepartmentUpdate(employerDepartment)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerPaymentUpsert(EmployerPayment employerPayment)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerPaymentUpsert(employerPayment)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerUserIdUpsert(SecurityVM vm)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerUserIdUpsert(Guid.Parse(vm.UserName), vm.UserId)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerContactPhotoUpload(Guid employerGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerContactPhotoUpload(HttpContext.Current.Request,employerGuId)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerCompanyLogoUpload(Guid employerGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerCompanyLogoUpload(HttpContext.Current.Request, employerGuId)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerDeptVideoUpload(Guid employerGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerDeptVideoUpload(HttpContext.Current.Request, employerGuId)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployerCompanyVideoUpload(Guid employerGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerCompanyVideoUpload(HttpContext.Current.Request, employerGuId)
            });

        }

    }
}