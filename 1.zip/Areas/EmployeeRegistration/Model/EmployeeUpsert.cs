﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Employee = JobDoggApi.Models.DbRepository.JD_EMP_Employee;

namespace JobDoggApi.Areas.EmployeeRegistration.Model
{
    public class EmployeeUpsert
    {
        public Employee employee { get; set; }
        public int step { get; set; }
    }
    public class Jobdoggfile
    {
        public int EmployeeId { get; set; }
        public string filecontent { get; set; }
        public string filename { get; set; }
        public string Guid { get; set; }
    }

    public class UploadProfilePicDetails
    {
        public string rootFolder;
        public string fileName;
        public string fileGuid;
    }
    public partial class EmployeeMillitary
    {
        public int EmployeeMillitaryId { get; set; }
        public int EmployeeId { get; set; }
        public string MilitaryBranch { get; set; }
        public Nullable<bool> ActiveDutyFlag { get; set; }
        public string DischargeYear { get; set; }
        public string Rank { get; set; }
        public string CertificationLicense { get; set; }
        public string FilePath { get; set; }
        public System.DateTime Crt_Dt { get; set; }
        public string Crt_By { get; set; }
        public Nullable<System.DateTime> Upd_Dt { get; set; }
        public string Upd_By { get; set; }
        public string Status { get; set; }
        public string FileContent { get; set; }
        public string Filename { get; set; }
        public Guid GuId { get; set; }
        public Nullable<bool> IsDeleted { get; set; }
    }

}