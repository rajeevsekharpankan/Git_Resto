﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JobDoggApi.Models.DbRepository;
using JobDoggApi.Areas.EmployeeRegistration.Model;
using System.Web;
using System.Net.Http;

namespace JobDoggApi.Areas.EmployeeRegistration.Service
{
    public interface IEmployeeRegistrationService
    {

        string EmployeeBasicInfo_Upsert(JD_EMP_Employee employee);
        string EmployeePersonalInfo_Upsert(JD_EMP_Employee employee);
        string EmployeeProfileInfo_Upsert(JD_EMP_Employee employee);
        string EmployeeTransportMode_Upsert(JD_EMP_Employee employee);
        int EmployeeUserId_Upsert(string Guid, int UserId);
        Boolean Employee_Education_Cert_Upsert(List< JD_EMP_Employee_Education_Cert> certificates);
        Boolean Employee_Educations_Delete(List<int> educationids);
        Boolean Employee_Education_Cert_Delete(List<int> certificateids);
        //  int EmployeeEducationInfo_Upsert(List<JD_EMP_Employee_Education> educations);
        int EmployeeEducationInfo_Upsert(List<JD_EMP_Employee_Education> educations);
        Boolean EmployeeCompany_Upsert(List<JD_EMP_Employee_Company> companies);
        Boolean EmployeeCompany_Delete(List<int> companies);
        int EmployeeSkills_Upsert(List<JD_EMP_Employee_Skill_List> skillList, string EmployeeGuId);
        int EmployeePreferedJobDetails_Upsert(JD_EMP_Employee_PreferedJobDetails preferedJobDetails, string EmployeeGuId);
        int EmployeeBankAccountDetails_Upsert(JD_EMP_Employee_BankAccounts paymentDetails,string EmployeeGuId);
        string ResumeUpload(Jobdoggfile jobdoggfile);
        string ProfileVdoUpload(Jobdoggfile jobdoggfile);
        UploadProfilePicDetails EmployeeProfilePic_Upload(HttpRequest context,string GuId);
        JD_EMP_Employee EmployeeDetailSelect(string EmployeeGuId);
        List<JD_EMP_Employee_Education> EmployeeEducationsSelect(string EmployeeGuId);
        List<JD_EMP_Employee_Company> EmployeeCompaniessSelect(string EmployeeGuId);
        List<JD_ADM_Skills> GetSkills();
        List<JD_EMP_Employee_Skill_List> EmployeeSelectedSkillsSelect(string EmployeeGuId);
        JD_EMP_Employee_PreferedJobDetails EmployeePreferedJobDetailsSelect(string EmployeeGuId);
        JD_EMP_Employee_BankAccounts EmployeeBankAccountDetails_Select(string GuId);
        int EmployeeMilitaryInfo_Upsert(List<EmployeeMillitary> miliatryList, Guid EmployeeGuId);
        List<EmployeeMillitary> EmployeeMiliatrySelect(string EmployeeGuId);
        List<JD_EMP_Employee_Education_Cert> EmployeeEducationCertsSelect(string EmployeeGuId);


    }
}
