﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using JobDoggApi.Models.DbRepository;
using Employee = JobDoggApi.Models.DbRepository.JD_EMP_Employee;
using education = JobDoggApi.Models.DbRepository.JD_EMP_Employee_Education;
using JobDoggApi.Base;
using static JobDoggApi.Models.DbRepository.DbRepository;
using JobDoggApi.Areas.EmployeeRegistration.Model;
using System.Net.Http;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Configuration;
using System.Net;
using JobDoggApi.Utilities;

namespace JobDoggApi.Areas.EmployeeRegistration.Service
{
    public class EmployeeRegistrationService : ServiceBase, IEmployeeRegistrationService
    {
        public string EmployeeBasicInfo_Upsert(Employee employee)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Basic_info_Upsert(employee);
                }

            }, "JD_Employee_Basic_Upsert");

            return result;
        }
        public string EmployeePersonalInfo_Upsert(Employee employee)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Personal_info_Upsert(employee);
                }

            }, "JD_Employee_Personal_Upsert");

            return result;
        }
        public int EmployeeEducationInfo_Upsert(List<JD_EMP_Employee_Education> educations)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Education_Upsert(educations);
                }

            }, "JD_Employee_Education_Upsert");

            return result;
        }

        public JD_EMP_Employee EmployeeDetailSelect(string EmployeeGuId)
        {
            JD_EMP_Employee result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.EmployeeDetailSelect(EmployeeGuId);
                }

            }, "JD_Employee_Details_Select");

            return result;
        }

        public List<education> EmployeeEducationsSelect(string EmployeeGuId)
        {
            List<education> result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.EmployeeEducationsSelect(EmployeeGuId);
                }

            }, "JD_Employee_Educations_Select");

            return result;
        }

        public Boolean EmployeeCompany_Upsert(List<JD_EMP_Employee_Company> companies)
        {
            Boolean result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Compnay_Upsert(companies);
                }

            }, "JD_Employee_Companies_Upsert");
            return result;
        }
        public Boolean EmployeeCompany_Delete(List<int> companies)
        {
            Boolean result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Experience_Delete(companies);
                }

            }, "JD_Employee_Experience_Delete");
            return result;
        }
        public int EmployeeSkills_Upsert(List<JD_EMP_Employee_Skill_List> skillList, string EmployeeGuId)
        {
            int count = 0;
            foreach (var skill in skillList)
            {
                int result = ExecuteAction(() =>
                {
                    using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                    {
                        return db.Employee_Skills_Upsert(skill, EmployeeGuId);
                    }

                }, "EmployeeSkills_Upsert");
                count++;
            }
            return count;

        }

        public List<JD_EMP_Employee_Skill_List> EmployeeSelectedSkillsSelect(string EmployeeGuId)
        {
            List<JD_EMP_Employee_Skill_List> result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_SelectedSkills_Select(EmployeeGuId);
                }

            }, "EmployeeSelectedSkillsSelect");

            return result;
        }

        public int EmployeePreferedJobDetails_Upsert(JD_EMP_Employee_PreferedJobDetails preferedJobDetails, string EmployeeGuId)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_PreferedJobDetails_Upsert(preferedJobDetails, EmployeeGuId);
                }

            }, "EmployeePreferedJobDetails_Upsert");
            return result;
        }

        public JD_EMP_Employee_PreferedJobDetails EmployeePreferedJobDetailsSelect(string EmployeeGuId)
        {
            JD_EMP_Employee_PreferedJobDetails result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_PreferedJobDetails_Select(EmployeeGuId);
                }

            }, "EmployeePreferedJobDetailsSelect");

            return result;
        }

        public List<JD_EMP_Employee_Company> EmployeeCompaniessSelect(string EmployeeGuId)
        {
            List<JD_EMP_Employee_Company> result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.EmployeeCompaniessSelect(EmployeeGuId);
                }

            }, "JD_Employee_Educations_Select");

            return result;
        }


        public string EmployeeProfileInfo_Upsert(Employee employee)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Profile_info_Upsert(employee);
                }

            }, "EmployeeProfileInfo_Upsert");
            return result;
        }
        public string EmployeeTransportMode_Upsert(JD_EMP_Employee employee)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_TransportMode_Upsert(employee);
                }

            }, "EmployeeTransportMode_Upsert");
            return result;
        }
        public int EmployeeUserId_Upsert(string Guid, int UserId)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_UserId_Upsert(Guid, UserId);
                }

            }, "EmployeeTransportMode_Upsert");
            return result;
        }

        public int EmployeeBankAccountDetails_Upsert(JD_EMP_Employee_BankAccounts paymentDetails, string EmployeeGuId)
        {
            int result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_BankAccount_Details_Upsert(paymentDetails, EmployeeGuId);
                }

            }, "EmployeeBankAccountDetails_Upsert");

            return result;
            // return 0;
        }

        public JD_EMP_Employee_BankAccounts EmployeeBankAccountDetails_Select(string GuId)
        {
            JD_EMP_Employee_BankAccounts result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_BankAccountDetails_Select(GuId);
                }

            }, "EmployeeBankAccountDetails_Select");

            return result;
        }

        public string ResumeUpload(Jobdoggfile jobdoggfile)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.ResumeUpload(jobdoggfile);
                }
            }, "JD_Employee_Resume_Upsert");
            return result;
        }
        public string ProfileVdoUpload(Jobdoggfile jobdoggfile)
        {
            string result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.ProfileVdoUpload(jobdoggfile);
                }
            }, "JD_Employee_ProfileVdo_Upsert");
            return result;
        }

        public UploadProfilePicDetails EmployeeProfilePic_Upload(HttpRequest context, string GuId)
        {
            var filepath = string.Empty;
            // string fileGuid = "";
            var fileName = string.Empty;

            try
            {
                if (context.Files.Count > 0)
                {
                    fileName = context.Files[0].FileName;
                    // fileGuid = Guid.NewGuid().ToString();
                    // string imageName = String.Format("\\{0}_{1}", fileGuid, fileName);
                    // String path = ConfigurationManager.AppSettings["profilePhotoPath"] + "/Employee/" + employeeId;
                    String path = ConfigurationManager.AppSettings["SharedPath"] + ConfigurationManager.AppSettings["EmployeeFolder"] + "/" + GuId;
                    PictureUpload picUpload = new PictureUpload();
                    filepath = picUpload.profilePicUpload(context.Files[0], path, fileName);
                }
            }
            catch (Exception ex)
            {
                //status.Message = ex.Message;
            }
            return new UploadProfilePicDetails()
            {
                rootFolder = ConfigurationManager.AppSettings["EmployeeFolder"],
                fileName = fileName,
                fileGuid = GuId
            };

        }

        public List<JD_ADM_Skills> GetSkills()
        {
            List<JD_ADM_Skills> result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.GeneralModules db = new JobDoggApi.Models.DbRepository.GeneralModules())
                {
                    return db.GetSkills();
                }
            }, "JD_Employee_Resume_Upsert");
            return result;
        }

        public int EmployeeMilitaryInfo_Upsert(List<EmployeeMillitary> miliatryList, Guid EmployeeGuId)
        {
            // List<JD_EMP_Employee_Millitary> returnList = new List<JD_EMP_Employee_Millitary>();
            int count = 0;
            foreach (var military in miliatryList)
            {
                int result = ExecuteAction(() =>
                {
                    using (Models.DbRepository.EmployeeRegistration db = new Models.DbRepository.EmployeeRegistration())
                    {
                        return db.Employee_Military_info_Upsert(military, EmployeeGuId);
                    }
                }, "EmployeeMilitaryInfo_Upsert");
                // returnList.Add(result);
                count++;
            }
            return count;
        }

        public List<EmployeeMillitary> EmployeeMiliatrySelect(string EmployeeGuId)
        {
            List<EmployeeMillitary> result = ExecuteAction(() =>
            {
                using (Models.DbRepository.EmployeeRegistration db = new Models.DbRepository.EmployeeRegistration())
                {
                    return db.EmployeeMiliatrySelect(EmployeeGuId);
                }
            }, "EmployeeMiliatrySelect");
            return result;
        }
        public List<JD_EMP_Employee_Education_Cert> EmployeeEducationCertsSelect(string EmployeeGuId)
        {
            List<JD_EMP_Employee_Education_Cert> result = ExecuteAction(() =>
            {
                using (Models.DbRepository.EmployeeRegistration db = new Models.DbRepository.EmployeeRegistration())
                {
                    return db.EmployeeEducationsCertSelect(EmployeeGuId);
                }
            }, "JD_Employee_Educations_Cert_Select");
            return result;
        }


        public Boolean Employee_Educations_Delete(List<int> educationids)
        {
            Boolean result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Educations_Delete(educationids);
                }
            }, "JD_Employee_Education_Delete");
            return result;
        }
        public Boolean Employee_Education_Cert_Delete(List<int> certificateids)
        {
            Boolean result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Education_Cert_Delete(certificateids);
                }
            }, "JD_Employee_Education_Delete");
            return result;
        }
        public Boolean Employee_Education_Cert_Upsert(List<JD_EMP_Employee_Education_Cert> certificates)
        {
            Boolean result = ExecuteAction(() =>
            {
                using (JobDoggApi.Models.DbRepository.EmployeeRegistration db = new JobDoggApi.Models.DbRepository.EmployeeRegistration())
                {
                    return db.Employee_Education_Cert_Upsert(certificates);
                }

            }, "JD_Employee_Education_certifications_Upsert");

            return result;
        }

    }
}