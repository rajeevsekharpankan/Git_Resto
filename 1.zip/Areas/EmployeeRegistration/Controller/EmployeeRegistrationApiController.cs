﻿using JobDoggApi.Areas.EmployeeRegistration.Model;
using JobDoggApi.Areas.EmployeeRegistration.Service;
using JobDoggApi.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Employee = JobDoggApi.Models.DbRepository.JD_EMP_Employee;
using education = JobDoggApi.Models.DbRepository.JD_EMP_Employee_Education;
using company = JobDoggApi.Models.DbRepository.JD_EMP_Employee_Company;
using PaymentDetails = JobDoggApi.Models.DbRepository.JD_EMP_Employee_BankAccounts;
using System.Threading.Tasks;
using System.Web;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using JobDoggApi.Areas.SecurityManagement.Model;
using System.Configuration;
using JobDoggApi.Models.DbRepository;

namespace JobDoggApi.Areas.EmployeeRegistration.Controller
{
    public class EmployeeRegistrationApiController : ApiControllerBase
    {
        private readonly IEmployeeRegistrationService _service = null;

        protected override ServiceBase Service
        {
            get
            {
                return (ServiceBase)this._service;
            }
        }

        public EmployeeRegistrationApiController()
            : this(new EmployeeRegistrationService())
        {

        }

        public EmployeeRegistrationApiController(EmployeeRegistrationService service)
        {
            this._service = service;
        }

        [HttpPost]
        public HttpResponseMessage EmployeeInfoUpsert(EmployeeUpsert employeeupsert)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = employeeupsert.step == 1 ? this._service.EmployeeBasicInfo_Upsert(employeeupsert.employee) :
                (employeeupsert.step == 2 ? this._service.EmployeePersonalInfo_Upsert(employeeupsert.employee) :
                (employeeupsert.step == 7 ? this._service.EmployeeProfileInfo_Upsert(employeeupsert.employee) :
                (employeeupsert.step == 8 ? this._service.EmployeeTransportMode_Upsert(employeeupsert.employee) : "3")))
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployeeMilitaryUpsert(List<EmployeeMillitary> miliatryList, Guid EmployeeGuId)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeMilitaryInfo_Upsert(miliatryList, EmployeeGuId)
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployeeEducationUpsert(List<JD_EMP_Employee_Education> educations)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeEducationInfo_Upsert(educations)
                //ContentData = null
            });
        }
        [HttpPost]
        public HttpResponseMessage EmployeeEducationsDelete(List<int> educationids)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.Employee_Educations_Delete(educationids)
                //ContentData = null
            });
        }
        [HttpPost]
        public HttpResponseMessage EmployeeEducationCertDelete(List<int> certificateids)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.Employee_Education_Cert_Delete(certificateids)
                //ContentData = null
            });
        }
        [HttpPost]
        public HttpResponseMessage EmployeeEducationCertUpsert(List<JD_EMP_Employee_Education_Cert> certificates)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.Employee_Education_Cert_Upsert(certificates)
                //ContentData = null
            });
        }
        [HttpPost]
        public HttpResponseMessage EmployeeCompanyUpsert(List<JD_EMP_Employee_Company> companies)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeCompany_Upsert(companies)
                //ContentData = null
            });
        }
        [HttpPost]
        public HttpResponseMessage EmployeeCompanyDelete(List<int> companies)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeCompany_Delete(companies)
                //ContentData = null
            });
        }

        /// <summary>
        /// This method will insert or update the employee skills
        /// </summary>
        /// <param name="skillList">stores a list of employee's selected skills</param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage EmployeeSkillsUpsert(List<JD_EMP_Employee_Skill_List> skillList, string EmployeeGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeSkills_Upsert(skillList, EmployeeGuId)
            });
        }

        /// <summary>
        /// This method will insert or update the employee's preferedJobDetails
        /// </summary>
        /// <param name="preferedJobdetails">contains preferedjobdetails</param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage EmployeePreferedJobDetailsUpsert(JD_EMP_Employee_PreferedJobDetails preferedJobdetails, string EmployeeGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeePreferedJobDetails_Upsert(preferedJobdetails, EmployeeGuId)
            });
        }

        /// <summary>
        /// This method will insert or update the employee's BankAccountDetails
        /// </summary>
        /// <param name="paymentDetails">contains bankaccount details</param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage EmployeeBankAccountDetailsUpsert(PaymentDetails paymentDetails, string EmployeeGuId)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeBankAccountDetails_Upsert(paymentDetails, EmployeeGuId)
                // ContentData = null
            });
        }

        [HttpPost]
        public HttpResponseMessage EmployeeUserIdUpsert(SecurityVM vm)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeUserId_Upsert((vm.UserName), vm.UserId)
            });
        }


        [HttpGet]
        public HttpResponseMessage EmployeeDetailSelect(string EmployeeGuId)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {

                ContentData = this._service.EmployeeDetailSelect(EmployeeGuId)
            });
        }
        [HttpGet]
        public HttpResponseMessage EmployeeMilitarySelect(string EmployeeGuId)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeMiliatrySelect(EmployeeGuId)
            });
        }
        [HttpGet]
        public HttpResponseMessage EmployeeEducationSelect(string EmployeeGuId)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeEducationsSelect(EmployeeGuId)
            });
        }
        [HttpGet]
        public HttpResponseMessage EmployeeEducationCertSelect(string EmployeeGuId)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeEducationCertsSelect(EmployeeGuId)
            });
        }

        [HttpGet]
        public HttpResponseMessage EmployeeCompaniesSelect(string EmployeeGuId)
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeCompaniessSelect(EmployeeGuId)
            });
        }

        /// <summary>
        /// this method will give the employee's saved prefered job details
        /// </summary>
        /// <param name="EmployeeId">current employee id</param>
        /// <returns></returns>

        [HttpGet]
        public HttpResponseMessage EmployeePreferedJobDetailsSelect(string EmployeeGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeePreferedJobDetailsSelect(EmployeeGuId)
            });
        }

        /// <summary>
        /// this method returns employee's saved selected skills
        /// </summary>
        /// <param name="EmployeeId">current emplloyee's id</param>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage EmployeeSelectedSkillsSelect(string EmployeeGuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeSelectedSkillsSelect(EmployeeGuId)
            });
        }

        [HttpGet]
        public HttpResponseMessage GetSkills()
        {

            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetSkills()
            });
        }
        /// <summary>
        /// this method give employes's saved bankaccount details
        /// </summary>
        /// <param name="EmployeeId"></param>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage EmployeeBankAccountDetailsSelect(string GuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeBankAccountDetails_Select(GuId)
            });
        }

        public HttpResponseMessage ResumeUpload(Jobdoggfile file)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.ResumeUpload(file)

            });

        }
        [HttpPost]
        public HttpResponseMessage ProfileVdoUpload(Jobdoggfile file)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.ProfileVdoUpload(file)
            });

        }
        /// <summary>
        /// this method upload the profile picture into shared location 
        /// </summary>
        /// <returns></returns>
        /// 
        [HttpPost]
        public HttpResponseMessage EmployeeProfilePictureUpload(string GuId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployeeProfilePic_Upload(HttpContext.Current.Request, GuId)
            });

        }
    }
}
