﻿using JobDoggApi.Areas.SecurityManagement.Model;
using JobDoggApi.Areas.SecurityManagement.Service;
using JobDoggApi.Base;
using JobDoggApi.Models.DbRepository;
using JobDoggApi.Utilities;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace JobDoggApi.Areas.SecurityManagement.Controller
{
    public class SecurityManagementApiController : ApiControllerBase
    {
        private readonly ISecurityManagementService _service = null;

        protected override ServiceBase Service
        {
            get
            {
                return (ServiceBase)this._service;
            }
        }

        #region Constructors

        public SecurityManagementApiController()
            : this(new SecurityManagementService())
        {

        }

        public SecurityManagementApiController(SecurityManagementService service)
        {
            this._service = service;
        }

        #endregion

        /// <summary>
        /// This method will check the authentication
        /// </summary>
        /// <param name="logonViewData">logon user data</param>
        /// <returns></returns>
        [HttpPost]
        public HttpResponseMessage Authenticate(SecurityVM logonViewData)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.Authenticate(logonViewData)
            });
        }

        [HttpPost]
        public HttpResponseMessage UserCreation(JD_EMP_Employee Employee)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.UserCreation(Employee)
            });
        }

        /// <summary>
        /// This method will return logged-in user info
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetLoggedInUser()
        {
            var logonUser = this.LoggedInUser.Name;
            return logonUser != null ? this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = new
                {
                    LoggedInUser = logonUser
                }
            }) : this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = new
                {
                    LoggedInUser = string.Empty
                }
            });
        }

        /// <summary>
        /// This method will return the logged in user permisions
        /// </summary>
        /// <returns>Returns an array of string which contains the roles that are assigned to the user</returns>
        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetPermissions()
        {
            return this.LoggedInUser != null ? this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = new
                {
                    Roles = this.LoggedInUser.Roles.Split(',')
                }
            }) : this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = new
                {
                    Roles = string.Empty
                }
            });
        }

        /// <summary>
        /// This method will change the current password to a new password
        /// </summary>
        /// <param name="currentPassword">Store the current password</param>
        /// <param name="newPassword">Store the new password</param>
        /// <param name="retypedPassword">Store the new retyped password</param>
        /// <returns>Returns true if the operation is success</returns>
        [HttpPost]
        [ApiAuthorize]
        public HttpResponseMessage ChangePassword(string currentPassword, string newPassword, string retypedPassword)
        {
            try
            {
                var result = this._service.ChangePassword(this.LoggedInUser.Id, currentPassword, newPassword, retypedPassword);

                return Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
                {
                    ContentData = result,
                    ErrorMessage = ""
                });
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
                {
                    ContentData = null,
                    ErrorMessage = Prototype.CorrectExceptionMessage(ex)
                });
            }
        }

        [HttpPost]
        public HttpResponseMessage EmployerUserCreation(JD_EMR_Employer employer)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.EmployerUserCreation(employer)
            });
        }
    }
}