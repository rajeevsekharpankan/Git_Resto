﻿using JobDoggApi.Areas.SecurityManagement.Model;
using JobDoggApi.Base;
using JobDoggApi.Models.DbRepository;
using JobDoggApi.Utilities;
using System;
using System.Configuration;
using System.Linq;

namespace JobDoggApi.Areas.SecurityManagement.Service
{
    public class SecurityManagementService : ServiceBase, ISecurityManagementService
    {

        public Authentication Authenticate(SecurityVM user)
        {
            var result = ExecuteAction(() =>
            {
                using (Security db = new Security())
                {
                    var userData = db.GetUserInfo(user.UserName);
                    var resultObj = new Authentication();
                    resultObj = new Authentication()
                    {
                        IsAuthenticated = false
                    };
                    if (userData != null)
                    {
                        if (userData.Password != Encrypt.GetHashPassword(user.Password, userData.Salt))
                        {
                            resultObj = new Authentication()
                            {
                                IsAuthenticated = false
                            };
                        }
                        else
                        {
                            string keyIdentifier = Prototype.RandomString(16);

                            var identity = new Token(userData.UserId, userData.Name, userData.UserName, true, string.Join(",", userData.Roles.ToArray()), keyIdentifier);
                            db.SaveToken(identity.Encrypt(), userData.UserId, user.UserName, keyIdentifier);
                            resultObj = new Authentication()
                            {
                                IsAuthenticated = true,
                                Token = identity.Encrypt(),
                                IsActive = userData.IsActive
                            };
                        }
                    }

                    resultObj.TimeOut = Convert.ToInt32(ConfigurationManager.AppSettings["sessiontimeout"]);

                    return resultObj;
                }
            }, "Authenticate");
            return result;
        }

        public SecurityVM UserCreation(JD_EMP_Employee employee)
        {
            var result = ExecuteAction(() =>
            {
                using (Security db = new Security())
                {
                    string username = "", copy = "";
                    foreach (char chr in employee.FirstName)
                    {
                        username = copy + chr + employee.LastName;
                        var userData = db.GetUserInfo(username);
                        if (userData == null) break;
                        copy = copy + chr.ToString();
                    }
                    var resultObj = new Authentication();
                    resultObj = new Authentication()
                    {
                        IsAuthenticated = false
                    };
                    string salt = Encrypt.GetSalt();
                    string password = ConfigurationManager.AppSettings["defaultpassword"];
                    int userid;
                    string encryptedpasswrod = Encrypt.GetHashPassword(ConfigurationManager.AppSettings["defaultpassword"], salt);
                    userid = db.CreateNewUser(0, encryptedpasswrod, username, "PBLC_USER", salt);
                    return new SecurityVM()
                    {
                        Password = password,
                        UserName = username,
                        UserId = userid
                    };
                };

            }

            , "UserCreation");
            return result;
        }

        public bool ChangePassword(int userId, string currentPassword, string newPassword, string retypedPassword)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Security db = new Security())
                {
                    if (userId > 0)
                    {
                        if (currentPassword == newPassword || currentPassword == retypedPassword)
                        {
                            throw new Exception("New password cannot be same as the current password");
                        }
                        if (newPassword != retypedPassword)
                        {
                            throw new Exception("New password and retyped password doesn't match");
                        }

                        var userData = db.GetUserByUserId(userId);

                        if (userData != null)
                        {
                            if (userData.Password != Encrypt.GetHashPassword(currentPassword, userData.Salt))
                            {
                                throw new Exception("The current password that you have given is wrong");
                            }
                            else
                            {
                                string password = Encrypt.GetHashPassword(newPassword, userData.Salt);

                                db.ChangePassword(userId, password);

                                return true;
                            }
                        }
                    }
                    else
                    {
                        throw new Exception("User is not valid");
                    }
                    return true;
                }
            }, "ChangePassword", "SecurityManagementService");
            return result;
        }

        public bool UserCreation(int Employeeid)
        {
            throw new NotImplementedException();
        }

        public SecurityVM EmployerUserCreation(JD_EMR_Employer employer)
        {
            var result = ExecuteAction(() =>
            {
                using (Security db = new Security())
                {
                    string username = "", copy = "";
                    foreach (char chr in employer.CompanyName)
                    {
                        int randomInteger = (new Random()).Next(10000, 99999);
                        username = copy + chr + randomInteger;
                        var userData = db.GetUserInfo(username);
                        if (userData == null) break;
                        copy = copy + chr.ToString();
                    }
                    var resultObj = new Authentication();
                    resultObj = new Authentication()
                    {
                        IsAuthenticated = false
                    };
                    string salt = Encrypt.GetSalt();
                    string password = ConfigurationManager.AppSettings["defaultpassword"];
                    int userid;
                    string encryptedpasswrod = Encrypt.GetHashPassword(ConfigurationManager.AppSettings["defaultpassword"], salt);
                    userid = db.CreateNewUser(0, encryptedpasswrod, username, "PBLC_USER", salt,3);
                    return new SecurityVM()
                    {
                        Password = password,
                        UserName = username,
                        UserId = userid
                    };
                };

            }

            , "UserCreation");
            return result;
        }
    }
}