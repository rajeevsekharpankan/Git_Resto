﻿using JobDoggApi.Areas.SecurityManagement.Model;
using JobDoggApi.Models.DbRepository;

namespace JobDoggApi.Areas.SecurityManagement.Service
{
    interface ISecurityManagementService
    {
        Authentication Authenticate(SecurityVM user);

        bool ChangePassword(int userId, string currentPassword, string newPassword, string retypedPassword);
        SecurityVM UserCreation(JD_EMP_Employee Employeeid);
        SecurityVM EmployerUserCreation(JD_EMR_Employer employer);
    }
}
