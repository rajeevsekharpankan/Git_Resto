﻿namespace JobDoggApi.Areas.SecurityManagement.Model
{
    /// <summary>
    /// Security VM
    /// </summary>
    public class SecurityVM
    {
        /// <summary>
        /// Stores user name
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Stores the password
        /// </summary>
        public string Password { get; set; }

        public int UserId { get; set; }
    }

    /// <summary>
    /// Authentication class
    /// </summary>
    public class Authentication
    {
        /// <summary>
        /// Stores the user is authenticated or not
        /// </summary>
        public bool IsAuthenticated { get; set; }
        /// <summary>
        /// Stores the token string
        /// </summary>
        public string Token { get; set; }
        /// <summary>
        /// Stores the user is active or not
        /// </summary>
        public bool IsActive { get; set; }
        /// <summary>
        /// Session timeout
        /// </summary>
        public int TimeOut { get; set; }
    }
}