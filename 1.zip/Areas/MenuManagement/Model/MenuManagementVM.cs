﻿namespace JobDoggApi.Areas.MenuManagement
{
    public class MenuManagementVM
    {
    }
}