﻿using JobDoggApi.Base;
using JobDoggApi.Models.DbRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Areas.MenuManagement.Service
{
    public class MenuManagementService : ServiceBase, IMenuManagementService
    {
        public List<GetMenuList_Result> GetMenuList(string roles)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Menu db = new Menu())
                {
                    return db.GetMenuList(roles);
                }
            }, "GetMenuList", "Menumangement");
            return result;
        }
    }
}