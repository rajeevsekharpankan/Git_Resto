﻿using JobDoggApi.Models.DbRepository;
using System.Collections.Generic;

namespace JobDoggApi.Areas.MenuManagement.Service
{
    interface IMenuManagementService
    {
        List<GetMenuList_Result> GetMenuList(string roles);
    }
}
