﻿using JobDoggApi.Areas.MenuManagement.Service;
using JobDoggApi.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace JobDoggApi.Areas.MenuManagement.Controller
{
    public class MenuManagementApiController : ApiControllerBase
    {
        private readonly IMenuManagementService _service = null;

        protected override ServiceBase Service
        {
            get
            {
                return (ServiceBase)this._service;
            }
        }

        #region Constructors

        public MenuManagementApiController()
            : this(new MenuManagementService())
        {

        }

        public MenuManagementApiController(MenuManagementService service)
        {
            this._service = service;
        }

        #endregion

        [HttpPost]
        public HttpResponseMessage GetMenuList()
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetMenuList(this.LoggedInUser == null ? "NoRole" : this.LoggedInUser.Roles)
        });
        }
    }
}