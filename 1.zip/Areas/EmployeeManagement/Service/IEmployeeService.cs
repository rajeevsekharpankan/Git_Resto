﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JobDoggApi.Models.DbRepository;

namespace JobDoggApi.Areas.EmployeeManagement.Service
{
    interface IEmployeeService
    {
      JD_Employee_Select_Result GetEmployeeDetails(int userId);
    }
}
