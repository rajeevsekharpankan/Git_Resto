﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using JobDoggApi.Base;
using JobDoggApi.Models.DbRepository;

namespace JobDoggApi.Areas.EmployeeManagement.Service
{
    public class EmployeeService : ServiceBase, IEmployeeService
    {

        public JD_Employee_Select_Result GetEmployeeDetails(int userId)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Employee db = new Employee())
                {
                    return db.GetEmployeeDetails(userId);
                }
            }, "GetEmployeeDetails", "EmployeeService");
            return result;
        }
    }
}