﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using JobDoggApi.Areas.EmployeeManagement.Service;
using JobDoggApi.Base;

namespace JobDoggApi.Areas.EmployeeManagement.Controller
{
    public class EmployeeApiController : ApiControllerBase
    {
        private readonly IEmployeeService _service = null;

        protected override ServiceBase Service
        {
            get
            {
                return (ServiceBase)this._service;
            }
        }

        #region Constructors

        public EmployeeApiController()
            : this(new EmployeeService())
        {

        }

        public EmployeeApiController(EmployeeService service)
        {
            this._service = service;
        }

        #endregion

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetEmployeeDetails()
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetEmployeeDetails(this.LoggedInUser.Id)
            });
        }

    }
}