﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using JobDoggApi.Base;

namespace JobDoggApi.Areas.FindBones.Controller
{
    public class FindBonesApiController : ApiControllerBase
    {
      
    }
}