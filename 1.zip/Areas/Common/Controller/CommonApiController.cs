﻿using JobDoggApi.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using JobDoggApi.Areas.EmployeeManagement.Service;
using JobDoggApi.Areas.Common.Service;

namespace JobDoggApi.Areas.Common.Controller
{
    public class CommonApiController : ApiControllerBase
    {
        private readonly ICommonService _service = null;

        protected override ServiceBase Service
        {
            get
            {
                return (ServiceBase)this._service;
            }
        }

        public CommonApiController()
            : this(new CommonService())
        {

        }

        public CommonApiController(CommonService service)
        {
            this._service = service;
        }


        [HttpGet]
        public HttpResponseMessage GetStates()
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetAllStates()
            });
        }

        /// <summary>
        /// This method gives list of dropdown values based on types
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage GetApplicationDropdowns(string type)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetApplicationDropdowns(type)
            });
        }

    }
}
