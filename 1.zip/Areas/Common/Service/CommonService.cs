﻿using JobDoggApi.Base;
using JobDoggApi.Models.DbRepository;
using JobDoggApi.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JobDoggApi.Areas.Common.Service
{
    public class CommonService : ServiceBase, ICommonService
    {
        public List<JD_ADM_States> GetAllStates()
        {
            List<JD_ADM_States> result = ExecuteAction(() =>
            {
                using (CommonFunctions db = new CommonFunctions())
                {
                    return db.GetAllStates();
                }

            }, "JD_ADM_States_Select");

            return result;
        }

        public List<JD_ADM_Dropdown_Select_Result> GetApplicationDropdowns(string type)
        {
            List<JD_ADM_Dropdown_Select_Result> result = ExecuteAction(() =>
            {
                using (CommonFunctions db = new CommonFunctions())
                {
                    return db.GetApplicationDropdowns(type);
                }

            }, "GetApplicationDropdowns");

            return result;
        }
    }
}