﻿using JobDoggApi.Models.DbRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobDoggApi.Areas.Common.Service
{
    interface ICommonService
    {
        List<JD_ADM_States> GetAllStates();
        List<JD_ADM_Dropdown_Select_Result> GetApplicationDropdowns(string type);
    }
}
