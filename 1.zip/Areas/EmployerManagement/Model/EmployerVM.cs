﻿using System;
using System.Collections.Generic;

namespace JobDoggApi.Areas.EmployerManagement.Model
{
    public class EmployerVM
    {
    }
    
    public class EmailContact
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }

    public class Location
    {
        public int LocationId { get; set; }
        public string LocationText { get; set; }
    }

    public class HowMuchAreMyDoggs : Location
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string SelectedDoggsText { get; set; }
        public string SelectedDoggsType { get; set; }
    }

    public class DogList
    {
        public int DogId { get; set; }
        public string DogName { get; set; }
    }

    public class DogType
    {
        public int DogId { get; set; }
        public string Type { get; set; }
    }

    public partial class EmployerMessage
    {
        public int EmployerMessageId { get; set; }
        public string ToAddress { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public DateTime SendDate { get; set; }
        public string Status { get; set; }
    }

    public class EmployerMessageListCount
    {
        public int MessageCount { get; set; }
    }

    public class EmployerMessageData
    {
        public List<EmployerMessage> EmployerMessages { get; set; }
        public EmployerMessageListCount Count { get; set; }
    }
}