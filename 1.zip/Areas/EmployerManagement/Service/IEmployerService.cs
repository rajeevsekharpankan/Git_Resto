﻿using JobDoggApi.Areas.EmployerManagement.Model;
using JobDoggApi.Models.DbRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobDoggApi.Areas.EmployerManagement.Service
{
    interface IEmployerService
    {
        List<Location> GetLocations(string searchText);

        EmployerMessageData GetEmployerMessageList(int userId, int currentPageNumber, int itemsPerPage);

        GetEmployerMessageList_Result GetEmployerMessageById(int userId, int messageId);

        EmailContact GetEmailAddress(string searchText);

        bool SendEmployerEmail(GetEmployerMessageList_Result employerMessage);

        JD_Employer_Select_Result GetEmployerDetails(int userId);

        JD_EmployerContact_Select_Result GetEmployerContactDetails(int userId);

        List<DogList> GetDogList(int userId);

        List<DogType> GetTypeOfDoggs(int userId);
    }
}
