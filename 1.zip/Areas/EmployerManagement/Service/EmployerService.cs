﻿using JobDoggApi.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using JobDoggApi.Areas.EmployerManagement.Model;
using JobDoggApi.Models.DbRepository;

namespace JobDoggApi.Areas.EmployerManagement.Service
{
    public class EmployerService : ServiceBase, IEmployerService
    {
        public GetEmployerMessageList_Result GetEmployerMessageById(int userId, int messageId)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Employer db = new Employer())
                {
                    return db.GetEmployerMessageById(userId, messageId);
                }
            }, "GetEmployerMessageById", "EmployerService");
            return result;
        }

        public EmployerMessageData GetEmployerMessageList(int userId, int currentPageNumber, int itemsPerPage)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Employer db = new Employer())
                {
                    return db.GetEmployerMessageList(userId, currentPageNumber, itemsPerPage);
                }
            }, "GetEmployerMessageList", "EmployerService");
            return result;
        }

        public List<Location> GetLocations(string searchText)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (GeneralModules db = new GeneralModules())
                {
                    return db.GetLocations(searchText);
                }
            }, "GetLocations", "EmployerService");
            return result;
        }

        public EmailContact GetEmailAddress(string searchText)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Employer db = new Employer())
                {
                    return db.GetEmailAddress(searchText);
                }
            }, "GetEmailAddress", "EmployerService");
            return result;
        }

        public bool SendEmployerEmail(GetEmployerMessageList_Result employerMessage)
        {
            throw new NotImplementedException();
        }

        public JD_Employer_Select_Result GetEmployerDetails(int userId)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Employer db = new Employer())
                {
                    return db.GetEmployerDetails(userId);
                }
            }, "GetEmployerDetails", "EmployerService");
            return result;
        }

        public JD_EmployerContact_Select_Result GetEmployerContactDetails(int userId)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Employer db = new Employer())
                {
                    return db.GetEmployerContactDetails(userId);
                }
            }, "GetEmployerContactDetails", "EmployerService");
            return result;
        }

        public List<DogList> GetDogList(int userId)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Employer db = new Employer())
                {
                    return db.GetDogList(userId);
                }
            }, "GetDogList", "EmployerService");
            return result;
        }
        
        public List<DogType> GetTypeOfDoggs(int userId)
        {
            var result = ExecuteServiceAction(() =>
            {
                using (Employer db = new Employer())
                {
                    return db.GetDogTypeList(userId);
                }
            }, "GetDogList", "EmployerService");
            return result;
        }
    }
}