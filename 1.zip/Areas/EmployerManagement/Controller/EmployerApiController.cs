﻿using JobDoggApi.Areas.EmployerManagement.Model;
using JobDoggApi.Areas.EmployerManagement.Service;
using JobDoggApi.Base;
using JobDoggApi.Models.DbRepository;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace JobDoggApi.Areas.EmployerManagement.Controller
{
    public class EmployerApiController : ApiControllerBase
    {
        private readonly IEmployerService _service = null;

        protected override ServiceBase Service
        {
            get
            {
                return (ServiceBase)this._service;
            }
        }

        #region Constructors

        public EmployerApiController()
            : this(new EmployerService())
        {

        }

        public EmployerApiController(EmployerService service)
        {
            this._service = service;
        }

        #endregion

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetLocations(string searchText)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetLocations(searchText)
            });
        }

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetDoggsList()
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetDogList(this.LoggedInUser.Id)
            });
        }

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetTypeOfDoggs()
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetTypeOfDoggs(this.LoggedInUser.Id)
            });
        }

        //[HttpGet]
        //[ApiAuthorize]
        //public HttpResponseMessage GetHowMuchAreMyDoggs(HowMuchAreMyDoggs howMuchAreMyDoggsObj)
        //{
        //    return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
        //    {
        //        ContentData = this._service.GetHowMuchAreMyDoggs(howMuchAreMyDoggsObj)
        //    });
        //}

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetEmployerMessageList(int currentPageNumber, int itemsPerPage)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetEmployerMessageList(this.LoggedInUser.Id, currentPageNumber, itemsPerPage)
            });
        }

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetEmployerMessageById(int messageId)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetEmployerMessageById(this.LoggedInUser.Id, messageId)
            });
        }

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetEmailAddress(string searchText)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetEmailAddress(searchText)
            });
        }

        [HttpPost]
        [ApiAuthorize]
        public HttpResponseMessage SendEmployerEmail(GetEmployerMessageList_Result employerMessage)
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.SendEmployerEmail(employerMessage)
            });
        }

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetEmployerDetails()
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetEmployerDetails(this.LoggedInUser.Id)
            });
        }

        [HttpGet]
        [ApiAuthorize]
        public HttpResponseMessage GetEmployerContactDetails()
        {
            return this.Request.CreateResponse(HttpStatusCode.OK, new ResponseResultBase
            {
                ContentData = this._service.GetEmployerContactDetails(this.LoggedInUser.Id)
            });
        }
    }
}